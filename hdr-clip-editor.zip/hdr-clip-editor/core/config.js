'use strict';
// Loads and saves every configurable value from the .env file next to
// package.json. Nothing else in the app hardcodes a path.
const fs = require('fs');
const path = require('path');
const os = require('os');

const APP_ROOT = path.resolve(__dirname, '..');
const ENV_PATH = process.env.HDRCE_ENV_PATH || path.join(APP_ROOT, '.env');

const IS_WIN = process.platform === 'win32';

// Defaults used only when a key is missing from .env.
const DEFAULTS = {
  FFMPEG_PATH: IS_WIN ? 'ffmpeg.exe' : 'ffmpeg',
  FFPROBE_PATH: '', // empty = ffprobe next to FFMPEG_PATH
  NVENCC_PATH: IS_WIN ? 'NVEncC64.exe' : 'nvencc',
  HDR10PLUS_TOOL_PATH: IS_WIN ? 'hdr10plus_tool.exe' : 'hdr10plus_tool',
  MKVMERGE_PATH: IS_WIN ? 'C:\\Program Files\\MKVToolNix\\mkvmerge.exe' : 'mkvmerge',
  HWACCEL: IS_WIN ? 'cuda' : 'none', // ffmpeg -hwaccel value for decoding: cuda | d3d11va | auto | none
  ENCODER: 'nvencc', // nvencc (GPU) | x265 (CPU)
  NVENCC_PRESET: 'quality', // NVEncC -u: performance | default | quality | P1..P7
  WORK_DIR: '', // empty = <system temp>/hdr-clip-editor
  OUTPUT_DIR: '', // empty = folder of the first clip
  PROXY_WIDTH: '960', // preview + tracking resolution (long edge for portrait)
  BLUR_STRENGTH: '24', // downscale factor used for the blur (higher = blurrier)
  BLUR_STYLE: 'blur', // blur | pixelate
  BOX_PADDING: '12', // % added around every plate box
  OUTPUT_CONTAINER: 'mp4', // mp4 | mkv
  OUTPUT_HEIGHT: '0', // 0 = original, otherwise e.g. 1440 / 1080 (short edge)
  BITRATE_MODE: 'source', // source = match each clip's bitrate | fixed
  BITRATE_KBPS: '40000', // used when BITRATE_MODE=fixed
  AUDIO_BITRATE_KBPS: '0', // 0 = match source audio bitrate
  SLOW_SPEED: '0.125', // speed for new slow-motion parts (0.5, 0.25, 0.125, 0.0625)
  SLOW_AUDIO: 'stretch', // stretch = slowed, pitch kept | tape = slowed and deeper | mute = silent
  FPS_MODE: 'keep', // keep = every clip keeps its own frame rate | lowest = whole video at the lowest clip's rate
  FLASH_THRESHOLD: '15', // lightning finder: brightness jump needed (preview levels 0-255)
  FLASH_BEFORE_SEC: '0.3', // slow motion starts this long before each flash
  FLASH_AFTER_SEC: '0.7', // ...and ends this long after it
};

const ORDER = Object.keys(DEFAULTS);

const COMMENTS = {
  FFMPEG_PATH: 'Full path to ffmpeg (8.x recommended; gyan.dev full build works)',
  FFPROBE_PATH: 'Full path to ffprobe. Leave empty to use the ffprobe in the same folder as ffmpeg',
  NVENCC_PATH: 'Full path to NVEncC64.exe (rigaya NVEnc) - GPU HEVC encoder',
  HDR10PLUS_TOOL_PATH: 'Full path to hdr10plus_tool (quietvoid) - reads/writes HDR10+ metadata',
  MKVMERGE_PATH: 'Full path to mkvmerge (MKVToolNix) - keeps the exact phone timestamps',
  HWACCEL: 'ffmpeg hardware decoding: cuda | d3d11va | auto | none',
  ENCODER: 'Encoder: nvencc (GPU, fast) | x265 (CPU, slow fallback)',
  NVENCC_PRESET: 'NVEncC preset: performance | default | quality | P1..P7',
  WORK_DIR: 'Folder for previews and temporary files. Empty = system temp folder',
  OUTPUT_DIR: 'Default export folder. Empty = same folder as the first clip',
  PROXY_WIDTH: 'Preview/tracking size in pixels (long edge)',
  BLUR_STRENGTH: 'Blur strength (bigger = blurrier). 24 makes plates unreadable at 4K',
  BLUR_STYLE: 'blur | pixelate',
  BOX_PADDING: 'Extra % added around each plate box so edges are covered',
  OUTPUT_CONTAINER: 'mp4 | mkv',
  OUTPUT_HEIGHT: '0 = keep resolution. Otherwise the short edge in pixels (e.g. 1440, 1080)',
  BITRATE_MODE: 'source = match each clip\'s video bitrate | fixed = use BITRATE_KBPS',
  BITRATE_KBPS: 'Video bitrate in kbps when BITRATE_MODE=fixed',
  AUDIO_BITRATE_KBPS: 'AAC bitrate in kbps. 0 = match the source audio bitrate',
  SLOW_SPEED: 'Speed for new slow-motion parts: 0.5 (1/2), 0.25 (1/4), 0.125 (1/8), 0.0625 (1/16)',
  SLOW_AUDIO: 'Audio in slow-motion parts: stretch (slowed, pitch kept) | tape (slowed and deeper) | mute (silent)',
  FPS_MODE: 'Frame rate of the export: keep (each clip its own, exact) | lowest (the whole video at the lowest clip frame rate, e.g. 30)',
  FLASH_THRESHOLD: 'Lightning finder: how big a sudden brightness jump counts (lower = finds fainter flashes)',
  FLASH_BEFORE_SEC: 'Lightning finder: seconds of slow motion before each flash',
  FLASH_AFTER_SEC: 'Lightning finder: seconds of slow motion after each flash',
};

function parseEnv(text) {
  const out = {};
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const eq = line.indexOf('=');
    if (eq < 0) continue;
    const key = line.slice(0, eq).trim();
    let val = line.slice(eq + 1).trim();
    if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
      val = val.slice(1, -1);
    }
    out[key] = val;
  }
  return out;
}

// Updates don't ship a .env (it would overwrite your settings); on the very
// first start it is made from .env.example.
const EXAMPLE_PATH = path.join(APP_ROOT, '.env.example');
function ensureEnv() {
  if (!process.env.HDRCE_ENV_PATH && !fs.existsSync(ENV_PATH) && fs.existsSync(EXAMPLE_PATH)) {
    try { fs.copyFileSync(EXAMPLE_PATH, ENV_PATH); } catch (_) { /* defaults are used */ }
  }
}

function load() {
  ensureEnv();
  let fileVals = {};
  if (fs.existsSync(ENV_PATH)) fileVals = parseEnv(fs.readFileSync(ENV_PATH, 'utf8'));
  const cfg = { ...DEFAULTS, ...fileVals };
  return cfg;
}

function save(values) {
  const merged = { ...load(), ...values };
  const lines = ['# HDR10+ Clip Editor settings. Edited by the Settings panel or by hand.', ''];
  for (const k of ORDER) {
    if (COMMENTS[k]) lines.push(`# ${COMMENTS[k]}`);
    const v = String(merged[k] ?? '');
    lines.push(`${k}="${v}"`);
    lines.push('');
  }
  fs.writeFileSync(ENV_PATH, lines.join('\n'), 'utf8');
  return merged;
}

// Resolved tool paths and folders (derived values).
function resolved(cfg = load()) {
  let ffprobe = cfg.FFPROBE_PATH;
  if (!ffprobe) {
    const dir = path.dirname(cfg.FFMPEG_PATH);
    const name = IS_WIN ? 'ffprobe.exe' : 'ffprobe';
    ffprobe = dir && dir !== '.' ? path.join(dir, name) : name;
  }
  const work = cfg.WORK_DIR || path.join(os.tmpdir(), 'hdr-clip-editor');
  fs.mkdirSync(work, { recursive: true });
  return {
    ffmpeg: cfg.FFMPEG_PATH,
    ffprobe,
    nvencc: cfg.NVENCC_PATH,
    hdr10plus: cfg.HDR10PLUS_TOOL_PATH,
    mkvmerge: cfg.MKVMERGE_PATH,
    hwaccel: cfg.HWACCEL,
    workDir: work,
    cfg,
  };
}

module.exports = { load, save, resolved, DEFAULTS, ENV_PATH, APP_ROOT };
