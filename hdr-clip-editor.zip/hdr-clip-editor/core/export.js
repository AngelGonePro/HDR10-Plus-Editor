'use strict';
// Export: blur + cut + join, GPU encode, HDR10+ re-attached, exact phone
// timestamps kept, then verified.
const fs = require('fs');
const path = require('path');
const proc = require('./proc');
const log = require('./log');
const tl = require('./timeline');
const mask = require('./mask');
const h10 = require('./hdr10plus');
const { withHwFallback } = require('./proxy');

const even = (n) => Math.max(2, Math.round(n / 2) * 2);
const evenDown = (n) => Math.max(0, Math.floor(n / 2) * 2);

// A clip filmed sideways can be turned: rot = 0, 90, 180 or 270 degrees clockwise.
const normRot = (r) => ((Math.round((Number(r) || 0) / 90) * 90) % 360 + 360) % 360;
function turnedSize(clip, rot) {
  return normRot(rot) % 180 ? { w: clip.dispH, h: clip.dispW } : { w: clip.dispW, h: clip.dispH };
}
// ffmpeg filters that turn the picture
function rotFilter(rot) {
  return { 90: 'transpose=clock', 180: 'hflip,vflip', 270: 'transpose=cclock' }[normRot(rot)] || '';
}

function outDims(clip, outHeight, rot = 0) {
  const t = turnedSize(clip, rot);
  const short = Math.min(t.w, t.h);
  const H = Number(outHeight) || 0;
  if (H > 0 && short > H) {
    const s = H / short;
    return { w: even(t.w * s), h: even(t.h * s) };
  }
  return { w: t.w, h: t.h };
}
// Size of a picture w x h scaled to fit inside W x H (same shape, even numbers).
function fitInto(t, W, H) {
  const s = Math.min(W / t.w, H / t.h);
  return { w: Math.min(W, even(t.w * s)), h: Math.min(H, even(t.h * s)) };
}

const PRIM = { bt2020: 'bt2020', bt709: 'bt709', smpte170m: 'smpte170m', bt470bg: 'bt470bg', smpte240m: 'smpte240m' };
const TRC = { smpte2084: 'smpte2084', 'arib-std-b67': 'arib-std-b67', bt709: 'bt709', 'bt2020-10': 'bt2020-10', smpte170m: 'smpte170m' };
const MAT = { bt2020nc: 'bt2020nc', bt709: 'bt709', smpte170m: 'smpte170m', bt470bg: 'bt470bg' };
// Matroska / H.273 code points for mkvmerge colour flags
const H273_PRIM = { bt709: 1, bt470bg: 5, smpte170m: 6, bt2020: 9 };
const H273_TRC = { bt709: 1, smpte170m: 6, 'bt2020-10': 14, smpte2084: 16, 'arib-std-b67': 18 };
const H273_MAT = { bt709: 1, bt470bg: 5, smpte170m: 6, bt2020nc: 9 };

function colorFlags(clip) {
  return {
    prim: PRIM[clip.colorPrimaries], trc: TRC[clip.colorTransfer], mat: MAT[clip.colorSpace],
  };
}

function selectExpr(keep) {
  return keep.map(([a, b]) => (a === b ? `eq(n,${a})` : `between(n,${a},${b})`)).join('+');
}

// One source clip's frames -> blurred, scaled stream labelled `label`.
// inIdx/maskIdx are ffmpeg input numbers; frames are re-numbered 0,1,2... so
// the blur mask (one mask frame per kept frame) lines up exactly.
// The blur is done on the clip's own picture; turning (rot) comes after it.
// A clip of another size is scaled to fit the output (Lanczos), and a clip of
// another shape gets black bars (fitW x fitH = the picture inside outW x outH).
// `pick` replaces the plain frame selection when the video gets one fixed frame
// rate (it drops / repeats frames; see cfrPick).
function buildChain({ inIdx, maskIdx, keep, pick, blurStrength, blurStyle, srcW, srcH, outW, outH, fitW, fitH, tenBit, label, rot = 0 }) {
  const pf = tenBit ? 'yuv420p10le' : 'yuv420p';
  const parts = [];
  const t = `c${inIdx}`;
  const sel = `${pick || `select='${selectExpr(keep)}',setpts=N/25/TB`},format=${pf}`;
  const turned = normRot(rot) % 180 ? { w: srcH, h: srcW } : { w: srcW, h: srcH };
  const fw = fitW || outW, fh = fitH || outH;
  const scale = (rotFilter(rot) ? `,${rotFilter(rot)}` : '') +
    (fw !== turned.w || fh !== turned.h ? `,scale=${fw}:${fh}:flags=lanczos` : '') +
    (fw !== outW || fh !== outH ? `,pad=${outW}:${outH}:${evenDown((outW - fw) / 2)}:${evenDown((outH - fh) / 2)}:color=black` : '');
  if (maskIdx !== null && maskIdx !== undefined) {
    const F = Math.max(2, Number(blurStrength) || 24);
    const up = blurStyle === 'pixelate' ? 'neighbor' : 'bicubic';
    const apf = tenBit ? 'yuva420p10le' : 'yuva420p';
    const mpf = tenBit ? 'gray10le' : 'gray';
    parts.push(`[${inIdx}:v]${sel},split=2[${t}base][${t}b]`);
    // pixel-format changes are done at the small size, before upscaling (faster)
    parts.push(`[${t}b]scale=w='max(2,trunc(iw/${F}/2)*2)':h='max(2,trunc(ih/${F}/2)*2)':flags=area,` +
      `format=${apf},scale=${srcW}:${srcH}:flags=${up}[${t}bl]`);
    parts.push(`[${maskIdx}:v]setpts=N/25/TB,format=${mpf},scale=${srcW}:${srcH}:flags=bilinear[${t}m]`);
    parts.push(`[${t}bl][${t}m]alphamerge[${t}bla]`);
    parts.push(`[${t}base][${t}bla]overlay=format=${tenBit ? 'yuv420p10' : 'yuv420'}:eof_action=pass${scale}[${label}]`);
  } else {
    parts.push(`[${inIdx}:v]${sel}${scale}[${label}]`);
  }
  return parts;
}

function finish(label, { rate, tenBit, extra = '' }) {
  const pf = tenBit ? 'yuv420p10le' : 'yuv420p';
  return `[${label}]${extra}format=${pf},settb=expr=${rate[1]}/${rate[0]},setpts=N[out]`;
}

// A clip's own part: blur, optional fade from/to black at its ends.
function buildGraph({ keep, pick, useMask, blurStrength, blurStyle, srcW, srcH, outW, outH, fitW, fitH, rate, tenBit, fadeIn = 0, fadeOut = 0, count = 0, rot = 0 }) {
  const parts = buildChain({ inIdx: 0, maskIdx: useMask ? 1 : null, keep, pick, blurStrength, blurStyle, srcW, srcH, outW, outH, fitW, fitH, tenBit, label: 'v', rot });
  let extra = '';
  if (fadeIn > 0) extra += `fade=t=in:start_frame=0:nb_frames=${fadeIn},`;
  if (fadeOut > 0) extra += `fade=t=out:start_frame=${count - fadeOut}:nb_frames=${fadeOut},`;
  parts.push(finish('v', { rate, tenBit, extra }));
  return parts.join(';');
}

// Crossfade part: the last K frames of A dissolve into the first K frames of B.
// Frame i shows (1 - i/K) of A and i/K of B.
function buildCrossGraph({ a, b, K, blurStrength, blurStyle, outW, outH, rate, tenBit }) {
  const parts = [
    ...buildChain({ ...a, blurStrength, blurStyle, outW, outH, tenBit, label: 'xa' }),
    ...buildChain({ ...b, blurStrength, blurStyle, outW, outH, tenBit, label: 'xb' }),
    // both streams are exactly 25 "fps" after re-numbering; fps= only sets the
    // rate xfade checks (with a 1/25 time base it keeps every frame, incl. the last)
    '[xa]settb=1/25,setpts=N,fps=25[xa2]', '[xb]settb=1/25,setpts=N,fps=25[xb2]',
    `[xa2][xb2]xfade=transition=fade:duration=${(K / 25).toFixed(6)}:offset=0[xx]`,
    finish('xx', { rate, tenBit }),
  ];
  return parts.join(';');
}

function nvenccArgs(clip, s, outFile, kbps, tenBit) {
  const c = colorFlags(clip);
  const a = ['--y4m', '-i', '-', '-c', 'hevc', '--profile', tenBit ? 'main10' : 'main',
    '--output-depth', tenBit ? '10' : '8', '-u', s.nvenccPreset || 'quality',
    '--vbr', String(kbps), '--max-bitrate', String(Math.round(kbps * 1.5)),
    '--multipass', '2pass-full', '--lookahead', '32'];
  if (c.prim) a.push('--colorprim', c.prim);
  if (c.trc) a.push('--transfer', c.trc);
  if (c.mat) a.push('--colormatrix', c.mat);
  a.push('--colorrange', 'limited');
  if (clip.masterDisplay) a.push('--master-display', clip.masterDisplay);
  if (clip.maxCll) a.push('--max-cll', clip.maxCll);
  a.push('--repeat-headers', '--aud', '-o', outFile);
  return a;
}

function x265Args(clip, kbps, tenBit) {
  const c = colorFlags(clip);
  const p = [];
  if (c.prim) p.push(`colorprim=${c.prim}`);
  if (c.trc) p.push(`transfer=${c.trc}`);
  if (c.mat) p.push(`colormatrix=${c.mat}`);
  p.push('range=limited');
  if (clip.masterDisplay) p.push(`master-display=${clip.masterDisplay}`);
  if (clip.maxCll) p.push(`max-cll=${clip.maxCll}`);
  if (clip.isPQ) p.push('hdr10=1');
  p.push('repeat-headers=1', 'aud=1', `vbv-maxrate=${Math.round(kbps * 1.5)}`, `vbv-bufsize=${Math.round(kbps * 2)}`);
  return ['-c:v', 'libx265', '-preset', 'medium', '-b:v', `${kbps}k`, '-profile:v', tenBit ? 'main10' : 'main',
    '-x265-params', p.join(':')];
}

async function ffmpegHasFilter(paths, name) {
  const r = await proc.capture(paths.ffmpeg, ['-hide_banner', '-filters'], { allowFail: true });
  return new RegExp(`\\s${name}\\s`).test(r.stdout);
}

async function countFrames(paths, file) {
  const r = await proc.capture(paths.ffprobe, ['-v', 'error', '-select_streams', 'v:0', '-count_packets',
    '-show_entries', 'stream=nb_read_packets', '-of', 'csv=p=0', file]);
  const m = /\d+/.exec(r.stdout);
  return m ? Number(m[0]) : NaN;
}

async function exportProject(paths, project, settings, outPath, onProgress = () => {}) {
  proc.resetCancel();
  const stamp0 = new Date().toISOString().replace(/[:.]/g, '-');
  const work = path.join(paths.workDir, `export-${stamp0}`);
  try {
    return await runExport(paths, project, settings, outPath, onProgress, work);
  } catch (e) {
    log.error(`Export stopped: ${e.message}`);
    // a half-written output file is useless and confusing
    if (fs.existsSync(outPath) && !e.keepOutput) {
      try { fs.unlinkSync(outPath); log.file(`Removed incomplete ${outPath}`); } catch (_) { /* ignore */ }
    }
    throw e;
  } finally {
    if (!process.env.HDRCE_KEEP_TEMP) {
      try { fs.rmSync(work, { recursive: true, force: true }); log.file(`Removed temporary folder ${work}`); } catch (_) { /* ignore */ }
    }
  }
}

async function runExport(paths, project, settings, outPath, onProgress, work) {
  const s = settings;
  fs.mkdirSync(work, { recursive: true });
  log.info(`=== Export started -> ${outPath}`);
  log.info(`Settings: ${JSON.stringify(s)}`);
  log.info(`Temporary folder: ${work}`);

  // ---- plan --------------------------------------------------------------
  const plan = [];
  for (const [i, c] of project.clips.entries()) {
    const keep = tl.keepRanges(c.info.nFrames, c.removed);
    if (!keep.length) { log.info(`Clip ${i + 1} (${path.basename(c.info.path)}): everything cut, skipped`); continue; }
    const rot = normRot(c.rot);
    if (rot) log.info(`Clip ${i + 1} (${path.basename(c.info.path)}): turned ${rot === 180 ? 'upside down' : `90° ${rot === 90 ? 'right' : 'left'}`}`);
    plan.push({ i, c, keep, rot, kept: tl.keptCount(keep), dims: outDims(c.info, s.outHeight, rot) });
  }
  if (!plan.length) throw new Error('Nothing to export: every frame of every clip is cut.');
  // Output size: the biggest clip (after turning), or the chosen resolution.
  // Every other clip is scaled to fit it, with black bars if its shape differs.
  const big = plan.reduce((m, p) => (p.dims.w * p.dims.h > m.dims.w * m.dims.h ? p : m), plan[0]);
  const D = { ...big.dims };
  for (const p of plan) {
    const t = turnedSize(p.c.info, p.rot);
    p.fit = fitInto(t, D.w, D.h);
    p.dims = D;
    const name = path.basename(p.c.info.path);
    if (p.fit.w !== t.w || p.fit.h !== t.h) log.info(`${name}: ${t.w}x${t.h} scaled ${p.fit.w > t.w ? 'up' : 'down'} to ${p.fit.w}x${p.fit.h}`);
    if (p.fit.w !== D.w || p.fit.h !== D.h) log.info(`${name}: different shape than the ${D.w}x${D.h} output, black bars added`);
  }
  const tr = (p) => `${p.c.info.colorTransfer}/${p.c.info.bitDepth}`;
  if (plan.some((p) => tr(p) !== tr(plan[0]))) {
    throw new Error('Clips can only be joined if they are all the same type (all HDR10+/HDR10 or all SDR). ' +
      plan.map((p) => `${path.basename(p.c.info.path)}: ${p.c.info.colorTransfer}, ${p.c.info.bitDepth}-bit`).join(', '));
  }
  const tenBit = plan[0].c.info.bitDepth > 8;
  const withHdr10p = plan.filter((p) => p.c.info.hasHdr10Plus).length;
  if (withHdr10p && withHdr10p !== plan.length) {
    log.warn(`${plan.length - withHdr10p} of ${plan.length} clips have no HDR10+ metadata; those parts will be plain HDR10.`);
  }

  // ---- every kept frame, its on-screen time, and the transitions ---------
  for (const p of plan) {
    const info = p.c.info;
    p.speeds = tl.normSpeeds(p.c.speeds);
    p.frames = [];
    for (const [a, b] of p.keep) for (let f = a; f <= b; f++) p.frames.push(f);
    p.dur = p.frames.map((f) => tl.frameDur(info.times, info.lastDur, f) / tl.speedAt(p.speeds, f));
    p.len = p.dur.reduce((x, y) => x + y, 0);
    p.head = 0; p.tail = 0; p.fadeIn = 0; p.fadeOut = 0;
  }

  // ---- one fixed frame rate for the whole video (optional) ---------------
  // Every 1/F s the output shows the source frame that is on screen at that
  // moment (like a camera filming the original playback): a 60 fps clip in a
  // 30 fps video shows every other frame, a slowed frame is shown for as many
  // 1/F steps as it lasts. Each frame's step is
  //   slot = floor(outputTime * F + 0.501)
  // (the nearest step; exactly halfway goes to the later step) and a step shows
  // the last frame whose slot is not after it (exactly what ffmpeg's fps filter
  // does with frames placed on those steps). The sound is not moved, so it is
  // within half a frame step of the picture everywhere.
  const cfr = s.fpsMode === 'lowest'
    ? plan.map((p) => tl.clipRate(p.c.info.nominalFps || p.c.info.avgFps, p.c.info.avgFps)).reduce((m, r) => (r[0] / r[1] < m[0] / m[1] ? r : m))
    : null;
  if (cfr) {
    const [Fn, Fd] = cfr;
    log.info(`Frame rate: the whole video at ${tl.rateLabel(cfr)} fps (the lowest of the clips)`);
    for (const p of plan) {
      const info = p.c.info;
      // pieces = parts with one speed; output time inside a piece is linear in the source time
      const pieces = [];
      let O = 0;
      p.pieceOf = [];
      p.frames.forEach((f, i) => {
        const sp = tl.speedAt(p.speeds, f);
        const prev = pieces[pieces.length - 1];
        if (!prev || f !== p.frames[i - 1] + 1 || sp !== prev.s) pieces.push({ ta: info.times[f], O, s: sp, first: i });
        p.pieceOf.push(pieces.length - 1);
        O += p.dur[i];
      });
      p.pieces = pieces;
      p.slot = p.frames.map((f, i) => {
        const pc = pieces[p.pieceOf[i]];
        return Math.max(0, Math.floor((pc.O + (info.times[f] - pc.ta) / pc.s) * Fn / Fd + 0.501));
      });
      const S = Math.max(p.slot[p.slot.length - 1] + 1, Math.round(p.len * Fn / Fd));
      p.outIdx = [];
      for (let k = 0, i = 0; k < S; k++) {
        while (i + 1 < p.frames.length && p.slot[i + 1] <= k) i++;
        p.outIdx.push(i);
      }
      p.srcFrames = p.frames;
      const used = new Set(p.outIdx).size;
      log.info(`${path.basename(info.path)}: ${p.frames.length} frames (${tl.rateLabel(tl.clipRate(info.nominalFps || info.avgFps, info.avgFps))} fps) -> ${S} frames at ${tl.rateLabel(cfr)} fps` +
        ` (${p.frames.length - used} dropped, ${S - used} repeats for slow motion / gaps)`);
      p.frames = p.outIdx.map((i) => p.srcFrames[i]);
      p.dur = p.frames.map(() => Fd / Fn);
      p.len = S * Fd / Fn;
    }
  }
  // ffmpeg filters that pick the source frames for output steps k0..k1-1 of a clip (fixed frame rate)
  const cfrPick = (p, k0, k1) => {
    const [Fn, Fd] = cfr;
    const info = p.c.info;
    const i0 = p.outIdx[k0], i1 = p.outIdx[k1 - 1];
    const fr = p.srcFrames.slice(i0, i1 + 1);
    // output step of every selected frame, from its own timestamp (T, seconds), piece by piece
    const byPiece = new Map();
    for (let i = i0; i <= i1; i++) {
      const j = p.pieceOf[i];
      const g = byPiece.get(j) || { lo: Infinity, hi: -Infinity };
      const t = info.times[p.srcFrames[i]];
      g.lo = Math.min(g.lo, t); g.hi = Math.max(g.hi, t);
      byPiece.set(j, g);
    }
    const count = k1 - k0;
    // a copy of the last frame, placed after the part, makes fps emit the real last
    // frame too (it never emits the final frame it gets); trim cuts the copy off
    let expr = String(count + 1);
    for (const [j, g] of [...byPiece.entries()].reverse()) {
      const pc = p.pieces[j];
      const e = `max(0,floor((${pc.O.toFixed(9)}+(T-${pc.ta.toFixed(9)})/${pc.s})*${Fn}/${Fd}+0.501)-${k0})`;
      expr = `if(between(T,${(g.lo - 1e-4).toFixed(6)},${(g.hi + 1e-4).toFixed(6)}),${e},${expr})`;
    }
    // the step is worked out on the frame's own exact time, then the time base becomes 1/F
    return `select='${selectExpr(rangesOf(fr))}',tpad=stop_mode=clone:stop=1,setpts='(${expr})*${Fd}/(${Fn}*TB)',settb=expr=${Fd}/${Fn},` +
      `fps=${Fn}/${Fd},trim=end_frame=${count},settb=1/25,setpts=N`;
  };
  // number of frames at the start (dir=1) or end (dir=-1) of a clip that cover `sec` seconds
  const framesFor = (p, sec, dir) => {
    let t = 0, n = 0;
    const L = p.frames.length;
    while (n < L && t < sec - 1e-9) { t += p.dur[dir > 0 ? n : L - 1 - n]; n++; }
    return n;
  };
  const sumDur = (p, from, n) => p.dur.slice(from, from + n).reduce((x, y) => x + y, 0);
  const trans = []; // trans[k]: from plan[k-1] into plan[k]
  for (let k = 1; k < plan.length; k++) {
    const t = plan[k].c.transIn;
    if (!t || !t.type || t.type === 'none' || !(Number(t.dur) > 0)) continue;
    const A = plan[k - 1], B = plan[k], dur = Number(t.dur);
    if (t.type === 'black') {
      A.fadeOut = Math.max(1, Math.min(framesFor(A, dur / 2, -1), A.frames.length - A.fadeIn));
      B.fadeIn = Math.max(1, Math.min(framesFor(B, dur / 2, 1), B.frames.length));
      trans[k] = { type: 'black', dur };
      log.info(`Transition ${k}->${k + 1}: fade through black, ${A.fadeOut} frames out + ${B.fadeIn} frames in`);
    } else if (t.type === 'cross') {
      let K = framesFor(B, dur, 1);
      K = Math.min(K, B.frames.length - 1, A.frames.length - A.head - 1);
      if (K < 2) { log.warn(`Transition ${k}->${k + 1}: clips too short for a crossfade, joined without one`); continue; }
      A.tail = K; B.head = K;
      trans[k] = { type: 'cross', dur, K, dA: sumDur(A, A.frames.length - K, K), dB: sumDur(B, 0, K) };
      log.info(`Transition ${k}->${k + 1}: crossfade over ${K} frames (${trans[k].dB.toFixed(3)} s); no frames are dropped, they overlap`);
    }
  }
  const totalOut = plan.reduce((x, p) => x + p.frames.length, 0) - trans.reduce((x, t) => x + (t && t.type === 'cross' ? t.K : 0), 0);
  log.info(`Output ${D.w}x${D.h}, ${totalOut} frames from ${plan.length} clip(s), encoder=${s.encoder}`);

  let doneFrames = 0;
  const report = (stage, frac) => onProgress({ stage, overall: Math.min(0.97, (doneFrames + frac) / totalOut * 0.95) });

  const videoParts = [];
  const audioParts = [];
  const expectedFp = [];
  const tsLines = [];
  let lastFrameMs = 0; // how long the very last output frame should be shown
  let tOffset = 0;
  let hasRubberband;
  const anyAudio = plan.some((p) => p.c.info.audio.length);
  const firstAudio = (plan.find((p) => p.c.info.audio.length) || {}).c?.info.audio[0];
  const pushTimes = (durs) => {
    for (const d of durs) { tsLines.push((tOffset * 1000).toFixed(6)); tOffset += d; lastFrameMs = d * 1000; }
  };
  const rangesOf = (fr) => {
    const r = [];
    for (const f of fr) { const l = r[r.length - 1]; if (l && f === l[1] + 1) l[1] = f; else r.push([f, f]); }
    return r;
  };
  const kbpsFor = (p) => (s.bitrateMode === 'fixed'
    ? Math.max(500, Number(s.bitrateKbps) || 40000)
    : Math.max(2000, Math.round((p.c.info.videoBitrate / 1000) * (p.fit.w * p.fit.h) / (p.c.info.dispW * p.c.info.dispH))));
  const hw = (h) => h; // readability below

  // Encodes one part (filter graph -> HEVC), checks its frame count, adds HDR10+.
  async function encodePart({ tag, inputs, graph, info, kbps, rate, count, entries, template }) {
    const hevc = path.join(work, `${tag}.hevc`);
    const onFf = (l) => {
      const m = /frame=\s*(\d+)/.exec(l);
      if (m) report(`${tag}: encoding (${s.encoder === 'x265' ? 'CPU x265' : 'GPU NVEncC'}) ${m[1]}/${count}`,
        0.05 * count + Math.min(1, Number(m[1]) / count) * 0.85 * count);
    };
    log.info(`${tag}: ${count} frames, ${kbps} kbps, encoder rate ${rate[0]}/${rate[1]}, filter graph: ${graph}`);
    await withHwFallback(paths, `${tag} encode`, async (hwArgs) => {
      const inArgs = ['-hide_banner', '-nostdin', '-y'];
      if (cfr) inArgs.push('-copyts');
      for (const inp of inputs) { if (inp.video) inArgs.push(...hw(hwArgs)); inArgs.push('-i', inp.file); }
      const common = [...inArgs, '-filter_complex', graph, '-map', '[out]', '-an', '-sn', '-dn', '-fps_mode', 'passthrough'];
      if (s.encoder === 'x265') {
        await proc.run(paths.ffmpeg, [...common, ...x265Args(info, kbps, tenBit), '-f', 'hevc', hevc], { onStderrLine: onFf });
      } else {
        await proc.pipe(
          { bin: paths.ffmpeg, args: [...common, '-pix_fmt', tenBit ? 'yuv420p10le' : 'yuv420p', '-f', 'yuv4mpegpipe', '-strict', '-1', '-'] },
          { bin: paths.nvencc, args: nvenccArgs(info, s, hevc, kbps, tenBit) },
          { onStderrLine: onFf },
          { onStderrLine: (l) => { if (/error|fail|invalid|unknown option/i.test(l)) log.warn(`NVEncC: ${l}`); } });
      }
    });
    const got = await countFrames(paths, hevc);
    if (got !== count) throw new Error(`${tag}: encoder produced ${got} frames, expected ${count}. Export stopped so nothing is out of sync.`);
    log.info(`${tag}: encoded ${got} frames OK`);
    if (entries && template) {
      report(`${tag}: adding HDR10+ metadata`, 0.92 * count);
      const json = await h10.writeEntries(paths, entries, template, path.join(work, `${tag}_hdr10plus.json`));
      expectedFp.push(...h10.fingerprints(json));
      const withMeta = path.join(work, `${tag}_hdr10plus.hevc`);
      await h10.inject(paths, hevc, json, withMeta);
      fs.unlinkSync(hevc);
      videoParts.push(withMeta);
    } else {
      for (let n = 0; n < count; n++) expectedFp.push(null);
      videoParts.push(hevc);
    }
  }

  async function maskFor(p, tag, frames) {
    if (!mask.hasAnyBox(p.c.tracks || [], rangesOf([...new Set(frames)].sort((a, b) => a - b)))) return null;
    report(`${tag}: drawing blur mask`, 0);
    const m = await mask.renderMask(paths, p.c.info, p.c.tracks, frames, Number(s.padPct) || 0,
      path.join(work, `${tag}_mask.mkv`), (f) => report(`${tag}: drawing blur mask`, f * frames.length * 0.05));
    return m.file;
  }

  for (const [k, p] of plan.entries()) {
    const { c } = p;
    const info = c.info;
    const name = path.basename(info.path);
    const tag = `clip${k + 1}`;
    const L = p.frames.length;
    log.info(`--- ${tag}: ${name}, keeping ${L}/${info.nFrames} frames in ${p.keep.length} part(s): ${JSON.stringify(p.keep)}`);

    // HDR10+ metadata for every kept frame of this clip
    p.entries = null; p.template = null;
    if (info.hasHdr10Plus) {
      let src = c.hdr10plusJson;
      if (!src || !fs.existsSync(src)) src = await h10.extract(paths, info.path, path.join(work, `${tag}_hdr10plus_src.json`));
      if (src) {
        const conf = await h10.conformLength(paths, src, info.nFrames, path.join(work, `${tag}_hdr10plus_full.json`));
        const full = h10.readJson(conf);
        p.template = full;
        p.entries = p.frames.map((f) => full.SceneInfo[f]);
      }
    }

    // 1) the clip's own part (minus frames that go into crossfades)
    const mainIdx = [];
    for (let i = p.head; i < L - p.tail; i++) mainIdx.push(i);
    const mainFrames = mainIdx.map((i) => p.frames[i]);
    const fadeIn = p.head ? 0 : Math.min(p.fadeIn, mainFrames.length);
    const fadeOut = p.tail ? 0 : Math.min(p.fadeOut, mainFrames.length - fadeIn);
    const maskFile = await maskFor(p, tag, mainFrames);
    if (!maskFile) log.info(`${tag}: no plates in these frames, no blur needed`);
    const rate = cfr || tl.nearestStdRate(info.avgFps);
    const graph = buildGraph({ keep: rangesOf(mainFrames), pick: cfr ? cfrPick(p, p.head, L - p.tail) : null, useMask: !!maskFile, blurStrength: s.blurStrength, blurStyle: s.blurStyle,
      srcW: info.dispW, srcH: info.dispH, outW: p.dims.w, outH: p.dims.h, fitW: p.fit.w, fitH: p.fit.h, rate, tenBit, fadeIn, fadeOut, count: mainFrames.length, rot: p.rot });
    let entries = null;
    if (p.entries) {
      entries = mainIdx.map((i, j) => {
        let e = p.entries[i];
        if (j < fadeIn) e = h10.fadeEntry(e, j / fadeIn);
        else if (j >= mainFrames.length - fadeOut) e = h10.fadeEntry(e, 1 - (j - (mainFrames.length - fadeOut)) / fadeOut);
        return e;
      });
    }
    if (fadeIn || fadeOut) log.info(`${tag}: fade from black over ${fadeIn} frame(s), to black over ${fadeOut} frame(s)`);
    await encodePart({ tag, inputs: [{ file: info.path, video: true }, ...(maskFile ? [{ file: maskFile }] : [])],
      graph, info, kbps: kbpsFor(p), rate, count: mainFrames.length, entries, template: p.template });
    if (maskFile) fs.unlinkSync(maskFile);
    pushTimes(mainIdx.map((i) => p.dur[i]));
    doneFrames += mainFrames.length;

    // 2) crossfade into the next clip
    const tn = trans[k + 1];
    if (tn && tn.type === 'cross') {
      const B = plan[k + 1];
      const ttag = `cross${k + 1}-${k + 2}`;
      // B's HDR10+ is needed now, read it ahead
      if (B.c.info.hasHdr10Plus && !B.entries) {
        let src = B.c.hdr10plusJson;
        if (!src || !fs.existsSync(src)) src = await h10.extract(paths, B.c.info.path, path.join(work, `${ttag}_b_src.json`));
        if (src) {
          const full = h10.readJson(await h10.conformLength(paths, src, B.c.info.nFrames, path.join(work, `${ttag}_b_full.json`)));
          B.template = full; B.entries = B.frames.map((f) => full.SceneInfo[f]);
        }
      }
      const K = tn.K;
      const aFrames = p.frames.slice(L - K), bFrames = B.frames.slice(0, K);
      const mA = await maskFor(p, `${ttag}a`, aFrames);
      const mB = await maskFor(B, `${ttag}b`, bFrames);
      const inputs = [{ file: info.path, video: true }, { file: B.c.info.path, video: true }];
      if (mA) inputs.push({ file: mA });
      if (mB) inputs.push({ file: mB });
      const graphX = buildCrossGraph({
        a: { inIdx: 0, maskIdx: mA ? 2 : null, keep: rangesOf(aFrames), pick: cfr ? cfrPick(p, L - K, L) : null, srcW: info.dispW, srcH: info.dispH, rot: p.rot, fitW: p.fit.w, fitH: p.fit.h },
        b: { inIdx: 1, maskIdx: mB ? (mA ? 3 : 2) : null, keep: rangesOf(bFrames), pick: cfr ? cfrPick(B, 0, K) : null, srcW: B.c.info.dispW, srcH: B.c.info.dispH, rot: B.rot, fitW: B.fit.w, fitH: B.fit.h },
        K, blurStrength: s.blurStrength, blurStyle: s.blurStyle, outW: p.dims.w, outH: p.dims.h,
        rate: cfr || tl.nearestStdRate(B.c.info.avgFps), tenBit });
      let xEntries = null;
      if (p.entries && B.entries) {
        xEntries = [];
        for (let i = 0; i < K; i++) xEntries.push(h10.blendEntry(p.entries[L - K + i], B.entries[i], 1 - i / K));
      } else if (p.entries || B.entries) {
        log.warn(`${ttag}: only one of the two clips has HDR10+, so the crossfade itself is plain HDR10`);
      }
      await encodePart({ tag: ttag, inputs, graph: graphX, info: B.c.info, kbps: Math.max(kbpsFor(p), kbpsFor(B)),
        rate: cfr || tl.nearestStdRate(B.c.info.avgFps), count: K, entries: xEntries, template: B.template || p.template });
      [mA, mB].forEach((m) => m && fs.unlinkSync(m));
      pushTimes(B.dur.slice(0, K)); // shown with B's timing, so B stays in sync afterwards
      doneFrames += K;
    }

    // 3) audio for this clip's frames (slowed the same way as the video)
    const speeds = p.speeds;
    const pieces = [];
    for (const [a, b] of p.keep) {
      let pa = a;
      for (let f = a; f <= b; f++) {
        const sp = tl.speedAt(speeds, f);
        if (f === b || tl.speedAt(speeds, f + 1) !== sp) { pieces.push([pa, f, sp]); pa = f + 1; }
      }
    }
    const srcEnd = (f) => (f + 1 < info.nFrames ? info.times[f + 1] : info.times[f] + info.lastDur);
    const slowPieces = pieces.filter((x) => x[2] < 1);
    if (slowPieces.length) {
      log.info(`${tag}: slow motion on ${slowPieces.length} part(s): ` +
        slowPieces.map(([a, b, sp]) => `frames ${a}-${b} at 1/${+(1 / sp).toFixed(2)}`).join(', ') +
        `; audio there is ${s.slowAudio === 'mute' ? 'silent' : s.slowAudio === 'tape' ? 'slowed down and deeper' : 'slowed down (pitch kept)'}`);
    }
    if (anyAudio && slowPieces.length && hasRubberband === undefined) {
      hasRubberband = await ffmpegHasFilter(paths, 'rubberband');
      if (!hasRubberband && s.slowAudio !== 'mute' && s.slowAudio !== 'tape') {
        log.warn('This ffmpeg has no rubberband filter; using atempo for slowed audio (timing is less exact)');
      }
    }
    if (anyAudio) {
      report(`${tag}: cutting audio`, 0);
      const wav = path.join(work, `${tag}.wav`);
      const segs = pieces.map(([a, b, sp]) => [info.times[a], srcEnd(b), sp]);
      // sound fades with the picture for "fade through black"
      const aIn = p.fadeIn ? sumDur(p, 0, p.fadeIn) : 0;
      const aOut = p.fadeOut ? sumDur(p, L - p.fadeOut, p.fadeOut) : 0;
      // with one fixed frame rate the clip's video is a fraction of a frame longer or shorter
      const fit = cfr ? `,apad=whole_dur=${p.len.toFixed(6)},atrim=end=${p.len.toFixed(6)}` : '';
      const afade = fit + (aIn ? `,afade=t=in:st=0:d=${aIn.toFixed(6)}` : '') +
        (aOut ? `,afade=t=out:st=${(p.len - aOut).toFixed(6)}:d=${aOut.toFixed(6)}` : '');
      if (info.audio.length) {
        const fc = [`[0:a:0]asplit=${segs.length}${segs.map((_, j) => `[s${j}]`).join('')}`];
        segs.forEach(([st, en, sp], j) => {
          let chain = `[s${j}]atrim=start=${st.toFixed(6)}:end=${en.toFixed(6)},asetpts=PTS-STARTPTS`;
          if (sp < 1) {
            const d = ((en - st) / sp).toFixed(6);
            const sr = info.audio[0].sampleRate || 48000;
            let slow;
            if (s.slowAudio === 'mute') slow = `asetrate=${Math.round(sr * sp)},aresample=${sr},volume=0`;
            else if (s.slowAudio === 'tape') slow = `asetrate=${Math.round(sr * sp)},aresample=${sr}`; // deeper, like a slowed tape
            else slow = hasRubberband ? `rubberband=tempo=${sp}:window=short` : tl.atempoChain(sp); // same pitch, slower (short window keeps sharp sounds sharp)
            // padded/trimmed to exactly the slowed video length
            chain += `,${slow},apad=whole_dur=${d},atrim=end=${d}`;
          }
          fc.push(`${chain}[a${j}]`);
        });
        fc.push(`${segs.map((_, j) => `[a${j}]`).join('')}concat=n=${segs.length}:v=0:a=1${afade}[aout]`);
        await proc.run(paths.ffmpeg, ['-hide_banner', '-nostdin', '-y', '-copyts', '-i', info.path,
          '-filter_complex', fc.join(';'), '-map', '[aout]', '-c:a', 'pcm_s24le', wav]);
      } else {
        log.info(`${tag}: no audio track, inserting ${p.len.toFixed(3)} s of silence to keep the join in sync`);
        await proc.run(paths.ffmpeg, ['-hide_banner', '-nostdin', '-y', '-f', 'lavfi', '-i',
          `anullsrc=r=${firstAudio.sampleRate}:cl=stereo`, '-t', p.len.toFixed(6), '-c:a', 'pcm_s24le', wav]);
      }
      audioParts.push({ wav, len: p.len });
    }
    report(`${tag}: done`, 0);
  }
  const totalKept = totalOut;

  // ---- join + mux -------------------------------------------------------
  onProgress({ stage: 'Joining and writing the final file', overall: 0.96 });
  const allHevc = path.join(work, 'video.hevc');
  if (videoParts.length === 1) fs.renameSync(videoParts[0], allHevc);
  else {
    const out = fs.createWriteStream(allHevc);
    for (const v of videoParts) {
      await new Promise((res, rej) => { const r = fs.createReadStream(v); r.on('error', rej); r.on('end', res); r.pipe(out, { end: false }); });
      fs.unlinkSync(v);
    }
    await new Promise((res) => out.end(res));
  }
  log.file(`Joined video: ${allHevc} (${videoParts.length} part(s))`);
  const tsFile = path.join(work, 'timestamps.txt');
  fs.writeFileSync(tsFile, '# timestamp format v2\n' + tsLines.join('\n') + '\n');
  log.file(`Timestamps: ${tsFile} (${tsLines.length} frames, ${tOffset.toFixed(3)} s)`);

  const ref = plan[0].c.info;
  const mkvArgs = ['-o', path.join(work, 'video.mkv'), '--timestamps', `0:${tsFile}`];
  const cp = H273_PRIM[ref.colorPrimaries], ct = H273_TRC[ref.colorTransfer], cm = H273_MAT[ref.colorSpace];
  if (cm) mkvArgs.push('--colour-matrix', `0:${cm}`);
  mkvArgs.push('--colour-range', '0:1');
  if (ct) mkvArgs.push('--colour-transfer-characteristics', `0:${ct}`);
  if (cp) mkvArgs.push('--colour-primaries', `0:${cp}`);
  if (ref.maxCll) {
    const [mc, mf] = ref.maxCll.split(',');
    mkvArgs.push('--max-content-light', `0:${mc}`, '--max-frame-light', `0:${mf}`);
  }
  const md = /G\((\d+),(\d+)\)B\((\d+),(\d+)\)R\((\d+),(\d+)\)WP\((\d+),(\d+)\)L\((\d+),(\d+)\)/.exec(ref.masterDisplay || '');
  if (md) {
    const c = (v) => (Number(v) / 50000).toFixed(5);
    mkvArgs.push('--chromaticity-coordinates', `0:${c(md[5])},${c(md[6])},${c(md[1])},${c(md[2])},${c(md[3])},${c(md[4])}`,
      '--white-colour-coordinates', `0:${c(md[7])},${c(md[8])}`,
      '--max-luminance', `0:${(Number(md[9]) / 10000).toFixed(4)}`, '--min-luminance', `0:${(Number(md[10]) / 10000).toFixed(4)}`);
  }
  mkvArgs.push(allHevc);
  await proc.run(paths.mkvmerge, mkvArgs, { allowFail: true }).then((r) => {
    // mkvmerge exit 1 = warnings only
    if (r.code !== 0 && r.code !== 1) throw new Error(`mkvmerge failed (exit ${r.code}):\n${r.stderrTail}`);
  });
  fs.unlinkSync(allHevc);

  let audioWav = null;
  if (audioParts.length) {
    audioWav = path.join(work, 'audio.wav');
    const ch = firstAudio.channels || 2;
    const sr = firstAudio.sampleRate || 48000;
    const fc = audioParts.map((_, j) => `[${j}:a]aresample=${sr},aformat=sample_fmts=s32:channel_layouts=${firstAudio.layout || (ch === 1 ? 'mono' : 'stereo')}[x${j}]`);
    // join one by one: plain join, or a crossfade where the pictures crossfade
    let curLab = 'x0', curLen = audioParts[0].len;
    for (let j = 1; j < audioParts.length; j++) {
      const t = trans[j];
      if (t && t.type === 'cross') {
        // the first clip's sound is made to end exactly where the second clip's
        // picture is fully in, then both sounds are crossfaded over that time
        const L1 = curLen - t.dA + t.dB;
        fc.push(`[${curLab}]apad=whole_dur=${L1.toFixed(6)},atrim=end=${L1.toFixed(6)}[p${j}]`);
        fc.push(`[p${j}][x${j}]acrossfade=d=${t.dB.toFixed(6)}:c1=tri:c2=tri[j${j}]`);
        curLen = L1 - t.dB + audioParts[j].len;
      } else {
        fc.push(`[${curLab}][x${j}]concat=n=2:v=0:a=1[j${j}]`);
        curLen += audioParts[j].len;
      }
      curLab = `j${j}`;
    }
    await proc.run(paths.ffmpeg, ['-hide_banner', '-nostdin', '-y', ...audioParts.flatMap((a) => ['-i', a.wav]),
      '-filter_complex', fc.join(';'), '-map', `[${curLab}]`, '-c:a', 'pcm_s24le', audioWav]);
    audioParts.forEach((a) => fs.unlinkSync(a.wav));
    log.info(`Audio joined: ${curLen.toFixed(3)} s (video ${tOffset.toFixed(3)} s)`);
  }

  const isMp4 = (s.container || 'mp4') === 'mp4';
  const aKbps = Number(s.audioKbps) > 0 ? Number(s.audioKbps)
    : Math.max(96, Math.round(((firstAudio && firstAudio.bitrate) || 256000) / 1000));
  const fin = ['-hide_banner', '-nostdin', '-y', '-i', path.join(work, 'video.mkv')];
  if (audioWav) fin.push('-i', audioWav);
  fin.push('-map', '0:v:0');
  if (audioWav) fin.push('-map', '1:a:0', '-c:a', 'aac', '-b:a', `${aKbps}k`);
  fin.push('-c:v', 'copy');
  // mkvmerge gives the last frame the clip's most common frame length, which
  // is wrong after slow motion; set the real one (timestamps untouched).
  const lastPts = Math.floor(Number(tsLines[tsLines.length - 1]) - 0.5);
  fin.push('-bsf:v', `setts=pts=PTS:dts=DTS:duration='if(gte(PTS,${lastPts}),${Math.max(1, Math.round(lastFrameMs))},DURATION)'`);
  if (isMp4) fin.push('-tag:v', 'hvc1', '-movflags', '+faststart');
  fin.push(outPath);
  await proc.run(paths.ffmpeg, fin);
  log.file(`Final file written: ${outPath}`);

  // ---- verify -------------------------------------------------------------
  onProgress({ stage: 'Checking the result', overall: 0.98 });
  const verify = { frames: null, hdr10plus: null, duration: null };
  const outFrames = await countFrames(paths, outPath);
  verify.frames = { expected: totalKept, got: outFrames, ok: outFrames === totalKept };
  const wantFp = expectedFp.filter((x) => x !== null);
  if (wantFp.length) {
    const vj = path.join(work, 'verify_hdr10plus.json');
    // hdr10plus_tool refuses a file whose first frames have no HDR10+, so when
    // the video starts with a clip without it, the check starts at the first
    // part that has it (every part starts on a keyframe).
    const n0 = expectedFp.findIndex((x) => x !== null);
    let src = outPath;
    if (n0 > 0) {
      src = path.join(work, 'verify_from_hdr10plus.mkv');
      await proc.run(paths.ffmpeg, ['-hide_banner', '-nostdin', '-y', '-ss', (Number(tsLines[n0]) / 1000 + 0.001).toFixed(6),
        '-i', outPath, '-map', '0:v:0', '-c', 'copy', src]);
    }
    const got = await h10.extract(paths, src, vj);
    if (n0 > 0) fs.rmSync(src, { force: true });
    if (!got) verify.hdr10plus = { ok: false, msg: 'no HDR10+ metadata found in the output' };
    else {
      const fp = h10.fingerprints(vj);
      const exp = expectedFp.slice(n0);
      let mism = 0, first = -1;
      // Parts without HDR10+ carry no entries. hdr10plus_tool extract fills such
      // gaps with a neighbouring entry, so then only the frames that should
      // carry HDR10+ are compared, at their own positions.
      const filled = fp.length === exp.length;
      const want = filled ? exp : wantFp;
      for (let n = 0; n < Math.max(fp.length, want.length); n++) {
        if (want[n] === null) continue;
        if (fp[n] !== want[n]) { mism++; if (first < 0) first = n + (filled ? n0 : 0); }
      }
      verify.hdr10plus = { ok: mism === 0 && fp.length === want.length, frames: wantFp.length, mismatches: mism, firstMismatch: first };
    }
  }
  verify.duration = { expected: +tOffset.toFixed(3) };
  log.info(`Verify: ${JSON.stringify(verify)}`);
  if (!verify.frames.ok) throw new Error(`Output has ${outFrames} frames, expected ${totalKept}.`);
  if (verify.hdr10plus && !verify.hdr10plus.ok) {
    const e = new Error(`The file was written, but the HDR10+ check failed: ${JSON.stringify(verify.hdr10plus)}`);
    e.keepOutput = true;
    throw e;
  }
  log.info(`=== Export finished: ${outPath}`);
  onProgress({ stage: 'Done', overall: 1 });
  return { outPath, verify, frames: totalKept, seconds: tOffset, fps: cfr ? tl.rateLabel(cfr) : null };
}

module.exports = { exportProject, buildGraph, buildCrossGraph, outDims, nvenccArgs, x265Args };
