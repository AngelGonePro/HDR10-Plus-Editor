'use strict';
// Renders the blur mask (white = blur) for a list of source frames of a clip,
// one mask frame per listed frame (a frame may be listed more than once), as a
// small lossless FFV1 video.
const proc = require('./proc');
const log = require('./log');
const tl = require('./timeline');

function maskSize(dispW, dispH) {
  const L = 640;
  const s = Math.min(1, L / Math.max(dispW, dispH));
  const ev = (n) => Math.max(2, Math.round(n / 2) * 2);
  return { w: ev(dispW * s), h: ev(dispH * s) };
}

// Draws an anti-aliased filled rectangle (normalised coords) into buf.
function fillRect(buf, W, H, b) {
  const x0 = b.x * W, y0 = b.y * H, x1 = (b.x + b.w) * W, y1 = (b.y + b.h) * H;
  const ix0 = Math.max(0, Math.floor(x0)), iy0 = Math.max(0, Math.floor(y0));
  const ix1 = Math.min(W - 1, Math.ceil(x1) - 1), iy1 = Math.min(H - 1, Math.ceil(y1) - 1);
  for (let y = iy0; y <= iy1; y++) {
    const cy = Math.min(y + 1, y1) - Math.max(y, y0);
    if (cy <= 0) continue;
    const o = y * W;
    for (let x = ix0; x <= ix1; x++) {
      const cx = Math.min(x + 1, x1) - Math.max(x, x0);
      if (cx <= 0) continue;
      const v = Math.round(255 * cx * cy);
      if (v > buf[o + x]) buf[o + x] = v;
    }
  }
}

// Returns number of kept frames that have at least one box.
function hasAnyBox(tracks, keep) {
  for (const t of tracks) {
    const r = tl.trackRange(t);
    if (!r) continue;
    for (const [a, b] of keep) if (r[0] <= b && r[1] >= a) return true;
  }
  return false;
}

async function renderMask(paths, clip, tracks, frameList, padPct, outFile, onProgress) {
  const { w, h } = maskSize(clip.dispW, clip.dispH);
  const prepared = tracks.map((t) => ({ t, frames: tl.sortedKeyFrames(t) })).filter((p) => p.frames.length);
  const total = frameList.length;
  const { child, done } = proc.start(paths.ffmpeg, ['-hide_banner', '-nostdin', '-y', '-v', 'error',
    '-f', 'rawvideo', '-pix_fmt', 'gray', '-s', `${w}x${h}`, '-framerate', '25', '-i', '-',
    '-c:v', 'ffv1', '-level', '3', '-g', '1', outFile], { stdin: 'pipe', stdout: 'ignore' });
  const stdin = child.stdin;
  stdin.on('error', () => { /* reported through the exit code */ });
  const write = (b) => new Promise((resolve) => { if (!stdin.write(b)) stdin.once('drain', resolve); else resolve(); });
  let n = 0, boxed = 0;
  let last = null, lastBuf = null;
  for (const f of frameList) {
    proc.checkCancel();
    if (f !== last) {
      lastBuf = Buffer.alloc(w * h);
      let any = false;
      for (const p of prepared) {
        const box = tl.boxAt(p.t, f, p.frames);
        if (box) { fillRect(lastBuf, w, h, tl.padBox(box, padPct)); any = true; }
      }
      lastBuf.any = any;
      last = f;
    }
    if (lastBuf.any) boxed++;
    await write(lastBuf);
    n++;
    if (onProgress && n % 50 === 0) onProgress(n / total);
  }
  stdin.end();
  await done;
  log.file(`Blur mask written: ${outFile} (${w}x${h}, ${n} frames, ${boxed} with plates)`);
  return { file: outFile, w, h, frames: n, boxed };
}

module.exports = { renderMask, hasAnyBox, maskSize, fillRect };
