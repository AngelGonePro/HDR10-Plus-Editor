'use strict';
// Runs plate tracking on its own thread, so the app window and the Stop button
// stay responsive however heavy a frame is. Stop is a shared flag that the
// tracker checks before every frame.
const { parentPort, workerData } = require('worker_threads');
const log = require('./log');
const proc = require('./proc');
const tracker = require('./tracker');

const stop = new Int32Array(workerData.stop);
// log lines go to the main thread, which writes them to the log file and panel
log.bus.on('line', ({ level, msg }) => parentPort.postMessage({ type: 'log', level, msg }));

parentPort.on('message', async (m) => {
  if (m.type === 'cancelAll') { proc.cancelAll(); return; }
  if (m.type !== 'track') return;
  const { id, paths, proxy, startFrame, box, dir, stopFrame } = m;
  let batch = {};
  let lastSend = Date.now();
  const flush = () => {
    if (Object.keys(batch).length) parentPort.postMessage({ type: 'boxes', id, boxes: batch });
    batch = {};
    lastSend = Date.now();
  };
  try {
    const res = await tracker.track(paths, proxy, startFrame, box, dir, stopFrame, (f, b, conf) => {
      const r5 = (v) => Math.round(v * 1e5) / 1e5;
      batch[f] = { x: r5(b.x), y: r5(b.y), w: r5(b.w), h: r5(b.h), c: +conf.toFixed(3) };
      if (Date.now() - lastSend > 120) flush();
    }, () => {
      // test only: make every frame heavy, like a tiny fast plate on a slow PC
      const slow = Number(process.env.HDRCE_TEST_TRACK_DELAY_MS) || 0;
      if (slow) { const t0 = Date.now(); while (Date.now() - t0 < slow && Atomics.load(stop, 0) !== 1) { /* busy */ } }
      return Atomics.load(stop, 0) === 1;
    });
    flush();
    parentPort.postMessage({ type: 'done', id, res });
  } catch (e) {
    flush();
    parentPort.postMessage({ type: 'error', id, message: e.message });
  }
});
