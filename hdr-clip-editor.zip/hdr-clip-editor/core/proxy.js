'use strict';
// Builds the lightweight SDR preview video used for scrubbing and tracking.
// It has exactly one frame per source frame (same order), so a proxy frame
// index is always the source frame index.
const fs = require('fs');
const path = require('path');
const proc = require('./proc');
const log = require('./log');
const probe = require('./probe');

function even(n) { return Math.max(2, Math.round(n / 2) * 2); }

function proxySize(clip, longEdge) {
  const L = Number(longEdge) || 960;
  const { dispW, dispH } = clip;
  if (dispW >= dispH) return { w: even(L), h: even(L * dispH / dispW) };
  return { w: even(L * dispW / dispH), h: even(L) };
}

function hwArgs(hwaccel) {
  return hwaccel && hwaccel !== 'none' ? ['-hwaccel', hwaccel] : [];
}

// Runs an ffmpeg decode job with hardware decoding, retrying in software if
// the hardware decoder can't be used on this machine.
async function withHwFallback(paths, label, fn) {
  if (!paths.hwaccel || paths.hwaccel === 'none') return fn([]);
  try {
    return await fn(hwArgs(paths.hwaccel));
  } catch (e) {
    if (e.cancelled) throw e;
    // Only retry when ffmpeg itself failed in a way that points at the
    // hardware decoder; other failures (e.g. the encoder) are real errors.
    const fromFfmpeg = /^ffmpeg(\.exe)? failed/i.test(e.message);
    const hwRelated = /hwaccel|cuda|nvdec|cuvid|d3d11|dxva|device creation|hw_frames|hardware|No device available/i.test(e.message);
    if (!(fromFfmpeg && hwRelated)) throw e;
    log.warn(`${label}: hardware decoding (${paths.hwaccel}) failed, retrying with software decoding`);
    return fn([]);
  }
}

function tonemapChain(clip) {
  if (clip.isPQ || clip.isHLG) {
    // HDR -> SDR preview only (the export keeps the original HDR pixels)
    return 'zscale=t=linear:npl=100,format=gbrpf32le,zscale=p=bt709,' +
      'tonemap=tonemap=hable:desat=0,zscale=t=bt709:m=bt709:r=tv,format=yuv420p';
  }
  return 'format=yuv420p';
}

async function makeProxy(paths, clip, outFile, longEdge, onProgress) {
  const { w, h } = proxySize(clip, longEdge);
  const vf = `scale=${w}:${h}:flags=bilinear,${tonemapChain(clip)}`;
  await withHwFallback(paths, 'Preview', (hw) => proc.run(paths.ffmpeg, [
    '-hide_banner', '-nostdin', '-y', ...hw, '-i', clip.path,
    '-map', '0:v:0', '-an', '-sn', '-dn', '-vf', vf, '-fps_mode', 'passthrough',
    '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20', '-g', '12', '-bf', '0',
    '-pix_fmt', 'yuv420p', '-movflags', '+faststart', outFile,
  ], {
    onStderrLine: (l) => {
      const m = /frame=\s*(\d+)/.exec(l);
      if (m && onProgress) onProgress(Math.min(1, Number(m[1]) / clip.nFrames));
    },
  }));
  const pinfo = await probe.probeClip(paths, outFile);
  if (pinfo.nFrames !== clip.nFrames) {
    log.warn(`Preview has ${pinfo.nFrames} frames but source has ${clip.nFrames}. Frame positions in the preview may be slightly off.`);
  }
  log.file(`Preview written: ${outFile} (${w}x${h}, ${pinfo.nFrames} frames)`);
  return { file: outFile, w, h, times: pinfo.times, nFrames: pinfo.nFrames };
}

// Puts the clip's own sound into the preview (so playback has audio). The
// preview's video is copied as is, and the sound keeps exactly the offset it
// has to the picture in the original file. Returns the updated proxy info.
async function addProxyAudio(paths, clip, px) {
  if (!clip.audio.length) return { ...px, audio: false };
  const tmp = px.file.replace(/\.mp4$/, '.av.mp4');
  const off = px.times[0] - clip.times[0]; // original video start -> preview video start
  await proc.run(paths.ffmpeg, [
    '-hide_banner', '-nostdin', '-y', '-i', px.file, '-itsoffset', off.toFixed(6), '-i', clip.path,
    '-map', '0:v:0', '-map', '1:a:0', '-c:v', 'copy', '-c:a', 'aac', '-b:a', '160k', '-ac', '2',
    '-copyts', '-avoid_negative_ts', 'make_zero', '-movflags', '+faststart', tmp,
  ]);
  fs.renameSync(tmp, px.file);
  const pinfo = await probe.probeClip(paths, px.file);
  if (pinfo.nFrames !== px.nFrames) throw new Error(`Adding sound to the preview changed its frame count (${pinfo.nFrames} != ${px.nFrames})`);
  log.file(`Preview sound added: ${px.file}`);
  return { ...px, times: pinfo.times, audio: true };
}

module.exports = { makeProxy, addProxyAudio, proxySize, withHwFallback, hwArgs };
