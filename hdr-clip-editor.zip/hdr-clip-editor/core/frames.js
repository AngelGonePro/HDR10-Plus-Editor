'use strict';
// Streams grayscale frames [a..b] of a preview video for the tracker.
const proc = require('./proc');

// Calls onFrame(index, Uint8Array w*h) for each frame a..b in order.
// onFrame may return a Promise (backpressure) or false to stop early.
async function readGray(paths, proxy, a, b, onFrame) {
  const { w, h } = proxy;
  const size = w * h;
  // Seek near frame a (fast, keyframe accurate) then select exact frames by
  // their timestamp; -copyts keeps the original timestamps.
  const ta = proxy.times[a];
  const tb = proxy.times[b];
  const eps = 0.0005;
  const seek = Math.max(0, ta - 1.0);
  const args = ['-hide_banner', '-nostdin', '-v', 'error'];
  if (seek > 0) args.push('-ss', seek.toFixed(6));
  args.push('-copyts', '-i', proxy.file, '-an', '-sn',
    '-vf', `select='between(t\\,${(ta - eps).toFixed(6)}\\,${(tb + eps).toFixed(6)})',format=gray`,
    '-fps_mode', 'passthrough', '-f', 'rawvideo', '-pix_fmt', 'gray', '-');
  const { child, done } = proc.start(paths.ffmpeg, args, { stdout: 'pipe', allowFail: true });
  let buf = Buffer.alloc(0);
  let idx = a;
  let stopped = false;
  let chain = Promise.resolve();
  child.stdout.on('data', (chunk) => {
    if (stopped) return;
    buf = buf.length ? Buffer.concat([buf, chunk]) : chunk;
    const frames = [];
    while (buf.length >= size) {
      frames.push(new Uint8Array(buf.buffer.slice(buf.byteOffset, buf.byteOffset + size)));
      buf = buf.subarray(size);
    }
    if (!frames.length) return;
    child.stdout.pause();
    chain = chain.then(async () => {
      for (const fr of frames) {
        if (stopped || idx > b) break;
        const r = await onFrame(idx, fr);
        idx++;
        if (r === false) { stopped = true; break; }
      }
      if (stopped || idx > b) {
        stopped = true;
        try { child.kill('SIGKILL'); } catch (_) { /* ignore */ }
      } else {
        child.stdout.resume();
      }
    });
  });
  const r = await done; // allowFail: we judge the exit code ourselves
  await chain;
  if (!stopped && r.code !== 0) {
    throw new Error(`Reading preview frames failed (exit ${r.code}):\n${r.stderrTail}`);
  }
  return { last: idx - 1, count: idx - a };
}

module.exports = { readGray };
