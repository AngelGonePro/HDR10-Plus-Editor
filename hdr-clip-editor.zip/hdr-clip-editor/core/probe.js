'use strict';
const proc = require('./proc');
const log = require('./log');

function frac(v) {
  if (v === undefined || v === null) return NaN;
  const s = String(v);
  if (s.includes('/')) {
    const [a, b] = s.split('/').map(Number);
    return b ? a / b : NaN;
  }
  return Number(s);
}

async function ffprobeJson(ffprobe, args) {
  const r = await proc.capture(ffprobe, ['-v', 'error', '-print_format', 'json', ...args]);
  return JSON.parse(r.stdout || '{}');
}

// Rotation as ffmpeg's autorotate will apply it.
function rotationOf(stream) {
  let rot = 0;
  for (const sd of stream.side_data_list || []) {
    if (sd.side_data_type === 'Display Matrix' && sd.rotation !== undefined) rot = Number(sd.rotation);
  }
  if (!rot && stream.tags && stream.tags.rotate) rot = -Number(stream.tags.rotate);
  rot = ((Math.round(rot) % 360) + 360) % 360;
  return rot;
}

function masterDisplayString(md) {
  const c = (v) => Math.round(frac(v) * 50000);
  const l = (v) => Math.round(frac(v) * 10000);
  if (!md || !md.red_x) return null;
  return `G(${c(md.green_x)},${c(md.green_y)})B(${c(md.blue_x)},${c(md.blue_y)})R(${c(md.red_x)},${c(md.red_y)})` +
    `WP(${c(md.white_point_x)},${c(md.white_point_y)})L(${l(md.max_luminance)},${l(md.min_luminance)})`;
}

// Presentation-order frame timestamps (seconds) from packets: fast, no decode.
// Packets the file marks as "discard" (decoded but never shown, e.g. after a
// cut without re-encoding) are not frames of the clip.
async function frameTimes(ffprobe, file, timeBase) {
  const r = await proc.capture(ffprobe, ['-v', 'error', '-select_streams', 'v:0',
    '-show_entries', 'packet=pts,duration,flags', '-of', 'csv=p=0', file]);
  const rows = [];
  const all = [];
  for (const line of r.stdout.split(/\r?\n/)) {
    if (!line.trim()) continue;
    const [p, d, fl] = line.split(',');
    const pts = Number(p);
    if (!Number.isFinite(pts)) continue;
    all.push(pts);
    if (fl && fl.includes('D')) continue;
    rows.push({ pts, dur: Number(d) });
  }
  all.sort((a, b) => a - b);
  rows.sort((a, b) => a.pts - b.pts);
  const tb = frac(timeBase);
  const times = rows.map((r2) => r2.pts * tb);
  // duration of the last frame: its packet duration, else the median frame step
  let lastDur = rows.length ? rows[rows.length - 1].dur * tb : 0;
  if (!(lastDur > 0)) {
    const steps = [];
    for (let i = 1; i < times.length; i++) steps.push(times[i] - times[i - 1]);
    steps.sort((a, b) => a - b);
    lastDur = steps.length ? steps[Math.floor(steps.length / 2)] : 1 / 30;
  }
  // every listed frame incl. hidden ones (HDR10+ has an entry for each), only kept when they differ
  const listed = all.length !== times.length ? all.map((p) => p * tb) : null;
  return { times, lastDur, listed };
}

async function probeClip(paths, file) {
  log.info(`Probing ${file}`);
  const info = await ffprobeJson(paths.ffprobe, ['-show_streams', '-show_format', file]);
  const v = (info.streams || []).find((s) => s.codec_type === 'video' && !(s.disposition && s.disposition.attached_pic));
  if (!v) throw new Error(`No video stream found in ${file}`);
  const audio = (info.streams || []).filter((s) => s.codec_type === 'audio');

  // The first decoded frames carry the HDR side data (the very first one may not,
  // e.g. after a cut without re-encoding), so a few are read.
  const firstFrames = async (iv) => ((await ffprobeJson(paths.ffprobe, ['-select_streams', 'v:0', '-read_intervals', iv,
    '-show_frames', '-show_entries', 'frame=side_data_list,color_transfer,color_primaries,color_space,pix_fmt', file])).frames || []);
  let frames = await firstFrames('%+#5');
  // hidden frames at the start give no frames out: read the first seconds instead
  if (!frames.some((f) => (f.side_data_list || []).length)) frames = (await firstFrames('%+3')).slice(0, 8);
  const f0 = frames.find((f) => (f.side_data_list || []).length) || frames[0] || {};
  const sideData = [...frames.flatMap((f) => f.side_data_list || []), ...(v.side_data_list || [])];
  const md = sideData.find((s) => s.side_data_type === 'Mastering display metadata');
  const cll = sideData.find((s) => s.side_data_type === 'Content light level metadata');
  const hasHdr10Plus = sideData.some((s) => /2094-40|HDR10\+/i.test(s.side_data_type || ''));

  const rotation = rotationOf(v);
  const swap = rotation === 90 || rotation === 270;
  const { times, lastDur, listed } = await frameTimes(paths.ffprobe, file, v.time_base);
  const nFrames = times.length;
  const duration = nFrames ? times[nFrames - 1] - times[0] + lastDur : frac(v.duration);
  const avgFps = nFrames && duration > 0 ? nFrames / duration : frac(v.avg_frame_rate) || 30;
  const rate = frac(v.r_frame_rate);

  const transfer = v.color_transfer || f0.color_transfer || 'unknown';
  const clip = {
    path: file,
    codec: v.codec_name,
    width: v.width,
    height: v.height,
    rotation,
    dispW: swap ? v.height : v.width,
    dispH: swap ? v.width : v.height,
    pixFmt: v.pix_fmt,
    bitDepth: /p10|p12|p16/.test(v.pix_fmt || '') ? 10 : 8,
    colorTransfer: transfer,
    colorPrimaries: v.color_primaries || f0.color_primaries || 'unknown',
    colorSpace: v.color_space || f0.color_space || 'unknown',
    colorRange: v.color_range || 'tv',
    isPQ: transfer === 'smpte2084',
    isHLG: transfer === 'arib-std-b67',
    masterDisplay: masterDisplayString(md),
    maxCll: cll ? `${Math.round(frac(cll.max_content))},${Math.round(frac(cll.max_average))}` : null,
    hasHdr10Plus,
    videoBitrate: Number(v.bit_rate) || Math.round((Number(info.format.bit_rate) || 0) * 0.95) || 0,
    nominalFps: Number.isFinite(rate) && rate > 0 ? rate : avgFps,
    avgFps,
    nFrames,
    listedTimes: listed, // all listed frames incl. hidden ones (only when there are hidden ones)
    times, // presentation-order timestamps (s), absolute stream time
    lastDur,
    duration,
    audio: audio.map((a) => ({
      index: a.index,
      codec: a.codec_name,
      channels: a.channels,
      layout: a.channel_layout,
      sampleRate: Number(a.sample_rate),
      bitrate: Number(a.bit_rate) || 0,
      lang: (a.tags && a.tags.language) || 'und',
    })),
  };
  log.info(`Probe: ${clip.codec} ${clip.width}x${clip.height} rot=${rotation} -> ${clip.dispW}x${clip.dispH}, ` +
    `${clip.nFrames} frames, ${clip.duration.toFixed(3)} s, avg ${clip.avgFps.toFixed(3)} fps, ` +
    `transfer=${transfer}, HDR10+=${hasHdr10Plus}, MD=${clip.masterDisplay}, CLL=${clip.maxCll}, ` +
    `vbitrate=${clip.videoBitrate}, audio=${clip.audio.map((a) => a.codec + '/' + a.channels + 'ch/' + a.bitrate).join(';')}`);
  return clip;
}

// Timestamps of the frames ffmpeg really decodes. A damaged frame (e.g. at the
// end of a recording that was stopped abruptly) is listed in the file but never
// comes out of the decoder; this finds which. One full decode, so it is only run
// when the preview came out with fewer frames than the file lists.
async function decodedTimes(paths, file, hwArgs = []) {
  const times = [];
  await proc.run(paths.ffmpeg, ['-hide_banner', '-nostdin', ...hwArgs, '-copyts', '-i', file,
    '-map', '0:v:0', '-vf', 'showinfo=checksum=0', '-f', 'null', '-'], {
    onStderrLine: (l) => { const m = /\bn:\s*\d+\s+pts:\s*-?\d+\s+pts_time:(-?[\d.]+)/.exec(l); if (m) times.push(Number(m[1])); },
  });
  return times.sort((a, b) => a - b);
}

module.exports = { probeClip, frameTimes, decodedTimes, frac, masterDisplayString };
