'use strict';
// Non-AI plate tracker: multi-scale normalised cross-correlation template
// matching with a constant-velocity prediction and a slowly adapting template.
// Works on the grayscale preview frames.
const frames = require('./frames');
const log = require('./log');

const TPL = 64;          // template long side in "working" pixels
const SCALES = [1 / 1.04, 1, 1.04];

// Integral image (sum) of a gray frame, (W+1)*(H+1)
function integral(gray, W, H) {
  const I = new Float64Array((W + 1) * (H + 1));
  for (let y = 0; y < H; y++) {
    let row = 0;
    const o = y * W, io = (y + 1) * (W + 1), ip = y * (W + 1);
    for (let x = 0; x < W; x++) {
      row += gray[o + x];
      I[io + x + 1] = I[ip + x + 1] + row;
    }
  }
  return I;
}

class Frame {
  constructor(gray, W, H) {
    this.g = gray; this.W = W; this.H = H; this.I = null;
  }
  ii() { if (!this.I) this.I = integral(this.g, this.W, this.H); return this.I; }
  px(x, y) {
    x = x < 0 ? 0 : x >= this.W ? this.W - 1 : x;
    y = y < 0 ? 0 : y >= this.H ? this.H - 1 : y;
    return this.g[y * this.W + x];
  }
  bilinear(x, y) {
    const x0 = Math.floor(x), y0 = Math.floor(y), fx = x - x0, fy = y - y0;
    const a = this.px(x0, y0), b = this.px(x0 + 1, y0), c = this.px(x0, y0 + 1), d = this.px(x0 + 1, y0 + 1);
    return (a * (1 - fx) + b * fx) * (1 - fy) + (c * (1 - fx) + d * fx) * fy;
  }
  boxMean(x0, y0, x1, y1) {
    // integer box [x0,x1) x [y0,y1), clamped
    const W = this.W, H = this.H;
    x0 = Math.max(0, Math.min(W - 1, x0)); y0 = Math.max(0, Math.min(H - 1, y0));
    x1 = Math.max(x0 + 1, Math.min(W, x1)); y1 = Math.max(y0 + 1, Math.min(H, y1));
    const I = this.ii(), S = W + 1;
    const s = I[y1 * S + x1] - I[y0 * S + x1] - I[y1 * S + x0] + I[y0 * S + x0];
    return s / ((x1 - x0) * (y1 - y0));
  }
  // Resample the image region starting at (ox, oy) with scale k (working
  // pixels per image pixel) into an RW x RH Float32Array.
  sample(ox, oy, k, RW, RH) {
    const out = new Float32Array(RW * RH);
    const step = 1 / k;
    if (step >= 2) {
      for (let v = 0; v < RH; v++) {
        const y0 = Math.round(oy + v * step), y1 = Math.round(oy + (v + 1) * step);
        for (let u = 0; u < RW; u++) {
          const x0 = Math.round(ox + u * step), x1 = Math.round(ox + (u + 1) * step);
          out[v * RW + u] = this.boxMean(x0, y0, x1, y1);
        }
      }
    } else {
      for (let v = 0; v < RH; v++) {
        const y = oy + (v + 0.5) * step - 0.5;
        for (let u = 0; u < RW; u++) out[v * RW + u] = this.bilinear(ox + (u + 0.5) * step - 0.5, y);
      }
    }
    return out;
  }
}

function prepTemplate(T) {
  let m = 0;
  for (let i = 0; i < T.length; i++) m += T[i];
  m /= T.length;
  const Z = new Float32Array(T.length);
  let n2 = 0;
  for (let i = 0; i < T.length; i++) { Z[i] = T[i] - m; n2 += Z[i] * Z[i]; }
  return { Z, norm: Math.sqrt(n2) || 1e-6 };
}

// NCC of zero-mean template Z (tw x th) at offset (x, y) in region R (RW wide)
function nccAt(R, RW, II, I2, Z, norm, tw, th, x, y) {
  const S = RW + 1;
  const N = tw * th;
  const sum = II[(y + th) * S + x + tw] - II[y * S + x + tw] - II[(y + th) * S + x] + II[y * S + x];
  const sq = I2[(y + th) * S + x + tw] - I2[y * S + x + tw] - I2[(y + th) * S + x] + I2[y * S + x];
  const varN = sq - sum * sum / N;
  if (varN <= 1e-6) return -1;
  let num = 0;
  for (let v = 0; v < th; v++) {
    const ro = (y + v) * RW + x, to = v * tw;
    for (let u = 0; u < tw; u++) num += Z[to + u] * R[ro + u];
  }
  return num / (Math.sqrt(varN) * norm);
}

function regionIntegrals(R, RW, RH) {
  const S = RW + 1;
  const II = new Float64Array(S * (RH + 1));
  const I2 = new Float64Array(S * (RH + 1));
  for (let y = 0; y < RH; y++) {
    let r1 = 0, r2 = 0;
    for (let x = 0; x < RW; x++) {
      const p = R[y * RW + x];
      r1 += p; r2 += p * p;
      II[(y + 1) * S + x + 1] = II[y * S + x + 1] + r1;
      I2[(y + 1) * S + x + 1] = I2[y * S + x + 1] + r2;
    }
  }
  return { II, I2 };
}

class PlateTracker {
  constructor(W, H) { this.W = W; this.H = H; }

  init(gray, box) {
    const f = new Frame(gray, this.W, this.H);
    this.w = box.w; this.h = box.h;
    this.cx = box.x + box.w / 2; this.cy = box.y + box.h / 2;
    this.vx = 0; this.vy = 0; this.vs = 1;
    const long = Math.max(box.w, box.h);
    this.k0 = TPL / long;
    this.tw = Math.max(8, Math.round(box.w * this.k0));
    this.th = Math.max(8, Math.round(box.h * this.k0));
    this.T = f.sample(box.x, box.y, this.tw / box.w, this.tw, this.th);
    this.T0 = Float32Array.from(this.T);
    this.lowCount = 0;
  }

  // Best match of the template when the plate has size (w*s, h*s), searching
  // centres within +-R image pixels of (pcx, pcy). step=2 does a coarse pass
  // followed by a +-1 refinement. Returns centre with sub-pixel precision.
  searchAt(f, Z, norm, s, pcx, pcy, R, step) {
    const { tw, th } = this;
    const cw = this.w * s, ch = this.h * s;
    const k = tw / cw;
    const ox = pcx - cw / 2 - R, oy = pcy - ch / 2 - R;
    // A wide search over a big area (small plate, fast motion) is done coarse
    // to fine: first at 1/d resolution, then at full resolution around the best
    // spot. Without this the cost grows with the square of the search area
    // (seconds per frame for a small fast plate).
    if (step > 1) {
      const span = Math.max(cw + 2 * R, ch + 2 * R) * k;
      const d = span > 240 ? Math.min(Math.max(1, Math.floor(Math.min(tw, th) / 4)), Math.ceil(span / 120)) : 1;
      if (d >= 2) {
        const twd = Math.floor(tw / d), thd = Math.floor(th / d);
        const Td = new Float32Array(twd * thd);
        for (let v = 0; v < thd; v++) {
          for (let u = 0; u < twd; u++) {
            let m = 0;
            for (let yy = 0; yy < d; yy++) for (let xx = 0; xx < d; xx++) m += Z[(v * d + yy) * tw + u * d + xx];
            Td[v * twd + u] = m / (d * d);
          }
        }
        const cz = prepTemplate(Td);
        const kd = twd / cw; // coarse pixels per image pixel (the coarse template spans the plate)
        const RWd = Math.max(twd + 2, Math.round((cw + 2 * R) * kd));
        const RHd = Math.max(thd + 2, Math.round((ch + 2 * R) * kd));
        const regd = f.sample(ox, oy, kd, RWd, RHd);
        const ints = regionIntegrals(regd, RWd, RHd);
        // keep the best few separate peaks, refine each at full resolution
        const peaks = [];
        for (let y = 0; y <= RHd - thd; y++) {
          for (let x = 0; x <= RWd - twd; x++) {
            const c = nccAt(regd, RWd, ints.II, ints.I2, cz.Z, cz.norm, twd, thd, x, y);
            if (peaks.length < 3 || c > peaks[peaks.length - 1].c) {
              const near = peaks.findIndex((q) => Math.abs(q.x - x) <= 2 && Math.abs(q.y - y) <= 2);
              if (near >= 0) { if (c > peaks[near].c) peaks[near] = { c, x, y }; } else peaks.push({ c, x, y });
              peaks.sort((p1, p2) => p2.c - p1.c);
              if (peaks.length > 3) peaks.pop();
            }
          }
        }
        let best = null;
        for (const q of peaks) {
          const r = this.searchAt(f, Z, norm, s, ox + (q.x + twd / 2) / kd, oy + (q.y + thd / 2) / kd, (1.5 * d + 1) / k, 1);
          if (!best || r.ncc > best.ncc) best = r;
        }
        return best;
      }
    }
    const RW = Math.max(tw + 2, Math.round((cw + 2 * R) * k));
    const RH = Math.max(th + 2, Math.round((ch + 2 * R) * k));
    const reg = f.sample(ox, oy, k, RW, RH);
    const { II, I2 } = regionIntegrals(reg, RW, RH);
    const mx = RW - tw, my = RH - th;
    const at = (x, y) => nccAt(reg, RW, II, I2, Z, norm, tw, th, x, y);
    let bx = 0, by = 0, bs = -2;
    for (let y = 0; y <= my; y += step) {
      for (let x = 0; x <= mx; x += step) {
        const c = at(x, y);
        if (c > bs) { bs = c; bx = x; by = y; }
      }
    }
    if (step > 1) {
      const cx0 = bx, cy0 = by;
      for (let y = Math.max(0, cy0 - 1); y <= Math.min(my, cy0 + 1); y++) {
        for (let x = Math.max(0, cx0 - 1); x <= Math.min(mx, cx0 + 1); x++) {
          const c = at(x, y);
          if (c > bs) { bs = c; bx = x; by = y; }
        }
      }
    }
    let dx = 0, dy = 0;
    if (bx > 0 && bx < mx) {
      const l = at(bx - 1, by), r = at(bx + 1, by), d = l - 2 * bs + r;
      if (d < 0) dx = Math.max(-0.5, Math.min(0.5, 0.5 * (l - r) / d));
    }
    if (by > 0 && by < my) {
      const u = at(bx, by - 1), dn = at(bx, by + 1), d = u - 2 * bs + dn;
      if (d < 0) dy = Math.max(-0.5, Math.min(0.5, 0.5 * (u - dn) / d));
    }
    return { ncc: bs, s, cw, ch, cx: ox + (bx + dx + tw / 2) / k, cy: oy + (by + dy + th / 2) / k };
  }

  update(gray) {
    const f = new Frame(gray, this.W, this.H);
    const { Z, norm } = prepTemplate(this.T);
    const pcx = this.cx + this.vx, pcy = this.cy + this.vy;
    const sp = Math.hypot(this.vx, this.vy);
    const R = Math.min(0.35 * Math.max(this.W, this.H), Math.max(12, 0.5 * Math.max(this.w, this.h), 2 * sp + 10));
    // 1) wide position search at the predicted scale and two coarse neighbours
    let best = null;
    for (const s0 of SCALES) {
      const r = this.searchAt(f, Z, norm, s0 * this.vs, pcx, pcy, R, 2);
      const score = r.ncc - (s0 === 1 ? 0 : 0.002);
      if (!best || score > best.score) best = { ...r, score };
    }
    // 2) fine scale: three nearby scales, local search, parabola in log-scale.
    //    The first-frame template is scored too: it pins the absolute size,
    //    so small per-frame scale errors can't add up over a long track.
    const anchor = prepTemplate(this.T0);
    const fine = [0.985, 1, 1.015].map((m) => {
      const s = best.s * m;
      const Rf = 3 * (this.w * s) / this.tw + 1;
      const r = this.searchAt(f, Z, norm, s, best.cx, best.cy, Rf, 1);
      const r0 = this.searchAt(f, anchor.Z, anchor.norm, s, best.cx, best.cy, Rf, 1);
      return { s, ncc: r0.ncc > 0.5 ? 0.5 * (r.ncc + r0.ncc) : r.ncc };
    });
    let sFit = best.s;
    const [a, b0, c] = fine.map((r) => r.ncc);
    const den = a - 2 * b0 + c;
    if (den < 0) {
      const off = Math.max(-1, Math.min(1, 0.5 * (a - c) / den)); // in units of the log step
      sFit = best.s * Math.exp(off * Math.log(1.015));
    } else {
      sFit = fine.reduce((p, q) => (q.ncc > p.ncc ? q : p)).s;
    }
    // 3) final position at the fitted scale
    const fin = this.searchAt(f, Z, norm, sFit, best.cx, best.cy, 3 * (this.w * sFit) / this.tw + 1, 1);
    const ncx = fin.cx, ncy = fin.cy;
    const conf = fin.ncc;

    if (conf >= 0.35) {
      this.vx = 0.5 * this.vx + 0.5 * (ncx - this.cx);
      this.vy = 0.5 * this.vy + 0.5 * (ncy - this.cy);
      const scaleStep = fin.cw / this.w;
      this.vs = Math.max(0.97, Math.min(1.03, 0.6 * this.vs + 0.4 * scaleStep));
      this.cx = ncx; this.cy = ncy; this.w = fin.cw; this.h = fin.ch;
      if (conf > 0.8) {
        const patch = f.sample(this.cx - this.w / 2, this.cy - this.h / 2, this.tw / this.w, this.tw, this.th);
        for (let i = 0; i < this.T.length; i++) this.T[i] = 0.9 * this.T[i] + 0.1 * patch[i];
      }
    }
    this.lowCount = conf < 0.5 ? this.lowCount + 1 : 0;
    const box = { x: this.cx - this.w / 2, y: this.cy - this.h / 2, w: this.w, h: this.h };
    const visW = Math.min(this.W, box.x + box.w) - Math.max(0, box.x);
    const visH = Math.min(this.H, box.y + box.h) - Math.max(0, box.y);
    const offFrame = visW <= 0 || visH <= 0 || (visW * visH) / (box.w * box.h) < 0.35;
    let lost = null;
    if (conf < 0.3) lost = 'lost';
    else if (this.lowCount >= 3) lost = 'lost';
    else if (offFrame) lost = 'left the frame';
    return { box, conf, lost };
  }
}

// Track from startFrame (box in normalised coords) towards stopFrame
// (inclusive, dir=+1 forward / -1 backward). onBox(frame, normBox, conf) is
// called for every tracked frame after the start frame.
async function track(paths, proxy, startFrame, normBox, dir, stopFrame, onBox, shouldStop) {
  const W = proxy.w, H = proxy.h;
  const t = new PlateTracker(W, H);
  const pxBox = { x: normBox.x * W, y: normBox.y * H, w: normBox.w * W, h: normBox.h * H };
  let initialised = false;
  let result = { endFrame: startFrame, reason: 'end of range' };
  const handle = (idx, gray) => {
    if (!initialised) { t.init(gray, pxBox); initialised = true; return true; }
    if (shouldStop && shouldStop()) { result.reason = 'stopped'; return false; }
    const r = t.update(gray);
    if (r.lost) {
      result.reason = r.lost;
      return false;
    }
    onBox(idx, { x: r.box.x / W, y: r.box.y / H, w: r.box.w / W, h: r.box.h / H }, r.conf);
    result.endFrame = idx;
    return true;
  };
  log.info(`Tracking ${dir > 0 ? 'forward' : 'backward'} from frame ${startFrame} to ${stopFrame}`);
  if (dir > 0) {
    await frames.readGray(paths, proxy, startFrame, stopFrame, (i, g) => handle(i, g));
  } else {
    let hi = startFrame;
    const CHUNK = 90;
    let go = true;
    while (go && hi >= stopFrame) {
      const lo = Math.max(stopFrame, hi - CHUNK + 1);
      const buf = [];
      await frames.readGray(paths, proxy, lo, hi, (i, g) => { buf.push([i, g]); return true; });
      for (let j = buf.length - 1; j >= 0; j--) {
        // the first frame of the next (earlier) chunk overlaps nothing: lo-1
        if (!handle(buf[j][0], buf[j][1])) { go = false; break; }
      }
      hi = lo - 1;
    }
  }
  log.info(`Tracking stopped at frame ${result.endFrame}: ${result.reason}`);
  return result;
}

module.exports = { track, PlateTracker };
