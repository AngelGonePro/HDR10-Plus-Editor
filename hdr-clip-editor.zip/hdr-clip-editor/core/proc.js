'use strict';
// Process helpers: every spawn is logged with its full command line, tracked
// so it can be cancelled, and its stderr kept for error reports.
const { spawn } = require('child_process');
const path = require('path');
const log = require('./log');

const active = new Set();
let cancelled = false;

class CancelledError extends Error {
  constructor() { super('Cancelled by user'); this.cancelled = true; }
}

function resetCancel() { cancelled = false; }
function checkCancel() { if (cancelled) throw new CancelledError(); }

function cancelAll() {
  cancelled = true;
  for (const p of active) {
    try { p.kill('SIGKILL'); } catch (_) { /* ignore */ }
  }
  log.warn(`Cancel requested: killed ${active.size} running process(es)`);
}

function lineSplitter(cb) {
  let buf = '';
  return (chunk) => {
    buf += chunk.toString();
    // ffmpeg / NVEncC use \r for progress lines
    const parts = buf.split(/\r\n|\r|\n/);
    buf = parts.pop();
    for (const p of parts) if (p.length) cb(p);
  };
}

function start(bin, args, opts = {}) {
  checkCancel();
  log.cmd(bin, args);
  const child = spawn(bin, args, {
    cwd: opts.cwd,
    windowsHide: true,
    stdio: [opts.stdin || 'ignore', opts.stdout || 'pipe', 'pipe'],
  });
  active.add(child);
  const tail = [];
  child.stderr.on('data', lineSplitter((line) => {
    tail.push(line);
    if (tail.length > 60) tail.shift();
    if (opts.onStderrLine) opts.onStderrLine(line);
  }));
  const done = new Promise((resolve, reject) => {
    child.on('error', (err) => {
      active.delete(child);
      const e = new Error(`Could not start ${bin}: ${err.message}. Check the path in Settings.`);
      e.code = err.code;
      log.error(e.message);
      reject(e);
    });
    child.on('close', (code, signal) => {
      active.delete(child);
      if (cancelled) return reject(new CancelledError());
      const name = require('path').basename(bin);
      if (code === 0) {
        log.info(`${name} finished OK`);
        resolve({ code, stderrTail: tail.join('\n') });
      } else if (opts.allowFail) {
        log.warn(`${name} exited with code ${code}${signal ? ' (' + signal + ')' : ''}`);
        resolve({ code, stderrTail: tail.join('\n') });
      } else {
        const msg = `${name} failed (exit ${code}${signal ? ', ' + signal : ''}). Last output:\n${tail.slice(-15).join('\n')}`;
        log.error(msg);
        const e = new Error(msg);
        e.exitCode = code;
        reject(e);
      }
    });
  });
  return { child, done };
}

// Run and collect stdout as a string.
async function capture(bin, args, opts = {}) {
  const { child, done } = start(bin, args, opts);
  const chunks = [];
  child.stdout.on('data', (d) => chunks.push(d));
  const r = await done;
  return { ...r, stdout: Buffer.concat(chunks).toString('utf8') };
}

async function run(bin, args, opts = {}) {
  const { child, done } = start(bin, args, opts);
  if (child.stdout) {
    child.stdout.on('data', lineSplitter((l) => { if (opts.onStdoutLine) opts.onStdoutLine(l); }));
  }
  return done;
}

// a | b : a's stdout feeds b's stdin directly through an OS pipe (the pipe
// handle is handed to b, so video frames never pass through Node). Both
// processes are logged and tracked.
async function pipe(a, b, optsA = {}, optsB = {}) {
  const pa = start(a.bin, a.args, { ...optsA, stdout: 'pipe' });
  let pb;
  try {
    pb = start(b.bin, b.args, { ...optsB, stdin: pa.child.stdout });
  } catch (e) {
    try { pa.child.kill('SIGKILL'); } catch (_) { /* ignore */ }
    throw e;
  }
  // Parent no longer needs its copy of the read end.
  pa.child.stdout.destroy();
  // If the consumer dies, stop the producer too (and vice versa for errors).
  pb.done.catch(() => { try { pa.child.kill('SIGKILL'); } catch (_) { /* ignore */ } });
  const outChunks = [];
  if (pb.child.stdout) {
    pb.child.stdout.on('data', (d) => {
      outChunks.push(d);
      if (optsB.onStdoutLine) d.toString().split(/\r?\n/).filter(Boolean).forEach(optsB.onStdoutLine);
    });
  }
  const [ra, rb] = await Promise.allSettled([pa.done, pb.done]);
  // The producer's error is usually the root cause, so report it first.
  if (ra.status === 'rejected' && !(rb.status === 'rejected' && !ra.reason.exitCode)) {
    if (rb.status === 'rejected') ra.reason.message += `\n(${path.basename(b.bin)} also stopped: ${rb.reason.message.split('\n')[0]})`;
    throw ra.reason;
  }
  if (rb.status === 'rejected') throw rb.reason;
  return { a: ra.value, b: rb.value, stdout: Buffer.concat(outChunks).toString('utf8') };
}

module.exports = { start, run, capture, pipe, cancelAll, resetCancel, checkCancel, CancelledError, active };
