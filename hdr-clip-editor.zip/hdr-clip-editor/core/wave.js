'use strict';
// Waveform of a clip's sound for the timeline's audio track.
// Peaks (lowest and highest sample) per 1/RATE s, on the file's own timeline,
// so bucket k covers [k/RATE, (k+1)/RATE) s of the same clock as the video
// frame times (silence where the sound starts later than 0).
const fs = require('fs');
const proc = require('./proc');
const log = require('./log');

const RATE = 200; // buckets per second (about 6 per frame at 30 fps)
const SR = 16000; // decode rate; plenty for drawing

async function makeWave(paths, clip, outFile) {
  if (!clip.audio.length) return null;
  const per = SR / RATE;
  const mins = [], maxs = [];
  let lo = 0, hi = 0, n = 0, rest = Buffer.alloc(0);
  const take = (buf) => {
    for (let i = 0; i + 1 < buf.length; i += 2) {
      const v = buf.readInt16LE(i);
      if (v < lo) lo = v;
      if (v > hi) hi = v;
      if (++n === per) { mins.push(lo); maxs.push(hi); lo = 0; hi = 0; n = 0; }
    }
  };
  const { child, done } = proc.start(paths.ffmpeg, ['-hide_banner', '-nostdin', '-v', 'error', '-copyts', '-i', clip.path,
    '-map', '0:a:0', '-ac', '1', '-ar', String(SR), '-af', 'aresample=async=1:first_pts=0',
    '-f', 's16le', '-acodec', 'pcm_s16le', '-'], { stdout: 'pipe' });
  child.stdout.on('data', (chunk) => {
    const buf = rest.length ? Buffer.concat([rest, chunk]) : chunk;
    const even = buf.length - (buf.length % 2);
    take(buf.subarray(0, even));
    rest = buf.subarray(even);
  });
  await done;
  if (n) { mins.push(lo); maxs.push(hi); }
  // 8 bits per value is enough for drawing
  const q = (arr) => Buffer.from(Int8Array.from(arr, (v) => Math.max(-127, Math.min(127, Math.round(v / 258))))).toString('base64');
  let pk = 1;
  for (let i = 0; i < mins.length; i++) pk = Math.max(pk, -mins[i], maxs[i]);
  const peak = pk / 32768;
  const wave = { rate: RATE, count: mins.length, peak: +peak.toFixed(4), min: q(mins), max: q(maxs) };
  fs.writeFileSync(outFile, JSON.stringify(wave));
  log.file(`Waveform written: ${outFile} (${mins.length} values, peak ${(20 * Math.log10(peak)).toFixed(1)} dBFS)`);
  return outFile;
}

module.exports = { makeWave, RATE };
