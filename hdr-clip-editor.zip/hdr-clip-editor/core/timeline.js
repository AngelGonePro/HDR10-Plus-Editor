(function (root) {
'use strict';
// Pure helpers shared by the UI (via preload) and the export pipeline.
// Frames are source-frame indexes in presentation order.
// Boxes are normalised to the displayed (upright) frame: {x, y, w, h} in 0..1.

function mergeRanges(ranges) {
  const r = ranges.map(([a, b]) => [Math.min(a, b), Math.max(a, b)]).sort((p, q) => p[0] - q[0]);
  const out = [];
  for (const [a, b] of r) {
    if (out.length && a <= out[out.length - 1][1] + 1) out[out.length - 1][1] = Math.max(out[out.length - 1][1], b);
    else out.push([a, b]);
  }
  return out;
}

// removed ranges -> kept ranges within [0, n-1]
function keepRanges(n, removed) {
  const rem = mergeRanges((removed || []).map(([a, b]) => [Math.max(0, a), Math.min(n - 1, b)]).filter(([a, b]) => a <= b));
  const keep = [];
  let cur = 0;
  for (const [a, b] of rem) {
    if (a > cur) keep.push([cur, a - 1]);
    cur = Math.max(cur, b + 1);
  }
  if (cur <= n - 1) keep.push([cur, n - 1]);
  return keep;
}

function keptCount(keep) { return keep.reduce((s, [a, b]) => s + b - a + 1, 0); }

function isKept(keep, f) { return keep.some(([a, b]) => f >= a && f <= b); }

// ranges minus [a, b]
function subtractRange(ranges, a, b) {
  const out = [];
  for (const [x, y] of mergeRanges(ranges)) {
    if (y < a || x > b) { out.push([x, y]); continue; }
    if (x < a) out.push([x, a - 1]);
    if (y > b) out.push([b + 1, y]);
  }
  return out;
}

// --- slow motion ------------------------------------------------------------
// speeds = [{ a, b, s }]: frames a..b (inclusive) play at speed s (e.g. 0.125 = 1/8).
// Slow motion holds each real frame longer; no frames are invented.

function normSpeeds(speeds) {
  return (speeds || []).filter((p) => p && p.b >= p.a && p.s > 0 && p.s < 1)
    .map((p) => ({ a: Math.round(p.a), b: Math.round(p.b), s: p.s })).sort((p, q) => p.a - q.a);
}

function speedAt(speeds, f) {
  for (const p of speeds || []) if (f >= p.a && f <= p.b) return p.s;
  return 1;
}

// Sets frames a..b to speed s (s >= 1 = normal speed), replacing what was there.
function setSpeed(speeds, a, b, s) {
  if (a > b) [a, b] = [b, a];
  const out = [];
  for (const p of normSpeeds(speeds)) {
    if (p.b < a || p.a > b) { out.push(p); continue; }
    if (p.a < a) out.push({ a: p.a, b: a - 1, s: p.s });
    if (p.b > b) out.push({ a: b + 1, b: p.b, s: p.s });
  }
  if (s < 1) out.push({ a, b, s });
  // join touching parts with the same speed
  const sorted = normSpeeds(out);
  const merged = [];
  for (const p of sorted) {
    const l = merged[merged.length - 1];
    if (l && l.s === p.s && p.a <= l.b + 1) l.b = Math.max(l.b, p.b);
    else merged.push({ ...p });
  }
  return merged;
}

// Source duration of frame f (seconds).
function frameDur(times, lastDur, f) {
  return f + 1 < times.length ? times[f + 1] - times[f] : lastDur;
}

// Length of the exported clip (seconds) after cuts and slow motion.
function outSeconds(times, lastDur, removed, speeds) {
  const n = times.length;
  let s = 0;
  const sp = normSpeeds(speeds);
  for (const [a, b] of keepRanges(n, removed)) {
    for (let f = a; f <= b; f++) s += frameDur(times, lastDur, f) / speedAt(sp, f);
  }
  return s;
}

// atempo only accepts 0.5..100 per instance, so chain halvings
function atempoChain(s) {
  const parts = [];
  let r = s;
  while (r < 0.5 - 1e-9) { parts.push(0.5); r /= 0.5; }
  parts.push(+r.toFixed(6));
  return parts.map((x) => `atempo=${x}`).join(',');
}

// --- tracks -----------------------------------------------------------------
// track = { id, name, keys: { [frame]: {x,y,w,h, m:'manual'|'auto', c?:conf} } }

function sortedKeyFrames(track) {
  return Object.keys(track.keys || {}).map(Number).sort((a, b) => a - b);
}

function lerp(a, b, t) { return a + (b - a) * t; }

// Box of a track at frame f, or null when the track is not active there.
// Between two keys the box is linearly interpolated.
function boxAt(track, f, frames = sortedKeyFrames(track)) {
  if (!frames.length || f < frames[0] || f > frames[frames.length - 1]) return null;
  let lo = 0, hi = frames.length - 1;
  while (lo < hi) {
    const mid = (lo + hi + 1) >> 1;
    if (frames[mid] <= f) lo = mid; else hi = mid - 1;
  }
  const f0 = frames[lo];
  const k0 = track.keys[f0];
  if (f0 === f || lo === frames.length - 1) return { x: k0.x, y: k0.y, w: k0.w, h: k0.h };
  const f1 = frames[lo + 1];
  const k1 = track.keys[f1];
  const t = (f - f0) / (f1 - f0);
  return { x: lerp(k0.x, k1.x, t), y: lerp(k0.y, k1.y, t), w: lerp(k0.w, k1.w, t), h: lerp(k0.h, k1.h, t) };
}

function trackRange(track) {
  const f = sortedKeyFrames(track);
  return f.length ? [f[0], f[f.length - 1]] : null;
}

function padBox(b, padPct) {
  const px = b.w * padPct / 100, py = b.h * padPct / 100;
  return { x: b.x - px, y: b.y - py, w: b.w + 2 * px, h: b.h + 2 * py };
}

// Nearest manual key strictly after (dir=+1) or before (dir=-1) frame f.
function nextManualKey(track, f, dir) {
  const fr = sortedKeyFrames(track).filter((k) => track.keys[k].m === 'manual');
  if (dir > 0) return fr.find((k) => k > f) ?? null;
  const before = fr.filter((k) => k < f);
  return before.length ? before[before.length - 1] : null;
}

// Common output frame rates; used only for encoder rate control.
const STD_RATES = [[24000, 1001], [24, 1], [25, 1], [30000, 1001], [30, 1], [48, 1], [50, 1], [60000, 1001], [60, 1], [120, 1]];
function nearestStdRate(fps) {
  let best = STD_RATES[4], bd = Infinity;
  for (const r of STD_RATES) {
    const d = Math.abs(r[0] / r[1] - fps);
    if (d < bd) { bd = d; best = r; }
  }
  return best;
}

// The frame rate a clip was filmed at, as a standard rate [num, den]. Phone
// Auto-FPS clips vary a little below their rate, so a clip that is not exactly
// a standard rate counts as the nearest whole-number rate (24, 25, 30, 48, 50, 60, 120).
function clipRate(nominal, avg) {
  if (Math.abs(avg - nominal) < 0.01 * nominal) {
    let best = null, bd = 0.002 * nominal;
    for (const r of STD_RATES) { const d = Math.abs(r[0] / r[1] - nominal); if (d < bd) { bd = d; best = r; } }
    if (best) return best;
  }
  const whole = STD_RATES.filter((r) => r[1] === 1);
  let best = whole[0], bd = Infinity;
  for (const r of whole) { const d = Math.abs(r[0] - (avg || nominal)); if (d < bd) { bd = d; best = r; } }
  return best;
}
const rateLabel = (r) => (r[1] === 1 ? `${r[0]}` : (r[0] / r[1]).toFixed(2));

const api = {
  clipRate, rateLabel,
  mergeRanges, keepRanges, keptCount, isKept, sortedKeyFrames, boxAt, trackRange, padBox,
  nextManualKey, nearestStdRate, subtractRange, normSpeeds, speedAt, setSpeed, frameDur, outSeconds, atempoChain,
};
// Usable from Node (require) and from the renderer page (<script> -> window.TL)
if (typeof module !== 'undefined' && module.exports) module.exports = api;
else root.TL = api;
})(typeof window !== 'undefined' ? window : globalThis);
