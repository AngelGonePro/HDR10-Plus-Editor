'use strict';
// Finds sudden flashes (lightning) in a clip from its preview frames, using
// the average brightness of a 16x9 grid of cells per frame.
const frames = require('./frames');
const log = require('./log');

const GX = 16, GY = 9;

function cellMeans(gray, w, h) {
  const out = new Float32Array(GX * GY);
  const cw = w / GX, ch = h / GY;
  // sample every 2nd pixel: plenty for cell averages and twice as fast
  for (let cy = 0; cy < GY; cy++) {
    const y0 = Math.floor(cy * ch), y1 = Math.floor((cy + 1) * ch);
    for (let cx = 0; cx < GX; cx++) {
      const x0 = Math.floor(cx * cw), x1 = Math.floor((cx + 1) * cw);
      let s = 0, n = 0;
      for (let y = y0; y < y1; y += 2) {
        const o = y * w;
        for (let x = x0; x < x1; x += 2) { s += gray[o + x]; n++; }
      }
      out[cy * GX + cx] = s / n;
    }
  }
  return out;
}

// opts: { threshold (0-255 preview levels, default 25), fps }
// A flash must be (1) sudden: brighter than 1-2 frames before, out of light
// that was not already rising, (2) light:
// most cells in the area got brighter at once (movement makes some cells
// brighter and others darker), and (3) short: back to about the old
// brightness within 1.5 s (a car or object coming into view stays).
function detect(M, opts = {}) {
  const T = Number(opts.threshold) || 25;
  const fps = opts.fps || 30;
  const n = M.length;
  const BX = GX - 2, BY = GY - 2; // 3x3-cell areas
  const B = M.map((m) => {
    const out = new Float32Array(BX * BY);
    for (let by = 0; by < BY; by++) for (let bx = 0; bx < BX; bx++) {
      let s = 0;
      for (let y = 0; y < 3; y++) for (let x = 0; x < 3; x++) s += m[(by + y) * GX + bx + x];
      out[by * BX + bx] = s / 9;
    }
    return out;
  });
  const G = M.map((m) => m.reduce((a, b) => a + b, 0) / m.length);
  const maxLen = Math.max(3, Math.round(fps * 1.5));
  const events = [];
  let f = 2;
  while (f < n) {
    let cand = null;
    // whole sky lit
    const gBase = Math.min(G[f - 1], G[f - 2]);
    if (G[f] - gBase >= T * 0.4) {
      const prev = G[f - 1] <= G[f - 2] ? f - 1 : f - 2;
      let up = 0;
      for (let c = 0; c < M[f].length; c++) if (M[f][c] - M[prev][c] > T * 0.2) up++;
      if (up >= M[f].length * 0.6) cand = { series: G, base: gBase, rise: G[f] - gBase };
    }
    // local flash (bolt + glow)
    if (!cand) {
      let best = -1, bk = -1;
      for (let k = 0; k < BX * BY; k++) {
        const r = B[f][k] - Math.min(B[f - 1][k], B[f - 2][k]);
        if (r > best) { best = r; bk = k; }
      }
      if (best >= T) {
        const bx = bk % BX, by = Math.floor(bk / BX);
        const prev = B[f - 1][bk] <= B[f - 2][bk] ? f - 1 : f - 2;
        let up = 0;
        for (let y = 0; y < 3; y++) for (let x = 0; x < 3; x++) {
          const c = (by + y) * GX + bx + x;
          if (M[f][c] - M[prev][c] > T * 0.25) up++;
        }
        if (up >= 5) cand = { series: B.map((b) => b[bk]), base: Math.min(B[f - 1][bk], B[f - 2][bk]), rise: best };
      }
    }
    if (!cand) { f++; continue; }
    // lightning jumps out of steady (or fading) light; a brightness ramp that
    // was already rising before this frame is exposure or a fade, not a flash
    const pre = f >= 3 ? Math.max(0, cand.series[f - 1] - cand.series[f - 3]) : 0;
    if (pre > 0.35 * cand.rise) { f++; continue; }
    // how long until it is dark again
    let peak = cand.series[f], end = -1;
    for (let j = f; j < Math.min(n, f + maxLen + 1); j++) {
      peak = Math.max(peak, cand.series[j]);
      if (j > f && cand.series[j] <= cand.base + 0.3 * (peak - cand.base)) { end = j - 1; break; }
    }
    if (end < 0 && f + maxLen >= n) end = n - 1; // clip ends during the flash
    if (end < 0) { f++; continue; } // stays bright: not lightning
    const last = events[events.length - 1];
    if (last && f - last.b <= Math.max(2, Math.round(fps * 0.25))) {
      last.b = Math.max(last.b, end);
      if (cand.rise > last.strength) { last.strength = cand.rise; last.peak = f; }
    } else events.push({ a: f, b: end, peak: f, strength: cand.rise });
    f = end + 1;
  }
  return { events };
}

async function findFlashes(paths, proxy, opts = {}, onProgress = () => {}) {
  const M = [];
  const n = proxy.nFrames;
  log.info(`Looking for flashes in ${proxy.file} (${n} frames, threshold ${opts.threshold || 25})`);
  await frames.readGray(paths, proxy, 0, n - 1, (i, g) => {
    M.push(cellMeans(g, proxy.w, proxy.h));
    if (i % 60 === 0) onProgress(i / n);
    return true;
  });
  const r = detect(M, opts);
  log.info(`Found ${r.events.length} flash(es): ${r.events.map((e) => `${e.a}-${e.b}`).join(', ') || 'none'}`);
  return r;
}

module.exports = { findFlashes, detect, cellMeans };
