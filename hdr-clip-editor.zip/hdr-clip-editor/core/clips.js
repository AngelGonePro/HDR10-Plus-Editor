'use strict';
// Importing a clip: probe, HDR10+ metadata, preview. Results are cached per
// file (path + size + modified time), so reopening a session is instant.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const log = require('./log');
const probe = require('./probe');
const proxy = require('./proxy');
const h10 = require('./hdr10plus');
const wave = require('./wave');

const CACHE_VERSION = 1;

// The clip's frames are the frames ffmpeg decodes (that is what the preview and
// the export see). If the file lists frames that never come out of the decoder
// (damaged, or never meant to be shown), the clip's frame list, timing and
// HDR10+ entries are made to match the decoded frames. Changes `c` in place.
async function matchDecodedFrames(paths, c, dir, onProgress) {
  const info = c.info;
  if (info.decodeChecked) return false;
  info.decodeChecked = true;
  const P = info.listedTimes || info.times; // every listed frame (hidden ones too; HDR10+ has an entry for each)
  if (!c.proxy || c.proxy.times.length >= P.length) return true; // normal case: every listed frame decodes
  const name = path.basename(c.file);
  log.warn(`${name}: the file lists ${P.length} frames but only ${c.proxy.times.length} decode. Finding which ones...`);
  onProgress({ stage: 'Checking frames', frac: 0.5 });
  const D = await proxy.withHwFallback(paths, 'Frame check', (hw) => probe.decodedTimes(paths, info.path, hw));
  // match every decoded frame to the listed frame with the same timestamp
  const tol = 0.0005;
  const keepIdx = [];
  let j = 0, unmatched = 0;
  for (const t of D) {
    while (j < P.length && P[j] < t - tol) j++;
    if (j < P.length && Math.abs(P[j] - t) <= tol) { keepIdx.push(j); j++; } else unmatched++;
  }
  const dropped = [];
  { let k = 0; for (let i = 0; i < P.length; i++) { if (keepIdx[k] === i) k++; else dropped.push(i); } }
  log.warn(`${name}: ${dropped.length} listed frame(s) never decode (positions ${dropped.slice(0, 20).join(', ')}${dropped.length > 20 ? ', ...' : ''}); the clip uses the ${D.length} decoded frames`);
  if (unmatched) log.warn(`${name}: ${unmatched} decoded frame(s) have no listed timestamp; their own timestamps are used`);
  // HDR10+ has one entry per listed frame: drop the entries of frames that never decode
  if (c.hdr10plusJson && !unmatched) {
    const n = h10.count(c.hdr10plusJson);
    if (n === P.length && dropped.length) {
      const ranges = [];
      for (const i of keepIdx) { const l = ranges[ranges.length - 1]; if (l && i === l[1] + 1) l[1] = i; else ranges.push([i, i]); }
      c.hdr10plusJson = await h10.cutToRanges(paths, c.hdr10plusJson, n, ranges, path.join(dir, 'hdr10plus.decoded.json'));
      log.info(`${name}: HDR10+ entries of the ${dropped.length} undecodable frame(s) removed, ${h10.count(c.hdr10plusJson)} left`);
    } else if (n !== D.length) {
      log.warn(`${name}: HDR10+ has ${n} entries for ${P.length} listed / ${D.length} decoded frames; it will be matched by length at export`);
    }
  }
  info.times = D;
  info.listedTimes = null;
  info.nFrames = D.length;
  info.listedFrames = P.length;
  info.duration = D[D.length - 1] - D[0] + info.lastDur;
  info.avgFps = info.nFrames / info.duration;
  return true;
}

function cacheDir(paths, file, longEdge) {
  const st = fs.statSync(file);
  const key = crypto.createHash('sha1')
    .update(`${CACHE_VERSION}|${path.resolve(file)}|${st.size}|${st.mtimeMs}|${longEdge}`).digest('hex').slice(0, 16);
  return path.join(paths.workDir, 'cache', key);
}

// fresh = forget the cached preview and read everything again
async function importClip(paths, file, longEdge, onProgress = () => {}, { fresh = false } = {}) {
  if (!fs.existsSync(file)) throw new Error(`File not found: ${file}`);
  const dir = cacheDir(paths, file, longEdge);
  const meta = path.join(dir, 'clip.json');
  if (fresh && fs.existsSync(dir)) {
    log.info(`Rebuilding the preview of ${file}: removing ${dir}`);
    fs.rmSync(dir, { recursive: true, force: true, maxRetries: 5, retryDelay: 200 });
  }
  if (fs.existsSync(meta)) {
    try {
      const c = JSON.parse(fs.readFileSync(meta, 'utf8'));
      if (fs.existsSync(c.proxy.file) && (!c.hdr10plusJson || fs.existsSync(c.hdr10plusJson))) {
        log.info(`Using cached preview for ${file} (${dir})`);
        let upd = false;
        // HDR10+ could not be read last time (e.g. hdr10plus_tool was not set up yet): try again
        if (c.info.hasHdr10Plus && !c.hdr10plusJson) {
          onProgress({ stage: 'Reading HDR10+ metadata', frac: 0.3 });
          c.hdr10plusJson = await h10.extract(paths, file, path.join(dir, 'hdr10plus.json'));
          if (c.hdr10plusJson) { log.info(`${path.basename(file)}: HDR10+ metadata read now`); upd = true; }
        }
        // clips opened with older versions: check that every listed frame decodes
        if (!c.info.decodeChecked && await matchDecodedFrames(paths, c, dir, onProgress)) upd = true;
        // previews made by older versions have no sound / no waveform yet
        if (c.proxy.audio === undefined) {
          onProgress({ stage: 'Adding sound to the preview', frac: 0.5 });
          c.proxy = await proxy.addProxyAudio(paths, c.info, c.proxy); upd = true;
        }
        if (c.wave === undefined) {
          onProgress({ stage: 'Reading the sound', frac: 0.8 });
          c.wave = await wave.makeWave(paths, c.info, path.join(dir, 'wave.json')); upd = true;
        }
        if (upd) fs.writeFileSync(meta, JSON.stringify(c));
        onProgress({ stage: 'ready', frac: 1 });
        return c;
      }
    } catch (_) { /* rebuild */ }
  }
  fs.mkdirSync(dir, { recursive: true });
  onProgress({ stage: 'Reading video', frac: 0 });
  const info = await probe.probeClip(paths, file);
  if (!info.nFrames) throw new Error(`No video frames found in ${file}`);
  let hdr10plusJson = null;
  if (info.hasHdr10Plus) {
    onProgress({ stage: 'Reading HDR10+ metadata', frac: 0 });
    hdr10plusJson = await h10.extract(paths, file, path.join(dir, 'hdr10plus.json'));
    if (hdr10plusJson) {
      const n = h10.count(hdr10plusJson);
      if (n !== info.nFrames) log.warn(`${path.basename(file)}: HDR10+ has ${n} entries for ${info.nFrames} frames (will be matched at export)`);
    }
  }
  let px = await proxy.makeProxy(paths, info, path.join(dir, 'proxy.mp4'), longEdge,
    (f) => onProgress({ stage: 'Making preview', frac: f }));
  onProgress({ stage: 'Adding sound to the preview', frac: 1 });
  // the frames that really decode decide the clip's frame list (before the sound is lined up to it)
  const pre = { file, info, proxy: px, hdr10plusJson };
  await matchDecodedFrames(paths, pre, dir, onProgress);
  hdr10plusJson = pre.hdr10plusJson;
  px = await proxy.addProxyAudio(paths, info, px);
  onProgress({ stage: 'Reading the sound', frac: 1 });
  const waveFile = await wave.makeWave(paths, info, path.join(dir, 'wave.json'));
  const clip = { file, info, proxy: px, wave: waveFile, hdr10plusJson, cache: dir };
  fs.writeFileSync(meta, JSON.stringify(clip));
  onProgress({ stage: 'ready', frac: 1 });
  return clip;
}

module.exports = { importClip, matchDecodedFrames };
