'use strict';
// HDR10+ dynamic metadata: extract from a clip, cut it to match the edit,
// inject it into the newly encoded video, and verify it afterwards.
const fs = require('fs');
const path = require('path');
const proc = require('./proc');
const log = require('./log');

function annexbArgs(file) {
  return ['-hide_banner', '-v', 'error', '-i', file, '-map', '0:v:0', '-c:v', 'copy',
    '-bsf:v', 'hevc_mp4toannexb', '-f', 'hevc', '-'];
}

// Returns the JSON path, or null when the clip has no HDR10+.
async function extract(paths, file, outJson) {
  try {
    const r = await proc.pipe(
      { bin: paths.ffmpeg, args: annexbArgs(file) },
      { bin: paths.hdr10plus, args: ['extract', '-o', outJson, '-'] },
      {}, { allowFail: true });
    if (r.b.code !== 0 || !fs.existsSync(outJson)) {
      log.warn(`No HDR10+ metadata extracted from ${path.basename(file)}: ${r.b.stderrTail.split('\n')[0] || 'unknown error'}`);
      return null;
    }
  } catch (e) {
    if (e.cancelled) throw e;
    log.warn(`HDR10+ extraction failed for ${path.basename(file)}: ${e.message}`);
    return null;
  }
  log.file(`HDR10+ metadata written: ${outJson} (${count(outJson)} frames)`);
  return outJson;
}

function readJson(file) { return JSON.parse(fs.readFileSync(file, 'utf8')); }
function count(file) { return readJson(file).SceneInfo.length; }

// Per-frame fingerprint used to compare metadata sequences.
function fingerprints(file) {
  return readJson(file).SceneInfo.map((s) => {
    const L = s.LuminanceParameters || {};
    return `${L.AverageRGB}|${(L.MaxScl || []).join(',')}|${((L.LuminanceDistributions || {}).DistributionValues || []).join(',')}`;
  });
}

async function runEditor(paths, inJson, edits, outJson, tag) {
  const editsPath = outJson.replace(/\.json$/, `.${tag}.edits.json`);
  fs.writeFileSync(editsPath, JSON.stringify(edits, null, 2));
  log.file(`Wrote ${editsPath}: ${JSON.stringify(edits)}`);
  await proc.run(paths.hdr10plus, ['editor', inJson, '-j', editsPath, '-o', outJson]);
}

// Make the metadata frame count equal the decoded video frame count.
async function conformLength(paths, inJson, videoFrames, outJson) {
  const n = count(inJson);
  if (n === videoFrames) { fs.copyFileSync(inJson, outJson); return outJson; }
  if (n > videoFrames) {
    log.warn(`HDR10+ has ${n} entries but video has ${videoFrames} frames: dropping the extra ${n - videoFrames}`);
    await runEditor(paths, inJson, { remove: [`${videoFrames}-${n - 1}`] }, outJson, 'conform');
  } else {
    log.warn(`HDR10+ has ${n} entries but video has ${videoFrames} frames: repeating the last entry ${videoFrames - n}x`);
    await runEditor(paths, inJson, { duplicate: [{ source: n - 1, offset: n, length: videoFrames - n }] }, outJson, 'conform');
  }
  const after = count(outJson);
  if (after !== videoFrames) throw new Error(`HDR10+ length fix failed: ${after} != ${videoFrames}`);
  return outJson;
}

// keep: [[a,b],...] inclusive source-frame ranges, sorted, non-overlapping.
async function cutToRanges(paths, inJson, totalFrames, keep, outJson) {
  const remove = [];
  let cur = 0;
  for (const [a, b] of keep) {
    if (a > cur) remove.push(`${cur}-${a - 1}`);
    cur = b + 1;
  }
  if (cur <= totalFrames - 1) remove.push(`${cur}-${totalFrames - 1}`);
  if (!remove.length) { fs.copyFileSync(inJson, outJson); return outJson; }
  await runEditor(paths, inJson, { remove }, outJson, 'cut');
  const expected = keep.reduce((s, [a, b]) => s + b - a + 1, 0);
  const got = count(outJson);
  if (got !== expected) throw new Error(`HDR10+ cut produced ${got} entries, expected ${expected}`);
  return outJson;
}

async function inject(paths, hevcIn, json, hevcOut) {
  await proc.run(paths.hdr10plus, ['inject', '-i', hevcIn, '-j', json, '-o', hevcOut]);
  log.file(`Injected HDR10+ ${json} into ${hevcOut}`);
}

// ---- editing metadata for fades and crossfades ------------------------------
// HDR10+ luminance values are linear light, 0..100000 = 0..10000 nits. A fade
// or a crossfade is done on the PQ signal, so the matching metadata is
// computed through the PQ curve (SMPTE ST 2084).
const M1 = 2610 / 16384, M2 = 2523 / 4096 * 128, C1 = 3424 / 4096, C2 = 2413 / 4096 * 32, C3 = 2392 / 4096 * 32;
function pqFromLinear(L) { const p = Math.pow(Math.max(0, L), M1); return Math.pow((C1 + C2 * p) / (1 + C3 * p), M2); }
function linearFromPq(E) { const p = Math.pow(Math.max(0, E), 1 / M2); return Math.pow(Math.max(p - C1, 0) / (C2 - C3 * p), 1 / M1); }
const toPq = (v) => pqFromLinear(v / 100000);
const fromPq = (e) => Math.max(0, Math.min(100000, Math.round(linearFromPq(e) * 100000)));

// Applies fn(pqValuesOfA, pqValuesOfB) -> pq to every luminance value.
// DistributionIndex 5 holds a pixel percentage, not a brightness; it is mixed linearly.
function mapLuminance(eA, eB, wA, fnPq) {
  const out = JSON.parse(JSON.stringify(wA >= 0.5 || !eB ? eA : eB));
  const La = eA.LuminanceParameters, Lb = (eB || eA).LuminanceParameters, Lo = out.LuminanceParameters;
  Lo.AverageRGB = fromPq(fnPq(toPq(La.AverageRGB), toPq(Lb.AverageRGB)));
  Lo.MaxScl = La.MaxScl.map((v, i) => fromPq(fnPq(toPq(v), toPq(Lb.MaxScl[i]))));
  const da = La.LuminanceDistributions, db = Lb.LuminanceDistributions;
  if (da && db && Lo.LuminanceDistributions) {
    Lo.LuminanceDistributions.DistributionValues = da.DistributionValues.map((v, i) => {
      if (da.DistributionIndex[i] === 5) return Math.round(wA * v + (1 - wA) * db.DistributionValues[i]);
      return fromPq(fnPq(toPq(v), toPq(db.DistributionValues[i])));
    });
  }
  return out;
}
// Frame faded towards black: the PQ signal is multiplied by f.
function fadeEntry(e, f) { return mapLuminance(e, null, 1, (a) => a * f); }
// Crossfade frame: wA * A + (1 - wA) * B on the PQ signal (an upper bound for maxima).
function blendEntry(eA, eB, wA) { return mapLuminance(eA, eB, wA, (a, b) => wA * a + (1 - wA) * b); }

// Writes a list of per-frame entries as a JSON hdr10plus_tool accepts, and lets
// hdr10plus_tool rewrite it (it rebuilds the scene info and checks every entry).
async function writeEntries(paths, entries, template, outJson) {
  const raw = outJson.replace(/\.json$/, '.raw.json');
  const scenes = entries.map((e, i) => ({ ...e, SceneId: 0, SceneFrameIndex: i, SequenceFrameIndex: i }));
  fs.writeFileSync(raw, JSON.stringify({
    JSONInfo: template.JSONInfo, SceneInfo: scenes,
    SceneInfoSummary: { SceneFirstFrameIndex: [0], SceneFrameNumbers: [entries.length] }, ToolInfo: template.ToolInfo,
  }));
  await runEditor(paths, raw, {}, outJson, 'write');
  const got = count(outJson);
  if (got !== entries.length) throw new Error(`HDR10+ rewrite produced ${got} entries, expected ${entries.length}`);
  return outJson;
}

module.exports = {
  extract, count, fingerprints, conformLength, cutToRanges, inject, annexbArgs, readJson,
  fadeEntry, blendEntry, writeEntries, pqFromLinear, linearFromPq,
};
