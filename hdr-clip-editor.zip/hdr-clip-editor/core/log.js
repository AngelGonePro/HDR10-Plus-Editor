'use strict';
// Every program launch (full command line), file operation and result is
// logged here, both to a log file and to the UI log panel.
const fs = require('fs');
const path = require('path');
const { EventEmitter } = require('events');

const bus = new EventEmitter();
bus.setMaxListeners(50);
let logFile = null;

function init(workDir) {
  const dir = path.join(workDir, 'logs');
  fs.mkdirSync(dir, { recursive: true });
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  logFile = path.join(dir, `session-${stamp}.log`);
  write('info', `Log file: ${logFile}`);
  return logFile;
}

function write(level, msg) {
  const line = `[${new Date().toISOString()}] [${level.toUpperCase()}] ${msg}`;
  if (logFile) {
    try { fs.appendFileSync(logFile, line + '\n'); } catch (_) { /* ignore */ }
  }
  if (process.env.HDRCE_LOG_STDOUT) process.stdout.write(line + '\n');
  bus.emit('line', { level, msg, line });
}

function quoteArg(a) {
  const s = String(a);
  return /[\s"'()&|<>^;]/.test(s) || s === '' ? `"${s.replace(/"/g, '\\"')}"` : s;
}

function cmdline(bin, args) {
  return [bin, ...args].map(quoteArg).join(' ');
}

module.exports = {
  init,
  bus,
  write,
  info: (m) => write('info', m),
  warn: (m) => write('warn', m),
  error: (m) => write('error', m),
  cmd: (bin, args) => write('cmd', cmdline(bin, args)),
  file: (m) => write('file', m),
  cmdline,
  get path() { return logFile; },
};
