'use strict';
/* global TL, api */
const $ = (id) => document.getElementById(id);
const vid = $('vid');
const overlay = $('overlay');
const octx = overlay.getContext('2d');
const tlc = $('timeline');
const tctx = tlc.getContext('2d');
const viewer = $('viewer');

const COLORS = ['#f2b33d', '#3ecf8e', '#4da3ff', '#ff6b6b', '#c77dff', '#00c2d1', '#ff9f43', '#a3e635'];
const S = {
  clips: [], cur: -1, frame: 0, sel: null, markA: null, markB: null,
  tracking: null, blurPrev: true, settings: {}, tools: null,
  zoom: { a: 0, b: 1 }, undo: [], redo: [], stamp: 0,
  sound: { volume: 1, muted: false }, tlHeight: 180,
};

// ---------------------------------------------------------------- helpers
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const cur = () => S.clips[S.cur] || null;
const ready = (c = cur()) => !!c && c.status === 'ready';
const N = () => (ready() ? cur().info.nFrames : 0);
const errMsg = (e) => String(e && e.message ? e.message : e).replace(/^Error invoking remote method '[^']+': (Error: )?/, '');
function fmt(sec) {
  if (!Number.isFinite(sec)) sec = 0;
  const m = Math.floor(sec / 60), s = sec - m * 60;
  return `${m}:${s.toFixed(3).padStart(6, '0')}`;
}
function frameTime(c, n) { return c.info.times[n] - c.info.times[0]; }
function clipDuration(c) { return c.info.duration; }
function lastDur(c) {
  return c.info.lastDur || (c.info.duration - (c.info.times[c.info.nFrames - 1] - c.info.times[0])) || 1 / 30;
}
// length of this clip in the export: cuts removed, slow-motion parts stretched
function keptSeconds(c) { return TL.outSeconds(c.info.times, lastDur(c), c.removed, c.speeds); }
function cutSeconds(c) { return TL.outSeconds(c.info.times, lastDur(c), c.removed, []); }
const SPEED_LABEL = { 0.5: '½', 0.25: '¼', 0.125: '⅛', 0.0625: '1/16' };
function speedLabel(s) { return SPEED_LABEL[s] || `1/${+(1 / s).toFixed(2)}`; }
function setStatus(t) { $('statusText').textContent = t; }
function trackById(id, c = cur()) { return c ? c.tracks.find((t) => t.id === id) : null; }
function indexAtTime(times, t) {
  let lo = 0, hi = times.length - 1;
  if (t <= times[0]) return 0;
  while (lo < hi) {
    const mid = (lo + hi + 1) >> 1;
    if (times[mid] <= t + 1e-4) lo = mid; else hi = mid - 1;
  }
  return lo;
}

let renderQueued = false;
function requestRender() {
  if (renderQueued) return;
  renderQueued = true;
  requestAnimationFrame(() => { renderQueued = false; renderOverlay(); renderTimeline(); renderInfo(); });
}

let saveTimer = null;
function saveSessionSoon() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    api.saveSession({
      clips: S.clips.map((c) => ({ file: c.file, removed: c.removed, tracks: c.tracks, speeds: c.speeds, transIn: c.transIn || null, rot: rotOf(c) })),
      cur: S.cur, sound: S.sound, tlHeight: S.tlHeight,
    });
  }, 800);
}

// Undo / redo. A step remembers the clip order, every transition, and the full
// edit state (cuts, plates, slow motion) of the clip that was changed.
function snapshot(ref, label) {
  return {
    label, ref, cur: S.cur, order: S.clips.slice(),
    trans: S.clips.map((c) => (c.transIn ? { ...c.transIn } : null)),
    state: ref ? JSON.parse(JSON.stringify({ removed: ref.removed, tracks: ref.tracks, speeds: ref.speeds || [], rot: rotOf(ref) })) : null,
  };
}
function pushUndo(label = 'edit', ref = cur()) {
  S.undo.push(snapshot(ref, label));
  if (S.undo.length > 60) S.undo.shift();
  S.redo = [];
  updateUndoButtons();
}
function applySnapshot(u) {
  const keep = cur();
  S.clips = u.order.slice();
  u.order.forEach((c, i) => { c.transIn = u.trans[i]; });
  if (u.ref) Object.assign(u.ref, JSON.parse(JSON.stringify(u.state)));
  const want = u.ref && S.clips.includes(u.ref) ? S.clips.indexOf(u.ref) : (keep && S.clips.includes(keep) ? S.clips.indexOf(keep) : Math.min(u.cur, S.clips.length - 1));
  if (want !== S.cur || cur() !== keep) { const f = S.frame; selectClip(want); if (cur() === keep) seekFrame(f); }
  if (S.sel && !trackById(S.sel)) S.sel = null;
}
function undo() {
  if (S.tracking) return;
  const u = S.undo.pop();
  if (!u) { setStatus('Nothing to undo'); return; }
  S.redo.push(snapshot(u.ref, u.label));
  applySnapshot(u);
  setStatus(`Undid ${u.label}`);
  changed();
}
function redo() {
  if (S.tracking) return;
  const r = S.redo.pop();
  if (!r) { setStatus('Nothing to redo'); return; }
  S.undo.push(snapshot(r.ref, r.label));
  applySnapshot(r);
  setStatus(`Redid ${r.label}`);
  changed();
}
function updateUndoButtons() {
  const u = S.undo[S.undo.length - 1], r = S.redo[S.redo.length - 1];
  $('btnUndo').disabled = !u; $('btnRedo').disabled = !r;
  $('btnUndo').title = u ? `Undo ${u.label} (Ctrl+Z)` : 'Nothing to undo';
  $('btnRedo').title = r ? `Redo ${r.label} (Ctrl+Y)` : 'Nothing to redo';
}
function changed() { S.stamp++; renderClips(); renderPlates(); requestRender(); saveSessionSoon(); updateUndoButtons(); }

// Sorted key frames per track, cached until the keys change (S.stamp bump).
const kfCache = new WeakMap();
function keyFrames(t) {
  const c = kfCache.get(t);
  if (c && c.stamp === S.stamp) return c.frames;
  const frames = TL.sortedKeyFrames(t);
  kfCache.set(t, { stamp: S.stamp, frames });
  return frames;
}
function boxAtC(t, f) { return TL.boxAt(t, f, keyFrames(t)); }

// ---------------------------------------------------------------- turning
// A clip filmed sideways can be turned: c.rot = 0, 90, 180 or 270 degrees
// clockwise. Plate boxes, tracking and the blur stay in the clip's own picture;
// only the view (and the exported video) is turned.
const rotOf = (c) => (c && c.rot) || 0;
function viewSize(c) { return rotOf(c) % 180 ? { w: c.info.dispH, h: c.info.dispW } : { w: c.info.dispW, h: c.info.dispH }; }
// box in the clip's picture -> box in the turned view (both 0..1)
function rotBox(b, rot) {
  if (!b) return b;
  if (rot === 90) return { ...b, x: 1 - b.y - b.h, y: b.x, w: b.h, h: b.w };
  if (rot === 180) return { ...b, x: 1 - b.x - b.w, y: 1 - b.y - b.h };
  if (rot === 270) return { ...b, x: b.y, y: 1 - b.x - b.w, w: b.h, h: b.w };
  return b;
}
function unrotBox(b, rot) { return rotBox(b, (360 - rot) % 360); }
const viewBox = (t, f, c = cur()) => rotBox(boxAtC(t, f), rotOf(c));
const ROT_LABEL = { 90: 'turned right', 180: 'upside down', 270: 'turned left' };
function turnClip(dir) {
  const c = cur();
  if (!ready(c) || S.tracking) return;
  pushUndo(dir > 0 ? 'turning right' : 'turning left');
  c.rot = (rotOf(c) + (dir > 0 ? 90 : 270)) % 360;
  if (drag) drag = null;
  const v = viewSize(c);
  setStatus(c.rot ? `${c.name} ${ROT_LABEL[c.rot]} (${v.w}×${v.h}). Plates and cuts stay as they are.` : `${c.name} back to how it was filmed (${v.w}×${v.h})`);
  changed();
}
function rangeC(t) { const fr = keyFrames(t); return fr.length ? [fr[0], fr[fr.length - 1]] : null; }

// ---------------------------------------------------------------- clips
// ---------------------------------------------------------------- transitions
// A clip's transIn = { type: 'none' | 'black' | 'cross', dur: seconds } joins it
// to the clip before it. Nothing is cut: "black" fades out and back in,
// "cross" lets the two clips overlap and dissolve into each other.
const TRANS_LABEL = { none: 'No transition', black: 'Fade through black', cross: 'Crossfade' };
function transitionChip(c, prev) {
  const t = c.transIn || { type: 'none', dur: 1 };
  const el = document.createElement('div');
  el.className = 'trans' + (t.type !== 'none' ? ' on' : '');
  el.innerHTML = `<span class="trans-ico">${t.type === 'black' ? '◐' : t.type === 'cross' ? '⧉' : '↓'}</span>
    <select class="trans-type" title="How ${escapeHtml(prev.name)} goes into ${escapeHtml(c.name)}">
      <option value="none">No transition</option><option value="black">Fade through black</option><option value="cross">Crossfade</option>
    </select>
    <select class="trans-dur" title="Length of the transition">
      ${[0.5, 1, 1.5, 2, 3].map((d) => `<option value="${d}">${d} s</option>`).join('')}
    </select>`;
  const ty = el.querySelector('.trans-type'), du = el.querySelector('.trans-dur');
  ty.value = t.type; du.value = String(t.dur || 1);
  du.disabled = t.type === 'none';
  const set = () => {
    const nt = ty.value === 'none' ? null : { type: ty.value, dur: Number(du.value) };
    if (JSON.stringify(nt) === JSON.stringify(c.transIn || null)) return; // nothing changed
    pushUndo('transition', null);
    c.transIn = nt;
    setStatus(ty.value === 'none' ? `${prev.name} → ${c.name}: no transition` : `${prev.name} → ${c.name}: ${TRANS_LABEL[ty.value].toLowerCase()}, ${du.value} s`);
    changed();
  };
  ty.addEventListener('change', set); du.addEventListener('change', set);
  el.addEventListener('click', (e) => e.stopPropagation());
  return el;
}
// kept frames + how long each is shown (after slow motion)
function shownFrames(c) {
  const fr = [];
  for (const [a, b] of TL.keepRanges(c.info.nFrames, c.removed)) for (let f = a; f <= b; f++) fr.push(f);
  const dur = fr.map((f) => TL.frameDur(c.info.times, lastDur(c), f) / TL.speedAt(c.speeds, f));
  return { fr, dur };
}
function framesFor(sf, sec, dir) {
  let t = 0, n = 0; const L = sf.fr.length;
  while (n < L && t < sec - 1e-9) { t += sf.dur[dir > 0 ? n : L - 1 - n]; n++; }
  return n;
}
// The transitions touching clip index i: { into: {...} from the previous clip, out: {...} into the next }
function transZones(i) {
  const c = S.clips[i];
  if (!ready(c)) return {};
  const res = {};
  const sf = shownFrames(c);
  const prev = S.clips[i - 1], next = S.clips[i + 1];
  if (i > 0 && c.transIn && ready(prev)) {
    const t = c.transIn;
    if (t.type === 'black') res.into = { type: 'black', n: Math.max(1, framesFor(sf, t.dur / 2, 1)), sf };
    else {
      const psf = shownFrames(prev);
      const K = Math.min(framesFor(sf, t.dur, 1), sf.fr.length - 1, psf.fr.length - 1);
      if (K >= 2) res.into = { type: 'cross', n: K, sf, other: prev, osf: psf };
    }
  }
  if (next && next.transIn && ready(next)) {
    const t = next.transIn;
    const nsf = shownFrames(next);
    if (t.type === 'black') res.out = { type: 'black', n: Math.max(1, framesFor(sf, t.dur / 2, -1)), sf };
    else {
      const K = Math.min(framesFor(nsf, t.dur, 1), nsf.fr.length - 1, sf.fr.length - 1);
      if (K >= 2) res.out = { type: 'cross', n: K, sf, other: next, osf: nsf };
    }
  }
  return res;
}
function crossOverlapSeconds() {
  let s = 0;
  S.clips.forEach((c, i) => {
    if (i > 0 && c.transIn && c.transIn.type === 'cross' && ready(c) && ready(S.clips[i - 1])) {
      const z = transZones(i).into;
      if (z) s += z.sf.dur.slice(0, z.n).reduce((x, y) => x + y, 0);
    }
  });
  return s;
}

function renderClips() {
  const list = $('clipList');
  list.innerHTML = '';
  S.clips.forEach((c, i) => {
    if (i > 0) list.appendChild(transitionChip(c, S.clips[i - 1]));
    const el = document.createElement('div');
    el.className = 'clip' + (i === S.cur ? ' active' : '');
    const badges = [];
    let meta = '';
    if (ready(c)) {
      const inf = c.info;
      const v = viewSize(c);
      meta = `${v.w}×${v.h} · ${inf.avgFps.toFixed(2)} fps · ${fmt(clipDuration(c))}`;
      if (inf.hasHdr10Plus) badges.push('<span class="badge hdrp">HDR10+</span>');
      else if (inf.hdr10plusUnread) badges.push('<span class="badge warn" title="This clip has HDR10+, but it could not be read. Check hdr10plus_tool in Settings, then press ⟳ on this clip.">HDR10+ not read ⚠</span>');
      else if (inf.isPQ) badges.push('<span class="badge hdr">HDR10 (no HDR10+)</span>');
      else if (inf.isHLG) badges.push('<span class="badge hdr">HLG</span>');
      else badges.push('<span class="badge">SDR</span>');
      if (!inf.audio.length) badges.push('<span class="badge warn">no audio</span>');
      if (rotOf(c)) badges.push(`<span class="badge turn">⟳ ${ROT_LABEL[rotOf(c)]}</span>`);
      const plates = c.tracks.filter((t) => rangeC(t)).length;
      if (plates) badges.push(`<span class="badge">${plates} plate${plates > 1 ? 's' : ''}</span>`);
      if (c.speeds.length) badges.push(`<span class="badge slow">🐢 ${c.speeds.length} slow part${c.speeds.length > 1 ? 's' : ''}</span>`);
      if (c.removed.length || c.speeds.length) badges.push(`<span class="badge">→ ${fmt(keptSeconds(c))}</span>`);
    }
    el.innerHTML = `
      <div class="name"></div>
      <div class="meta">${meta}</div>
      <div class="badges">${badges.join('')}</div>
      ${c.status === 'loading' ? `<div class="meta">${c.stage || 'Waiting'}…</div><div class="mini-bar"><div style="width:${Math.round((c.progress || 0) * 100)}%"></div></div>` : ''}
      ${c.status === 'error' ? '<div class="err"></div>' : ''}
      <div class="ctrl"><button data-a="rebuild" title="Rebuild: clear this clip's saved preview and read the file again (sound, waveform, HDR10+). Your edits stay.">⟳</button><button data-a="up" title="Move up">▲</button><button data-a="down" title="Move down">▼</button><button data-a="del" title="Remove from project">✕</button></div>`;
    el.querySelector('.name').textContent = c.name;
    if (c.status === 'error') el.querySelector('.err').textContent = c.err;
    el.addEventListener('click', (e) => {
      const a = e.target.dataset && e.target.dataset.a;
      if (a === 'up' && i > 0) { pushUndo('moving a clip', null); [S.clips[i - 1], S.clips[i]] = [S.clips[i], S.clips[i - 1]]; if (S.cur === i) S.cur--; else if (S.cur === i - 1) S.cur++; changed(); return; }
      if (a === 'down' && i < S.clips.length - 1) { pushUndo('moving a clip', null); [S.clips[i + 1], S.clips[i]] = [S.clips[i], S.clips[i + 1]]; if (S.cur === i) S.cur++; else if (S.cur === i + 1) S.cur--; changed(); return; }
      if (a === 'rebuild') { rebuildClip(c); return; }
      if (a === 'del') {
        if (!confirm(`Remove ${c.name} from the project? (The file itself is not touched. Undo brings it back.)`)) return;
        pushUndo(`removing ${c.name}`, null);
        S.clips.splice(i, 1);
        if (S.cur >= S.clips.length) S.cur = S.clips.length - 1;
        selectClip(S.cur);
        changed();
        return;
      }
      if (i !== S.cur) selectClip(i);
    });
    list.appendChild(el);
  });
  const rd = S.clips.filter((c) => ready(c));
  const tot = rd.reduce((s, c) => s + keptSeconds(c), 0) - crossOverlapSeconds();
  $('joinSummary').textContent = rd.length ? `Result: ${fmt(tot)} from ${rd.length} clip${rd.length > 1 ? 's' : ''}` : '';
  $('btnExport').disabled = !rd.length || !!S.tracking;
  $('empty').classList.toggle('hidden', S.clips.length > 0);
}

function selectClip(i) {
  const prev = cur();
  if (prev) prev.lastFrame = S.frame;
  S.cur = i;
  S.sel = null; S.markA = null; S.markB = null; S.zoom = { a: 0, b: 1 };
  const c = cur();
  vid.pause();
  if (!c) { vid.removeAttribute('src'); vid.load(); changed(); return; }
  S.frame = c.lastFrame || 0;
  if (ready(c)) loadVideo(c);
  else { vid.removeAttribute('src'); vid.load(); }
  changed();
}

function loadVideo(c) {
  vid.src = c.proxy.url;
  vid.onloadeddata = () => { seekFrame(S.frame); };
}

async function addFiles(files, restore) {
  for (const f of files) {
    if (S.clips.some((c) => c.file === f)) continue;
    const name = f.split(/[\\/]/).pop();
    const c = { file: f, name, status: 'loading', stage: 'Waiting', progress: 0, removed: [], tracks: [], speeds: [] };
    if (restore && restore[f]) { c.removed = restore[f].removed || []; c.tracks = restore[f].tracks || []; c.speeds = restore[f].speeds || []; c.transIn = restore[f].transIn || null; c.rot = restore[f].rot || 0; }
    S.clips.push(c);
    if (S.cur < 0) selectClip(S.clips.length - 1);
    renderClips();
    api.importClip(f).then((data) => {
      Object.assign(c, data, { status: 'ready' });
      if (c === cur()) { loadVideo(c); }
      setStatus(`${c.name} ready`);
      changed();
    }).catch((e) => {
      c.status = 'error'; c.err = errMsg(e);
      setStatus(`Could not load ${c.name}`);
      renderClips();
    });
  }
  saveSessionSoon();
}

// Clears a clip's saved preview and reads the file again. Cuts, plates and
// other edits are kept.
function rebuildClip(c, { fresh = true } = {}) {
  if (c.status === 'loading') return;
  // let go of the preview file first (Windows can't delete a file that is open)
  if (vid.src && c.proxy && vid.src === c.proxy.url) { vid.pause(); vid.removeAttribute('src'); vid.load(); }
  if (vidN.dataset.file === c.file) { vidN.removeAttribute('src'); vidN.load(); vidN.dataset.file = ''; }
  c.status = 'loading'; c.stage = fresh ? 'Rebuilding preview' : 'Reading again'; c.progress = 0; c._w = null;
  renderClips(); requestRender();
  api.importClip(c.file, { fresh }).then((data) => {
    Object.assign(c, data, { status: 'ready' });
    if (c === cur()) loadVideo(c);
    setStatus(`${c.name} ready${c.info.hasHdr10Plus ? ' — HDR10+ read' : c.info.hdr10plusUnread ? ' — HDR10+ still could not be read, check hdr10plus_tool in Settings' : ''}`);
    changed();
  }).catch((e) => { c.status = 'error'; c.err = errMsg(e); setStatus(`Could not load ${c.name}`); renderClips(); });
}
// after the tools are set up, clips whose HDR10+ could not be read are read again
function retryUnreadHdr10Plus() {
  const todo = S.clips.filter((c) => ready(c) && c.info.hdr10plusUnread);
  for (const c of todo) rebuildClip(c, { fresh: false });
  if (todo.length) setStatus(`Reading HDR10+ again for ${todo.length} clip${todo.length > 1 ? 's' : ''}…`);
}

api.onClipProgress((p) => {
  const c = S.clips.find((x) => x.file === p.file);
  if (!c || c.status !== 'loading') return;
  c.stage = p.stage; c.progress = p.frac;
  renderClips();
});

// ---------------------------------------------------------------- video
function seekFrame(n) {
  const c = cur();
  if (!ready(c)) return;
  n = clamp(Math.round(n), 0, c.info.nFrames - 1);
  S.frame = n;
  if (!vid.paused) vid.pause();
  const pt = c.proxy.times;
  const i = Math.min(n, pt.length - 1);
  const next = i + 1 < pt.length ? pt[i + 1] : pt[i] + 1 / 30;
  const t = pt[i] + 0.3 * (next - pt[i]); // the player's clock is the preview file's own timestamps
  if (Math.abs(vid.currentTime - t) > 1e-4) vid.currentTime = t;
  requestRender();
}

function onVideoFrame(_now, md) {
  const c = cur();
  if (ready(c) && !vid.paused) {
    const pt = c.proxy.times;
    let f = indexAtTime(pt, md.mediaTime);
    // play the edit: jump over cut parts
    const rem = TL.mergeRanges(c.removed);
    const r = rem.find(([a, b]) => f >= a && f <= b);
    if (r) {
      if (r[1] + 1 >= c.info.nFrames) { vid.pause(); f = r[0] > 0 ? r[0] - 1 : 0; seekFrame(f); }
      else { S.frame = r[1] + 1; const t = pt[r[1] + 1] + 0.001; vid.currentTime = t; }
    } else S.frame = f;
    applyPlaybackRate(c);
    requestRender();
  }
  vid.requestVideoFrameCallback(onVideoFrame);
}
vid.requestVideoFrameCallback(onVideoFrame);
vid.addEventListener('seeked', requestRender);
vid.addEventListener('play', () => { $('btnPlay').textContent = '❚❚'; });
vid.addEventListener('pause', () => { $('btnPlay').textContent = '▶'; requestRender(); });
vid.addEventListener('ended', () => { $('btnPlay').textContent = '▶'; });

// the preview plays slow-motion parts at their slowed speed
function applyPlaybackRate(c) {
  const sp = Math.max(0.0625, TL.speedAt(c.speeds, S.frame));
  if (Math.abs(vid.playbackRate - sp) > 1e-4) vid.playbackRate = sp;
}

function togglePlay() {
  if (!ready()) return;
  if (vid.paused) {
    if (S.frame >= N() - 1) seekFrame(0);
    applyPlaybackRate(cur());
    vid.play().catch(() => {});
  } else { vid.pause(); seekFrame(S.frame); }
}

// ---------------------------------------------------------------- overlay
function contentRect() {
  const c = cur();
  const W = viewer.clientWidth, H = viewer.clientHeight;
  if (!ready(c)) return { x: 0, y: 0, w: W, h: H };
  const ar = rotOf(c) % 180 ? c.proxy.h / c.proxy.w : c.proxy.w / c.proxy.h;
  let w = W, h = W / ar;
  if (h > H) { h = H; w = H * ar; }
  return { x: (W - w) / 2, y: (H - h) / 2, w, h };
}
function toScreen(b, r) { return { x: r.x + b.x * r.w, y: r.y + b.y * r.h, w: b.w * r.w, h: b.h * r.h }; }
function toNorm(e, r) {
  const bb = overlay.getBoundingClientRect();
  return { x: (e.clientX - bb.left - r.x) / r.w, y: (e.clientY - bb.top - r.y) / r.h };
}

let drag = null;

// The preview video is turned with CSS so it fills the turned view rect.
let vidLayout = '';
function layoutVideo(c, r) {
  const rot = rotOf(c);
  const key = rot ? `${rot}|${r.x}|${r.y}|${r.w}|${r.h}` : '0';
  if (key === vidLayout) return;
  vidLayout = key;
  if (!rot) { vid.style.cssText = ''; return; }
  const w = rot % 180 ? r.h : r.w, h = rot % 180 ? r.w : r.h;
  vid.style.cssText = `inset:auto;left:${r.x + r.w / 2 - w / 2}px;top:${r.y + r.h / 2 - h / 2}px;width:${w}px;height:${h}px;transform:rotate(${rot}deg)`;
}
// Draws a frame of a clip's picture (video, or a canvas of it) turned into the view rect r.
function drawPicture(src, r, rot) {
  if (!rot) { octx.drawImage(src, r.x, r.y, r.w, r.h); return; }
  const w = rot % 180 ? r.h : r.w, h = rot % 180 ? r.w : r.h;
  octx.save();
  octx.translate(r.x + r.w / 2, r.y + r.h / 2);
  octx.rotate((rot * Math.PI) / 180);
  octx.drawImage(src, -w / 2, -h / 2, w, h);
  octx.restore();
}

function renderOverlay() {
  const dpr = window.devicePixelRatio || 1;
  const W = viewer.clientWidth, H = viewer.clientHeight;
  if (overlay.width !== Math.round(W * dpr) || overlay.height !== Math.round(H * dpr)) {
    overlay.width = Math.round(W * dpr); overlay.height = Math.round(H * dpr);
  }
  octx.setTransform(dpr, 0, 0, dpr, 0, 0);
  octx.clearRect(0, 0, W, H);
  const c = cur();
  $('cutBanner').classList.toggle('hidden', !(ready(c) && TL.mergeRanges(c.removed).some(([a, b]) => S.frame >= a && S.frame <= b)));
  if (!ready(c)) {
    if (c && c.status === 'loading') {
      octx.fillStyle = '#8b93a1'; octx.font = '14px Segoe UI, sans-serif'; octx.textAlign = 'center';
      octx.fillText(`${c.stage || 'Preparing'}… ${Math.round((c.progress || 0) * 100)}%`, W / 2, H / 2);
    }
    return;
  }
  const r = contentRect();
  layoutVideo(c, r);
  const rot = rotOf(c);
  const pad = Number(S.settings.BOX_PADDING || 12);
  const boxes = [];
  for (const t of c.tracks) {
    let b = viewBox(t, S.frame, c);
    if (drag && drag.trackId === t.id && drag.cur) b = drag.cur;
    if (b) boxes.push({ t, b });
  }
  if (drag && drag.mode === 'new' && drag.cur) boxes.push({ t: null, b: drag.cur });
  // blur preview (approximate look of the export)
  if (S.blurPrev && vid.readyState >= 2) {
    const strength = Number(S.settings.BLUR_STRENGTH || 24);
    const scale = r.w / viewSize(c).w;
    for (const { t, b } of boxes) {
      if (!t) continue;
      const p = toScreen(TL.padBox(b, pad), r);
      octx.save();
      octx.beginPath(); octx.rect(p.x, p.y, p.w, p.h); octx.clip();
      if ((S.settings.BLUR_STYLE || 'blur') === 'pixelate') {
        const cell = Math.max(2, strength * scale);
        octx.imageSmoothingEnabled = false;
        const pw = rot % 180 ? r.h : r.w, ph = rot % 180 ? r.w : r.h; // the clip's own picture size on screen
        const tw = Math.max(1, Math.round(pw / cell)), th = Math.max(1, Math.round(ph / cell));
        const tmp = renderOverlay.tmp || (renderOverlay.tmp = document.createElement('canvas'));
        tmp.width = tw; tmp.height = th;
        tmp.getContext('2d').drawImage(vid, 0, 0, tw, th);
        drawPicture(tmp, r, rot);
      } else {
        octx.filter = `blur(${Math.max(3, strength * scale * 0.45).toFixed(1)}px)`;
        drawPicture(vid, r, rot);
      }
      octx.restore();
    }
  }
  drawTransitionPreview(c, r);
  for (const { t, b } of boxes) {
    const color = t ? t.color : '#ffffff';
    const s = toScreen(b, r);
    const p = toScreen(TL.padBox(b, pad), r);
    const selected = t && t.id === S.sel;
    octx.lineWidth = selected ? 2 : 1.5;
    octx.strokeStyle = color;
    octx.setLineDash([5, 4]);
    octx.strokeRect(p.x, p.y, p.w, p.h);
    octx.setLineDash([]);
    octx.strokeRect(s.x, s.y, s.w, s.h);
    if (t) {
      const key = t.keys[S.frame];
      const label = `${t.name}${key && key.m === 'manual' ? ' ◆' : ''}${key && key.c !== undefined && key.c < 0.6 ? ' ⚠' : ''}`;
      octx.font = '600 12px Segoe UI, sans-serif';
      octx.textAlign = 'left';
      const tw = octx.measureText(label).width + 10;
      octx.fillStyle = color;
      octx.fillRect(p.x, p.y - 18, tw, 17);
      octx.fillStyle = '#111';
      octx.fillText(label, p.x + 5, p.y - 5);
    }
    if (selected) {
      octx.fillStyle = color;
      for (const [hx, hy] of handlePoints(s)) octx.fillRect(hx - 4, hy - 4, 8, 8);
    }
  }
}

// Shows what a transition will look like at this frame: the fade to black, or
// the other clip mixed in for a crossfade (from a hidden second preview video).
const vidN = $('vidN');
let wantN = null;
vidN.addEventListener('seeked', () => { vidN.dataset.frame = wantN ? String(wantN.frame) : ''; requestRender(); });
vidN.addEventListener('loadeddata', () => { if (wantN) seekNeighbor(); });
function seekNeighbor() {
  const c = S.clips.find((x) => x.file === wantN.file);
  if (!ready(c)) return;
  const pt = c.proxy.times, i = Math.min(wantN.frame, pt.length - 1);
  const next = i + 1 < pt.length ? pt[i + 1] : pt[i] + 1 / 30;
  vidN.dataset.frame = '';
  vidN.currentTime = pt[i] + 0.3 * (next - pt[i]);
}
function drawNeighbor(c, frame, alpha, r) {
  if (vidN.dataset.file !== c.file) { vidN.dataset.file = c.file; vidN.dataset.frame = ''; wantN = { file: c.file, frame }; vidN.src = c.proxy.url; return; }
  if (!wantN || wantN.frame !== frame || wantN.file !== c.file) { wantN = { file: c.file, frame }; if (vidN.readyState >= 1) seekNeighbor(); return; }
  if (vidN.readyState >= 2 && vidN.dataset.frame === String(frame)) {
    const v = viewSize(c), k = Math.min(r.w / v.w, r.h / v.h);
    const rr = { x: r.x + (r.w - v.w * k) / 2, y: r.y + (r.h - v.h * k) / 2, w: v.w * k, h: v.h * k };
    octx.save(); octx.globalAlpha = alpha;
    if (rr.w < r.w - 1 || rr.h < r.h - 1) { octx.fillStyle = '#000'; octx.fillRect(r.x, r.y, r.w, r.h); }
    drawPicture(vidN, rr, rotOf(c)); octx.restore();
  }
}
function transTag(text, r) {
  octx.font = '600 12px Segoe UI, sans-serif'; octx.textAlign = 'left';
  const w = octx.measureText(text).width + 14;
  octx.fillStyle = 'rgba(20,28,48,.85)'; octx.fillRect(r.x + r.w - w - 10, r.y + 10, w, 20);
  octx.fillStyle = '#cfe0ff'; octx.fillText(text, r.x + r.w - w - 3, r.y + 24);
}
function drawTransitionPreview(c, r) {
  const z = transZones(S.cur);
  const any = z.into || z.out;
  if (!any) return;
  const sf = any.sf, pos = sf.fr.indexOf(S.frame);
  if (pos < 0) return;
  const L = sf.fr.length;
  if (z.into && pos < z.into.n) {
    const n = z.into.n;
    if (z.into.type === 'black') {
      octx.fillStyle = `rgba(0,0,0,${(1 - pos / n).toFixed(3)})`; octx.fillRect(r.x, r.y, r.w, r.h);
      transTag('◐ fading in from black', r);
    } else {
      const o = z.into.osf.fr;
      drawNeighbor(z.into.other, o[o.length - n + pos], 1 - pos / n, r);
      transTag(`⧉ crossfade from ${z.into.other.name}`, r);
    }
  }
  if (z.out && pos >= L - z.out.n) {
    const n = z.out.n, k = pos - (L - n);
    if (z.out.type === 'black') {
      octx.fillStyle = `rgba(0,0,0,${(k / n).toFixed(3)})`; octx.fillRect(r.x, r.y, r.w, r.h);
      transTag('◐ fading out to black', r);
    } else {
      drawNeighbor(z.out.other, z.out.osf.fr[k], k / n, r);
      transTag(`⧉ crossfade into ${z.out.other.name}`, r);
    }
  }
}

function handlePoints(s) {
  return [[s.x, s.y], [s.x + s.w, s.y], [s.x, s.y + s.h], [s.x + s.w, s.y + s.h],
    [s.x + s.w / 2, s.y], [s.x + s.w / 2, s.y + s.h], [s.x, s.y + s.h / 2], [s.x + s.w, s.y + s.h / 2]];
}
const HANDLE_NAMES = ['tl', 'tr', 'bl', 'br', 't', 'b', 'l', 'r'];
const HANDLE_CURSOR = { tl: 'nwse-resize', br: 'nwse-resize', tr: 'nesw-resize', bl: 'nesw-resize', t: 'ns-resize', b: 'ns-resize', l: 'ew-resize', r: 'ew-resize' };

function hitTest(e) {
  const c = cur(); const r = contentRect();
  const bb = overlay.getBoundingClientRect();
  const mx = e.clientX - bb.left, my = e.clientY - bb.top;
  if (S.sel) {
    const t = trackById(S.sel);
    const b = t && viewBox(t, S.frame, c);
    if (b) {
      const s = toScreen(b, r);
      const hp = handlePoints(s);
      for (let i = 0; i < hp.length; i++) {
        if (Math.abs(mx - hp[i][0]) <= 7 && Math.abs(my - hp[i][1]) <= 7) return { kind: 'handle', handle: HANDLE_NAMES[i], t, b };
      }
    }
  }
  for (let i = c.tracks.length - 1; i >= 0; i--) {
    const t = c.tracks[i];
    const b = viewBox(t, S.frame, c);
    if (!b) continue;
    const s = toScreen(TL.padBox(b, Number(S.settings.BOX_PADDING || 12)), r);
    if (mx >= s.x && mx <= s.x + s.w && my >= s.y && my <= s.y + s.h) return { kind: 'box', t, b };
  }
  return { kind: 'none' };
}

function normBox(b) {
  let { x, y, w, h } = b;
  if (w < 0) { x += w; w = -w; }
  if (h < 0) { y += h; h = -h; }
  x = clamp(x, -0.5, 1); y = clamp(y, -0.5, 1);
  return { x, y, w: Math.min(w, 1.5), h: Math.min(h, 1.5) };
}

overlay.addEventListener('mousedown', (e) => {
  if (e.button !== 0 || !ready() || S.tracking) return;
  if (!vid.paused) togglePlay();
  const r = contentRect();
  const p = toNorm(e, r);
  const hit = hitTest(e);
  if (hit.kind === 'handle') {
    drag = { mode: 'resize', handle: hit.handle, trackId: hit.t.id, orig: { ...hit.b }, cur: { ...hit.b }, start: p };
  } else if (hit.kind === 'box') {
    S.sel = hit.t.id;
    drag = { mode: 'move', trackId: hit.t.id, orig: { ...hit.b }, cur: { ...hit.b }, start: p, moved: false };
    renderPlates();
  } else {
    drag = { mode: 'new', start: p, cur: { x: p.x, y: p.y, w: 0, h: 0 } };
  }
  requestRender();
});

window.addEventListener('mousemove', (e) => {
  if (!ready()) return;
  if (!drag) {
    if (e.target === overlay && !S.tracking) {
      const hit = hitTest(e);
      overlay.style.cursor = hit.kind === 'handle' ? HANDLE_CURSOR[hit.handle] : hit.kind === 'box' ? 'move' : 'crosshair';
    }
    return;
  }
  const r = contentRect();
  const p = toNorm(e, r);
  const dx = p.x - drag.start.x, dy = p.y - drag.start.y;
  if (drag.mode === 'new') drag.cur = normBox({ x: drag.start.x, y: drag.start.y, w: dx, h: dy });
  else if (drag.mode === 'move') { drag.cur = { ...drag.orig, x: drag.orig.x + dx, y: drag.orig.y + dy }; drag.moved = true; }
  else {
    let { x, y, w, h } = drag.orig;
    const hd = drag.handle;
    if (hd.includes('l')) { x += dx; w -= dx; }
    if (hd.includes('r')) { w += dx; }
    if (hd.includes('t')) { y += dy; h -= dy; }
    if (hd === 'b' || hd === 'bl' || hd === 'br') { h += dy; }
    drag.cur = normBox({ x, y, w, h });
  }
  requestRender();
});

window.addEventListener('mouseup', () => {
  if (!drag) return;
  const c = cur();
  const r = contentRect();
  const d = drag;
  drag = null;
  if (!ready(c)) return;
  if (d.mode === 'new') {
    const pw = d.cur.w * r.w, ph = d.cur.h * r.h;
    if (pw < 6 || ph < 4) { S.sel = null; changed(); return; }
    pushUndo('new plate');
    const n = c.tracks.length;
    const used = new Set(c.tracks.map((t) => t.name));
    let k = n + 1;
    while (used.has(`Plate ${k}`)) k++;
    const t = { id: `t${Date.now().toString(36)}${Math.random().toString(36).slice(2, 5)}`, name: `Plate ${k}`,
      color: COLORS[n % COLORS.length], keys: { [S.frame]: { ...unrotBox(d.cur, rotOf(c)), m: 'manual' } } };
    c.tracks.push(t);
    S.sel = t.id;
    setStatus(`${t.name} added on frame ${S.frame}. Press Track ▶ (T) to follow it.`);
    $('hint').textContent = 'Now press Track ▶ (T)';
  } else if (d.mode === 'move' && !d.moved) {
    // simple click selects
  } else {
    pushUndo('moving a plate box');
    const t = trackById(d.trackId);
    if (t) t.keys[S.frame] = { ...unrotBox(d.cur, rotOf(c)), m: 'manual' };
    setStatus(`Box fixed on frame ${S.frame}. Track again from here if needed.`);
  }
  changed();
});

// ---------------------------------------------------------------- plates
function renderPlates() {
  const c = cur();
  const list = $('plateList');
  list.innerHTML = '';
  const tracks = ready(c) ? c.tracks : [];
  $('plateCount').textContent = tracks.length ? `(${tracks.length})` : '';
  if (!tracks.length) {
    list.innerHTML = '<div class="plate-empty small">No plates yet. Drag a box around a plate on the video.</div>';
  }
  for (const t of tracks) {
    const rg = rangeC(t);
    const el = document.createElement('div');
    el.className = 'plate' + (t.id === S.sel ? ' active' : '');
    const keys = Object.values(t.keys);
    const low = keys.filter((k) => k.c !== undefined && k.c < 0.6).length;
    const span = rg ? `frames ${rg[0]}–${rg[1]} · ${fmt(frameTime(c, rg[1]) - frameTime(c, rg[0]))}` : 'empty';
    el.innerHTML = `<span class="swatch" style="background:${t.color}"></span>
      <div><div class="pname"></div><div class="pmeta">${span}</div>${low ? `<div class="warnc">⚠ ${low} uncertain frame${low > 1 ? 's' : ''} — check them</div>` : ''}</div>`;
    el.querySelector('.pname').textContent = t.name;
    el.addEventListener('click', () => {
      S.sel = t.id;
      if (rg && (S.frame < rg[0] || S.frame > rg[1])) seekFrame(rg[0]);
      renderPlates(); requestRender();
    });
    list.appendChild(el);
  }
  const has = !!(S.sel && trackById(S.sel));
  const busy = !!S.tracking;
  for (const id of ['btnTrackBack', 'btnTrackFwd', 'btnEndHere', 'btnStartHere', 'btnDelPlate']) $(id).disabled = !has || busy;
  $('btnTrackStop').classList.toggle('hidden', !busy);
  $('btnTrackFwd').classList.toggle('hidden', busy);
  $('btnTrackBack').classList.toggle('hidden', busy);
}

function showTrackStatus(text, kind) {
  const el = $('trackStatus');
  el.textContent = text;
  el.className = 'status-box' + (kind ? ' ' + kind : '');
  el.classList.toggle('hidden', !text);
}

async function trackSelected(dir) {
  const c = cur();
  const t = trackById(S.sel);
  if (!ready(c) || !t || S.tracking) return;
  const f = S.frame;
  const box = boxAtC(t, f);
  if (!box) { showTrackStatus('The plate has no box on this frame. Draw or move its box here first, then track.', 'warn'); return; }
  pushUndo('tracking');
  if (!t.keys[f] || t.keys[f].m !== 'manual') t.keys[f] = { ...box, m: 'manual' };
  const nm = TL.nextManualKey(t, f, dir);
  const stop = dir > 0 ? (nm !== null ? nm - 1 : c.info.nFrames - 1) : (nm !== null ? nm + 1 : 0);
  if ((dir > 0 && stop <= f) || (dir < 0 && stop >= f)) { showTrackStatus('Nothing to track in that direction.', 'warn'); return; }
  for (const k of Object.keys(t.keys).map(Number)) {
    const inRange = dir > 0 ? (k > f && k <= stop) : (k < f && k >= stop);
    if (inRange && t.keys[k].m !== 'manual') delete t.keys[k];
  }
  S.stamp++;
  S.tracking = { file: c.file, trackId: t.id, dir };
  vid.pause();
  renderPlates(); renderClips();
  showTrackStatus(`Tracking ${dir > 0 ? 'forward' : 'backward'} from frame ${f}…`);
  try {
    const res = await api.track({ file: c.file, trackId: t.id, startFrame: f, box: { x: box.x, y: box.y, w: box.w, h: box.h }, dir, stopFrame: stop });
    const next = res.endFrame + dir;
    if (res.reason === 'end of range') {
      showTrackStatus(nm !== null ? `Tracked up to your fixed box at frame ${nm}.` : `Tracked to the ${dir > 0 ? 'end' : 'start'} of the clip.`, 'ok');
      if (nm !== null) seekFrame(nm);
    } else if (res.reason === 'stopped') {
      showTrackStatus(`Stopped at frame ${res.endFrame}.`);
    } else if (res.reason === 'left the frame') {
      showTrackStatus(`The plate left the picture after frame ${res.endFrame}. Tracking ended there.`, 'ok');
      seekFrame(res.endFrame);
    } else {
      showTrackStatus(`Lost the plate at frame ${next}. The box was kept up to frame ${res.endFrame}. ` +
        'If the plate is still visible, move the box onto it here and press Track again. If it is hidden, use End here.', 'warn');
      seekFrame(clamp(next, 0, c.info.nFrames - 1));
    }
  } catch (e) {
    showTrackStatus(`Tracking failed: ${errMsg(e)}`, 'warn');
  } finally {
    S.tracking = null;
    changed();
  }
}

api.onTrackBoxes(({ file, trackId, boxes }) => {
  const c = S.clips.find((x) => x.file === file);
  const t = c && c.tracks.find((x) => x.id === trackId);
  if (!t) return;
  let last = null;
  for (const [f, b] of Object.entries(boxes)) {
    const k = Number(f);
    if (t.keys[k] && t.keys[k].m === 'manual') continue;
    t.keys[k] = { x: b.x, y: b.y, w: b.w, h: b.h, m: 'auto', c: b.c };
    last = k;
  }
  S.stamp++;
  // only follow the playhead while this track is still running (a late batch
  // must not overwrite the final message)
  if (c === cur() && last !== null && S.tracking && S.tracking.trackId === trackId) {
    showTrackStatus(`Tracking… frame ${last} (match ${(boxes[last].c * 100).toFixed(0)}%)`);
    seekFrame(last);
    renderPlates();
  } else if (c === cur()) requestRender();
});

function endHere() {
  const t = trackById(S.sel); if (!t) return;
  const b = boxAtC(t, S.frame);
  if (!b) { showTrackStatus('The plate is not on this frame.', 'warn'); return; }
  pushUndo('End here');
  for (const k of Object.keys(t.keys).map(Number)) if (k > S.frame) delete t.keys[k];
  t.keys[S.frame] = { ...b, m: 'manual' };
  showTrackStatus(`${t.name} now ends at frame ${S.frame}.`, 'ok');
  changed();
}
function startHere() {
  const t = trackById(S.sel); if (!t) return;
  const b = boxAtC(t, S.frame);
  if (!b) { showTrackStatus('The plate is not on this frame.', 'warn'); return; }
  pushUndo('Start here');
  for (const k of Object.keys(t.keys).map(Number)) if (k < S.frame) delete t.keys[k];
  t.keys[S.frame] = { ...b, m: 'manual' };
  showTrackStatus(`${t.name} now starts at frame ${S.frame}.`, 'ok');
  changed();
}
function deletePlate() {
  const c = cur(); const t = trackById(S.sel); if (!t) return;
  pushUndo('deleting a plate');
  c.tracks = c.tracks.filter((x) => x !== t);
  S.sel = null;
  showTrackStatus('');
  changed();
}

// ---------------------------------------------------------------- cuts
function addRemoved(a, b) {
  const c = cur(); if (!ready(c) || a > b) return;
  pushUndo('cut');
  c.removed = TL.mergeRanges([...c.removed, [a, b]]);
  if (TL.keepRanges(c.info.nFrames, c.removed).length === 0) setStatus('Everything in this clip is cut: it will be skipped on export.');
  changed();
}
function trimStart() { if (S.frame > 0) { addRemoved(0, S.frame - 1); setStatus(`Trimmed: clip now starts at frame ${S.frame}`); } }
function trimEnd() { if (S.frame < N() - 1) { addRemoved(S.frame + 1, N() - 1); setStatus(`Trimmed: clip now ends at frame ${S.frame}`); } }
function markA() { S.markA = S.frame; setStatus(`A = frame ${S.frame}`); requestRender(); }
function markB() { S.markB = S.frame; setStatus(`B = frame ${S.frame}`); requestRender(); }
function cutAB() {
  if (S.markA === null || S.markB === null) { setStatus('Set both A and B first (A and B keys).'); return; }
  const a = Math.min(S.markA, S.markB), b = Math.max(S.markA, S.markB);
  addRemoved(a, b);
  setStatus(`Cut out frames ${a}–${b}`);
  S.markA = S.markB = null;
  requestRender();
}
function restorePart() {
  const c = cur(); if (!ready(c)) return;
  const rem = TL.mergeRanges(c.removed);
  const hit = rem.find(([a, b]) => S.frame >= a && S.frame <= b);
  if (!hit) { setStatus('Move the playhead into a cut part (red) to restore it.'); return; }
  pushUndo('restoring a part');
  c.removed = rem.filter((r) => r !== hit);
  setStatus(`Restored frames ${hit[0]}–${hit[1]}`);
  changed();
}

// ---------------------------------------------------------------- slow motion
function curSlow() {
  const c = cur();
  return ready(c) ? (c.speeds || []).find((p) => S.frame >= p.a && S.frame <= p.b) || null : null;
}
function slowAB() {
  const c = cur(); if (!ready(c)) return;
  if (S.markA === null || S.markB === null) { setStatus('Set A and B around the part to slow down first (A and B keys), or use ⚡ Find lightning.'); return; }
  const a = Math.min(S.markA, S.markB), b = Math.max(S.markA, S.markB);
  const sp = Number($('selSpeed').value);
  pushUndo('slow down');
  c.speeds = TL.setSpeed(c.speeds, a, b, sp);
  S.markA = S.markB = null;
  setStatus(`Frames ${a}–${b} now play at ${speedLabel(sp)} speed`);
  changed();
}
function speedNormalHere() {
  const c = cur(); const p = curSlow();
  if (!p) { setStatus('Move the playhead into a slow part (purple) first.'); return; }
  pushUndo('normal speed');
  c.speeds = TL.setSpeed(c.speeds, p.a, p.b, 1);
  setStatus(`Frames ${p.a}–${p.b} back to normal speed`);
  changed();
}
function speedSelected() {
  const v = Number($('selSpeed').value);
  const c = cur(); const p = curSlow();
  if (p && ready(c)) {
    pushUndo('speed change');
    c.speeds = TL.setSpeed(c.speeds, p.a, p.b, v);
    setStatus(`Frames ${p.a}–${p.b} now play at ${speedLabel(v)} speed`);
    changed();
  }
  S.settings.SLOW_SPEED = String(v);
  api.saveSettings({ SLOW_SPEED: String(v) });
}
let findingFlashes = false;
async function findLightning() {
  const c = cur(); if (!ready(c) || findingFlashes) return;
  findingFlashes = true;
  $('btnFindFlash').disabled = true;
  $('slowInfo').textContent = 'Looking for lightning…';
  try {
    const r = await api.findFlashes(c.file);
    if (!r.events.length) {
      $('slowInfo').textContent = 'No lightning flashes found in this clip. You can still slow down any part: Mark A, Mark B, then Slow down A–B.';
      setStatus('No lightning found');
      return;
    }
    const sp = Number($('selSpeed').value);
    const t = c.info.times;
    pushUndo('Find lightning', c);
    let speeds = c.speeds;
    for (const e of r.events) {
      const a = indexAtTime(t, t[e.a] - r.before);
      const b = Math.min(c.info.nFrames - 1, indexAtTime(t, t[e.b] + r.after));
      speeds = TL.setSpeed(speeds, a, b, sp);
    }
    c.speeds = speeds;
    changed();
    seekFrame(r.events[0].a);
    const msg = `Found ${r.events.length} flash${r.events.length > 1 ? 'es' : ''}. ${r.events.length > 1 ? 'They now play' : 'It now plays'} at ${speedLabel(sp)} speed. ` +
      'Drag the edges of the purple parts on the timeline to adjust, or pick another speed.';
    setStatus(msg);
    showSlowNote(msg);
  } catch (e) {
    $('slowInfo').textContent = `Lightning search failed: ${errMsg(e)}`;
  } finally {
    findingFlashes = false;
    $('btnFindFlash').disabled = false;
  }
}
let slowNote = null;
function showSlowNote(m) { slowNote = { m, f: S.frame }; requestRender(); }
api.onFlashProgress((p) => { if (findingFlashes) $('slowInfo').textContent = `Looking for lightning… ${Math.round(p.frac * 100)}%`; });

// ---------------------------------------------------------------- sound
// The preview plays the clip's own sound (only while playing, at the same
// speed as the picture, so slow parts sound slowed down too).
function applySound() {
  vid.volume = S.sound.volume;
  vid.muted = S.sound.muted || S.sound.volume === 0;
  $('btnMute').textContent = vid.muted ? '🔇' : '🔊';
  $('btnMute').title = vid.muted ? 'Sound is off — click to turn it on (M)' : 'Sound on — click to turn it off (M)';
  $('volume').value = String(S.sound.volume);
}
function toggleMute() {
  if (!S.sound.muted && S.sound.volume === 0) S.sound.volume = 1;
  else S.sound.muted = !S.sound.muted;
  applySound(); saveSessionSoon();
  setStatus(vid.muted ? 'Sound off' : 'Sound on');
}
$('btnMute').addEventListener('click', toggleMute);
$('volume').addEventListener('input', (e) => { S.sound.volume = Number(e.target.value); S.sound.muted = false; applySound(); saveSessionSoon(); });
applySound();

// ---------------------------------------------------------------- timeline size
// Drag the bar above the play buttons to make the timeline bigger, like in other editors.
const TL_MIN = 140;
function setTimelineHeight(h) {
  const stage = document.querySelector('.stage');
  const max = Math.max(TL_MIN, stage.clientHeight - 230);
  S.tlHeight = Math.round(clamp(Number(h) || 180, TL_MIN, max));
  document.querySelector('.timeline-wrap').style.height = `${S.tlHeight}px`;
  vidLayout = ''; requestRender();
}
let splitDrag = null;
$('tlSplit').addEventListener('mousedown', (e) => {
  if (e.button !== 0) return;
  e.preventDefault();
  splitDrag = { y: e.clientY, h: S.tlHeight };
  $('tlSplit').classList.add('drag');
});
window.addEventListener('mousemove', (e) => { if (splitDrag) setTimelineHeight(splitDrag.h - (e.clientY - splitDrag.y)); });
window.addEventListener('mouseup', () => { if (splitDrag) { splitDrag = null; $('tlSplit').classList.remove('drag'); saveSessionSoon(); } });
$('tlSplit').addEventListener('dblclick', () => { setTimelineHeight(180); saveSessionSoon(); });
window.addEventListener('resize', () => setTimelineHeight(S.tlHeight));

// ---------------------------------------------------------------- timeline
const TLY = { ruler: 18, kept: 20, slow: 12, audio: 30, row: 13, gap: 3, left: 10, right: 10 };
// the lanes grow when the timeline is made bigger
function layoutLanes(H) {
  const extra = Math.max(0, H - 180);
  TLY.kept = Math.round(20 + Math.min(40, extra * 0.2));
  TLY.audio = Math.round(30 + Math.min(160, extra * 0.5));
}
// waveform data of a clip, decoded once
function waveOf(c) {
  if (!c.wave) return null;
  if (!c._w || c._w.src !== c.wave) {
    const dec = (b64) => { const bin = atob(b64); const a = new Int8Array(bin.length); for (let i = 0; i < bin.length; i++) a[i] = bin.charCodeAt(i) << 24 >> 24; return a; };
    c._w = { src: c.wave, rate: c.wave.rate, peak: c.wave.peak, min: dec(c.wave.min), max: dec(c.wave.max) };
  }
  return c._w;
}
// source time (file clock) at a fractional frame position
function timeAtF(c, f) {
  const n = c.info.nFrames, t = c.info.times;
  const i = clamp(Math.floor(f), 0, n - 1);
  const d = (i + 1 < n ? t[i + 1] : t[i] + lastDur(c)) - t[i];
  return t[i] + clamp(f - i, 0, 1) * d;
}
function drawWave(c, W, y, h) {
  const n = c.info.nFrames;
  const xa = Math.max(0, Math.floor(fToX(0, W))), xb = Math.min(W, Math.ceil(fToX(n, W)));
  tctx.fillStyle = 'rgba(255,255,255,.035)';
  tctx.fillRect(xa, y, xb - xa, h);
  const w = waveOf(c);
  tctx.font = '600 10px Segoe UI, sans-serif'; tctx.textAlign = 'left';
  if (!w) { tctx.fillStyle = '#5c6370'; tctx.fillText(c.info.audio.length ? 'Sound: re-add the clip to see it' : 'No sound in this clip', xa + 6, y + h / 2 + 4); return; }
  const mid = y + h / 2, k = (h / 2 - 1) / 127 / Math.max(0.05, w.peak) * 0.98;
  const cuts = TL.mergeRanges(c.removed);
  const inCut = (f) => cuts.some(([a, b]) => f >= a && f < b + 1);
  tctx.fillStyle = 'rgba(255,255,255,.08)'; tctx.fillRect(xa, mid, xb - xa, 1);
  for (let x = xa; x < xb; x++) {
    const fa = xToF(x, W), fb = xToF(x + 1, W);
    let k0 = Math.floor(timeAtF(c, fa) * w.rate), k1 = Math.ceil(timeAtF(c, fb) * w.rate);
    k0 = clamp(k0, 0, w.min.length); k1 = clamp(Math.max(k0 + 1, k1), 0, w.min.length);
    let lo = 0, hi = 0;
    for (let i = k0; i < k1; i++) { if (w.min[i] < lo) lo = w.min[i]; if (w.max[i] > hi) hi = w.max[i]; }
    if (hi === 0 && lo === 0) continue;
    tctx.fillStyle = inCut((fa + fb) / 2) ? '#5a4148' : (TL.speedAt(c.speeds, Math.floor((fa + fb) / 2)) < 1 ? '#a58cff' : '#5fc4b8');
    tctx.fillRect(x, mid - hi * k, 1, Math.max(1, (hi - lo) * k));
  }
  tctx.fillStyle = 'rgba(231,233,238,.55)'; tctx.fillText('♪', 1, mid + 4);
}
function tlView() { const n = N(); return { a: S.zoom.a * n, b: S.zoom.b * n }; }
function fToX(f, w) { const v = tlView(); return TLY.left + ((f - v.a) / (v.b - v.a)) * (w - TLY.left - TLY.right); }
function xToF(x, w) { const v = tlView(); return v.a + ((x - TLY.left) / (w - TLY.left - TLY.right)) * (v.b - v.a); }

function renderTimeline() {
  const dpr = window.devicePixelRatio || 1;
  const W = tlc.clientWidth, H = tlc.clientHeight;
  if (tlc.width !== Math.round(W * dpr) || tlc.height !== Math.round(H * dpr)) { tlc.width = Math.round(W * dpr); tlc.height = Math.round(H * dpr); }
  tctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  tctx.clearRect(0, 0, W, H);
  layoutLanes(H);
  const c = cur();
  if (!ready(c)) return;
  const n = c.info.nFrames;
  const v = tlView();
  // ruler
  tctx.fillStyle = '#8b93a1'; tctx.font = '10.5px Segoe UI, sans-serif'; tctx.textAlign = 'left';
  const secSpan = frameTime(c, Math.min(n - 1, Math.floor(v.b))) - frameTime(c, Math.floor(v.a)) || 1;
  const pxPerSec = (W - TLY.left - TLY.right) / secSpan;
  const steps = [0.1, 0.2, 0.5, 1, 2, 5, 10, 15, 30, 60, 120, 300];
  const step = steps.find((s) => s * pxPerSec >= 70) || 600;
  const tStart = frameTime(c, Math.floor(v.a));
  for (let t = Math.ceil(tStart / step) * step; ; t += step) {
    const f = indexAtTime(c.info.times, t + c.info.times[0]);
    if (f > v.b || t > c.info.duration) break;
    const x = fToX(f, W);
    tctx.fillRect(x, 12, 1, 6);
    tctx.fillText(fmt(t).replace(/\.\d+$/, step < 1 ? fmt(t).slice(-4) : ''), x + 3, 10);
  }
  // kept / cut bar
  const y0 = TLY.ruler;
  tctx.fillStyle = '#2a9d8f';
  tctx.fillRect(fToX(0, W), y0, fToX(n, W) - fToX(0, W), TLY.kept);
  for (const [a, b] of TL.mergeRanges(c.removed)) {
    const x0 = fToX(a, W), x1 = fToX(b + 1, W);
    tctx.fillStyle = '#5b2330';
    tctx.fillRect(x0, y0, x1 - x0, TLY.kept);
    tctx.save(); tctx.beginPath(); tctx.rect(x0, y0, x1 - x0, TLY.kept); tctx.clip();
    tctx.strokeStyle = 'rgba(239,91,91,.55)'; tctx.lineWidth = 1;
    for (let x = x0 - TLY.kept; x < x1; x += 7) { tctx.beginPath(); tctx.moveTo(x, y0 + TLY.kept); tctx.lineTo(x + TLY.kept, y0); tctx.stroke(); }
    tctx.restore();
  }
  // transitions at the ends of this clip
  const z = transZones(S.cur);
  for (const [zz, atStart] of [[z.into, true], [z.out, false]]) {
    if (!zz) continue;
    const fr = zz.sf.fr, L = fr.length;
    const xa = atStart ? fToX(fr[0], W) : fToX(fr[L - zz.n], W);
    const xb = atStart ? fToX(fr[zz.n - 1] + 1, W) : fToX(fr[L - 1] + 1, W);
    const col = zz.type === 'black' ? '0,0,0' : '77,163,255';
    const g = tctx.createLinearGradient(xa, 0, xb, 0);
    g.addColorStop(atStart ? 0 : 1, `rgba(${col},${zz.type === 'black' ? 0.9 : 0.75})`);
    g.addColorStop(atStart ? 1 : 0, `rgba(${col},0)`);
    tctx.fillStyle = g; tctx.fillRect(xa, y0, Math.max(2, xb - xa), TLY.kept);
    tctx.fillStyle = '#e7e9ee'; tctx.font = '600 10px Segoe UI, sans-serif';
    tctx.fillText(zz.type === 'black' ? '◐' : '⧉', atStart ? xa + 3 : Math.max(xa, xb - 12), y0 + 14);
  }
  // edges of the kept parts can be dragged
  tctx.fillStyle = '#e7e9ee';
  for (const [a, b] of TL.keepRanges(n, c.removed)) {
    for (const x of [fToX(a, W), fToX(b + 1, W)]) tctx.fillRect(x - 1.5, y0 - 2, 3, TLY.kept + 4);
  }
  // slow-motion parts
  const ys = y0 + TLY.kept + 3;
  tctx.fillStyle = 'rgba(255,255,255,.04)';
  tctx.fillRect(fToX(0, W), ys, fToX(n, W) - fToX(0, W), TLY.slow);
  for (const p of c.speeds || []) {
    const x0 = fToX(p.a, W), x1 = fToX(p.b + 1, W);
    tctx.fillStyle = '#7c4dff';
    tctx.fillRect(x0, ys, Math.max(2, x1 - x0), TLY.slow);
    tctx.fillStyle = '#efe9ff';
    tctx.fillRect(x0 - 1, ys - 1, 2, TLY.slow + 2); tctx.fillRect(x1 - 1, ys - 1, 2, TLY.slow + 2);
    if (x1 - x0 > 26) { tctx.font = '600 10px Segoe UI, sans-serif'; tctx.fillText(speedLabel(p.s), x0 + 4, ys + 10); }
  }
  // sound
  const ya = ys + TLY.slow + 4;
  drawWave(c, W, ya, TLY.audio);
  // plates
  const rows = c.tracks;
  const yr = ya + TLY.audio + 4;
  const avail = H - yr - 2;
  const rowH = Math.max(5, Math.min(TLY.row, (avail / Math.max(1, rows.length)) - TLY.gap));
  rows.forEach((t, i) => {
    const y = yr + i * (rowH + TLY.gap);
    const rg = rangeC(t);
    if (t.id === S.sel) { tctx.fillStyle = 'rgba(255,255,255,.06)'; tctx.fillRect(0, y - 1, W, rowH + 2); }
    if (!rg) return;
    tctx.globalAlpha = 0.45; tctx.fillStyle = t.color;
    tctx.fillRect(fToX(rg[0], W), y, Math.max(2, fToX(rg[1] + 1, W) - fToX(rg[0], W)), rowH);
    tctx.globalAlpha = 1;
    for (const [k, key] of Object.entries(t.keys)) {
      const x = fToX(Number(k) + 0.5, W);
      if (x < 0 || x > W) continue;
      if (key.m === 'manual') {
        tctx.fillStyle = '#fff';
        tctx.beginPath(); tctx.moveTo(x, y - 1); tctx.lineTo(x + 4, y + rowH / 2); tctx.lineTo(x, y + rowH + 1); tctx.lineTo(x - 4, y + rowH / 2); tctx.fill();
      } else if (key.c !== undefined && key.c < 0.6) {
        tctx.fillStyle = '#ff9f43'; tctx.fillRect(x - 1, y, 2, rowH);
      }
    }
  });
  // marks
  for (const [m, lab] of [[S.markA, 'A'], [S.markB, 'B']]) {
    if (m === null) continue;
    const x = fToX(m + 0.5, W);
    tctx.fillStyle = '#ff6b6b'; tctx.fillRect(x - 0.5, y0 - 4, 1, H - y0 + 4);
    tctx.font = '600 11px Segoe UI, sans-serif'; tctx.fillText(lab, x + 3, y0 + TLY.kept - 5);
  }
  if (S.markA !== null && S.markB !== null) {
    const a = Math.min(S.markA, S.markB), b = Math.max(S.markA, S.markB);
    tctx.fillStyle = 'rgba(255,107,107,.18)'; tctx.fillRect(fToX(a, W), y0, fToX(b + 1, W) - fToX(a, W), H - y0);
  }
  // playhead
  const px = fToX(S.frame + 0.5, W);
  tctx.fillStyle = '#f2b33d'; tctx.fillRect(px - 1, 0, 2, H);
  tctx.beginPath(); tctx.moveTo(px - 6, 0); tctx.lineTo(px + 6, 0); tctx.lineTo(px, 8); tctx.fill();
}

// Which draggable edge (kept-part or slow-part) is under the mouse, if any
function tlEdgeHit(e) {
  const c = cur(); if (!ready(c)) return null;
  const bb = tlc.getBoundingClientRect();
  const mx = e.clientX - bb.left, my = e.clientY - bb.top, W = bb.width;
  const n = c.info.nFrames;
  const y0 = TLY.ruler, ys = y0 + TLY.kept + 3;
  let best = null;
  const cand = (kind, i, x) => { const d = Math.abs(mx - x); if (d <= 6 && (!best || d < best.d)) best = { kind, i, d }; };
  if (my >= y0 - 3 && my <= y0 + TLY.kept + 1) {
    TL.keepRanges(n, c.removed).forEach(([a, b], i) => { cand('keptL', i, fToX(a, W)); cand('keptR', i, fToX(b + 1, W)); });
  } else if (my >= ys - 2 && my <= ys + TLY.slow + 2) {
    (c.speeds || []).forEach((p, i) => { cand('slowL', i, fToX(p.a, W)); cand('slowR', i, fToX(p.b + 1, W)); });
  }
  return best;
}

let scrubbing = false;
let tlDrag = null;
tlc.addEventListener('mousedown', (e) => {
  if (!ready()) return;
  const c = cur();
  const hit = tlEdgeHit(e);
  if (hit) {
    if (!vid.paused) vid.pause();
    pushUndo('dragging an edge');
    tlDrag = { ...hit, removed0: TL.mergeRanges(c.removed), speeds0: TL.normSpeeds(c.speeds), keep0: TL.keepRanges(c.info.nFrames, c.removed) };
    return;
  }
  const bb = tlc.getBoundingClientRect();
  const f0 = clamp(Math.floor(xToF(e.clientX - bb.left, bb.width)), 0, N() - 1);
  if (e.shiftKey) { rangeSel = true; S.markA = f0; S.markB = f0; seekFrame(f0); return; }
  scrubbing = true;
  seekFrame(f0);
});
let rangeSel = false;
function dragEdge(e) {
  const c = cur(); const d = tlDrag; const n = c.info.nFrames;
  const bb = tlc.getBoundingClientRect();
  const f = Math.round(xToF(e.clientX - bb.left, bb.width)); // frame boundary under the mouse
  if (d.kind === 'keptL' || d.kind === 'keptR') {
    const [a, b] = d.keep0[d.i];
    if (d.kind === 'keptL') {
      const lb = d.i > 0 ? d.keep0[d.i - 1][1] + 1 : 0;
      const na = clamp(f, lb, b);
      c.removed = na > a ? TL.mergeRanges([...d.removed0, [a, na - 1]]) : na < a ? TL.subtractRange(d.removed0, na, a - 1) : d.removed0;
      seekFrame(na);
      setStatus(`Part now starts at frame ${na} (${fmt(frameTime(c, na))})`);
    } else {
      const ub = d.i < d.keep0.length - 1 ? d.keep0[d.i + 1][0] - 1 : n - 1;
      const nb = clamp(f - 1, a, ub);
      c.removed = nb < b ? TL.mergeRanges([...d.removed0, [nb + 1, b]]) : nb > b ? TL.subtractRange(d.removed0, b + 1, nb) : d.removed0;
      seekFrame(nb);
      setStatus(`Part now ends at frame ${nb} (${fmt(frameTime(c, nb))})`);
    }
  } else {
    const sp = d.speeds0.map((p) => ({ ...p }));
    const p = sp[d.i];
    if (d.kind === 'slowL') { p.a = clamp(f, d.i > 0 ? sp[d.i - 1].b + 1 : 0, p.b); seekFrame(p.a); }
    else { p.b = clamp(f - 1, p.a, d.i < sp.length - 1 ? sp[d.i + 1].a - 1 : n - 1); seekFrame(p.b); }
    c.speeds = sp;
    setStatus(`Slow part: frames ${p.a}–${p.b} at ${speedLabel(p.s)} speed`);
  }
  S.stamp++;
  requestRender();
}
window.addEventListener('mousemove', (e) => {
  if (tlDrag) { dragEdge(e); return; }
  if (rangeSel) {
    const bb = tlc.getBoundingClientRect();
    S.markB = clamp(Math.floor(xToF(e.clientX - bb.left, bb.width)), 0, N() - 1);
    seekFrame(S.markB);
    return;
  }
  if (!scrubbing) {
    if (e.target === tlc) tlc.style.cursor = tlEdgeHit(e) ? 'ew-resize' : 'pointer';
    return;
  }
  const bb = tlc.getBoundingClientRect();
  seekFrame(Math.floor(xToF(e.clientX - bb.left, bb.width)));
});
window.addEventListener('mouseup', () => {
  scrubbing = false;
  if (rangeSel) {
    rangeSel = false;
    const a = Math.min(S.markA, S.markB), b = Math.max(S.markA, S.markB);
    setStatus(`Frames ${a}–${b} marked. Press X or Delete to cut them out, W to slow them down.`);
    requestRender();
  }
  if (tlDrag) { tlDrag = null; changed(); }
});
tlc.addEventListener('wheel', (e) => {
  if (!ready()) return;
  e.preventDefault();
  const bb = tlc.getBoundingClientRect();
  const n = N();
  const span = S.zoom.b - S.zoom.a;
  if (e.shiftKey || Math.abs(e.deltaX) > Math.abs(e.deltaY)) {
    const d = (e.shiftKey ? e.deltaY : e.deltaX) / bb.width * span;
    const a = clamp(S.zoom.a + d, 0, 1 - span);
    S.zoom = { a, b: a + span };
  } else {
    const fx = xToF(e.clientX - bb.left, bb.width) / n;
    const ns = clamp(span * (e.deltaY > 0 ? 1.25 : 0.8), Math.min(1, 40 / n), 1);
    let a = fx - (fx - S.zoom.a) * (ns / span);
    a = clamp(a, 0, 1 - ns);
    S.zoom = { a, b: a + ns };
  }
  requestRender();
}, { passive: false });

// ---------------------------------------------------------------- info line
function renderInfo() {
  const c = cur();
  $('btnTurnLeft').disabled = $('btnTurnRight').disabled = !ready(c) || !!S.tracking;
  if (!ready(c)) { $('tcTime').textContent = fmt(0); $('tcDur').textContent = fmt(0); $('tcFrame').textContent = ''; $('cutInfo').textContent = ''; return; }
  $('tcTime').textContent = fmt(frameTime(c, S.frame));
  $('tcDur').textContent = fmt(c.info.duration);
  $('tcFrame').textContent = `frame ${S.frame} / ${c.info.nFrames - 1}`;
  const inCut = TL.mergeRanges(c.removed).some(([a, b]) => S.frame >= a && S.frame <= b);
  $('btnRestore').disabled = !inCut;
  $('cutInfo').textContent = `Keeping ${fmt(cutSeconds(c))} of ${fmt(c.info.duration)}` +
    ((c.speeds || []).length ? ` · plays ${fmt(keptSeconds(c))} with slow motion` : '') +
    (S.markA !== null || S.markB !== null ? ` · A ${S.markA ?? '–'} · B ${S.markB ?? '–'}` : '');
  for (const id of ['btnTrimStart', 'btnTrimEnd', 'btnMarkA', 'btnMarkB', 'btnCutAB']) $(id).disabled = false;
  const p = curSlow();
  $('btnSpeedNormal').disabled = !p;
  if (p && document.activeElement !== $('selSpeed')) $('selSpeed').value = String(p.s);
  else if (!p && document.activeElement !== $('selSpeed')) $('selSpeed').value = String(S.settings.SLOW_SPEED || 0.125);
  if (!findingFlashes) {
    if (p) {
      const src = frameTime(c, p.b) - frameTime(c, p.a) + TL.frameDur(c.info.times, lastDur(c), p.b);
      $('slowInfo').textContent = `This part (frames ${p.a}–${p.b}) plays at ${speedLabel(p.s)} speed: ${src.toFixed(2)} s becomes ${(src / p.s).toFixed(2)} s.`;
    } else if (slowNote) {
      $('slowInfo').textContent = slowNote.m;
    } else if ((c.speeds || []).length) {
      $('slowInfo').textContent = `${c.speeds.length} slow part${c.speeds.length > 1 ? 's' : ''} (purple). This clip plays ${fmt(keptSeconds(c))} instead of ${fmt(cutSeconds(c))}.`;
    } else {
      $('slowInfo').textContent = 'Mark A and B, then Slow down A–B. Or let ⚡ Find lightning do it.';
    }
  }
  if (slowNote && Math.abs(S.frame - slowNote.f) > 0 && !p) slowNote = null;
}

// ---------------------------------------------------------------- export
function exportSettingsFromForm() {
  return {
    encoder: $('optEncoder').value,
    container: $('optContainer').value,
    outHeight: Number($('optHeight').value),
    bitrateMode: $('optBitrateMode').value,
    bitrateKbps: Math.round(Number($('optBitrate').value || 40) * 1000),
    blurStyle: $('optBlurStyle').value,
    blurStrength: Number($('optBlurStrength').value),
    padPct: Number($('optPad').value),
    slowAudio: $('optSlowAudio').value,
    fpsMode: $('optFps').value,
  };
}

const ev2 = (n) => Math.max(2, Math.round(n / 2) * 2);
function outDimsFor(c, h) {
  const v = viewSize(c);
  const short = Math.min(v.w, v.h);
  if (h > 0 && short > h) { const s = h / short; return { w: ev2(v.w * s), h: ev2(v.h * s) }; }
  return { w: v.w, h: v.h };
}
// Same rule as the export: the biggest clip sets the size, the others are scaled
// to fit it (black bars when their shape differs).
function outputPlan(used, h) {
  const all = used.map((c) => ({ c, d: outDimsFor(c, h), v: viewSize(c) }));
  const big = all.reduce((m, x) => (x.d.w * x.d.h > m.d.w * m.d.h ? x : m), all[0]);
  const D = big.d;
  return { D, clips: all.map((x) => {
    const k = Math.min(D.w / x.v.w, D.h / x.v.h);
    const fit = { w: Math.min(D.w, ev2(x.v.w * k)), h: Math.min(D.h, ev2(x.v.h * k)) };
    return { c: x.c, v: x.v, fit, up: fit.w > x.v.w, down: fit.w < x.v.w, bars: fit.w !== D.w || fit.h !== D.h };
  }) };
}

function renderExportSummary() {
  const s = exportSettingsFromForm();
  const rd = S.clips.filter((c) => ready(c));
  const used = rd.filter((c) => TL.keepRanges(c.info.nFrames, c.removed).length);
  const lines = [];
  const tot = used.reduce((x, c) => x + keptSeconds(c), 0) - crossOverlapSeconds();
  let plates = 0;
  for (const c of used) {
    const keep = TL.keepRanges(c.info.nFrames, c.removed);
    plates += c.tracks.filter((t) => { const r = rangeC(t); return r && keep.some(([a, b]) => r[0] <= b && r[1] >= a); }).length;
  }
  lines.push(`<b>${used.length}</b> clip${used.length !== 1 ? 's' : ''} → <b>${fmt(tot)}</b> · <b>${plates}</b> plate${plates !== 1 ? 's' : ''} blurred`);
  const slowParts = used.reduce((x, c) => x + (c.speeds || []).filter((p) => TL.keepRanges(c.info.nFrames, c.removed).some(([a, b]) => p.a <= b && p.b >= a)).length, 0);
  const tr = used.slice(1).map((c) => (c.transIn && c.transIn.type !== 'none' ? c.transIn.type : null)).filter(Boolean);
  if (tr.length) {
    const nb = tr.filter((t) => t === 'black').length, nc = tr.filter((t) => t === 'cross').length;
    lines.push(`Transitions: ${[nc ? `${nc} crossfade${nc > 1 ? 's' : ''}` : '', nb ? `${nb} fade${nb > 1 ? 's' : ''} through black` : ''].filter(Boolean).join(', ')} (no frames are cut)`);
  }
  const turned = used.filter((c) => rotOf(c));
  if (turned.length) lines.push(`⟳ Turned: ${turned.map((c) => `${escapeHtml(c.name)} (${ROT_LABEL[rotOf(c)]})`).join(', ')}`);
  if (slowParts) lines.push(`🐢 <b>${slowParts}</b> slow-motion part${slowParts > 1 ? 's' : ''} (every real frame kept, shown longer)`);
  if (used.length) {
    const op = outputPlan(used, s.outHeight);
    lines.push(`Output ${op.D.w}x${op.D.h}`);
    for (const x of op.clips) {
      if (!x.up && !x.down && !x.bars) continue;
      const what = [x.up ? `scaled up from ${x.v.w}x${x.v.h}` : x.down ? `scaled down from ${x.v.w}x${x.v.h}` : '', x.bars ? `black bars (${x.v.w > x.v.h ? 'landscape' : 'portrait'} clip)` : ''].filter(Boolean).join(', ');
      if (x.up || x.bars) lines.push(`<span class="warn">${escapeHtml(x.c.name)}: ${what}${x.bars && Math.abs(x.v.w / x.v.h - op.D.w / op.D.h) > 0.5 ? ' — if it was filmed sideways, turn it with ↺ / ↻' : ''}</span>`);
    }
  }
  // frame rates (each part keeps its own, or the whole video at the lowest)
  if (used.length) {
    const rates = used.map((c) => TL.clipRate(c.info.nominalFps || c.info.avgFps, c.info.avgFps));
    const low = rates.reduce((m, r) => (r[0] / r[1] < m[0] / m[1] ? r : m));
    const labels = [...new Set(rates.map(TL.rateLabel))];
    $('optFps').options[1].textContent = `Same for the whole video: ${TL.rateLabel(low)} fps (the lowest)`;
    if (s.fpsMode === 'lowest') {
      const faster = used.filter((c, i) => rates[i][0] / rates[i][1] > low[0] / low[1] + 0.01);
      lines.push(`Frame rate: <b>${TL.rateLabel(low)} fps</b> for the whole video${faster.length ? ` (${faster.map((c) => escapeHtml(c.name)).join(', ')} shown at ${TL.rateLabel(low)} fps: frames in between are left out)` : ''}`);
    } else if (labels.length > 1) {
      lines.push(`Frame rates: ${labels.join(' and ')} fps — each part keeps its own, so nothing plays too fast or too slow`);
    }
  }
  const kinds = new Set(used.map((c) => (c.info.isPQ ? 'pq' : c.info.isHLG ? 'hlg' : 'sdr') + c.info.bitDepth));
  if (kinds.size > 1) lines.push('<span class="bad">HDR and SDR clips can\'t be joined in one file.</span>');
  const noPlus = used.filter((c) => !c.info.hasHdr10Plus);
  if (used.length && !noPlus.length) lines.push('HDR10+ metadata: <b>kept on every frame</b> (checked after export)');
  else if (noPlus.length && noPlus.length < used.length) lines.push(`<span class="warn">${noPlus.map((c) => c.name).join(', ')} ${noPlus.length > 1 ? 'have' : 'has'} no HDR10+, so those parts will be plain HDR10.</span>`);
  else if (used.length) lines.push(`<span class="warn">These clips have no HDR10+ metadata${used[0].info.isPQ ? ' (exported as HDR10)' : ''}.</span>`);
  const loading = S.clips.filter((c) => c.status === 'loading').length;
  if (loading) lines.push(`<span class="warn">${loading} clip${loading > 1 ? 's are' : ' is'} still loading and won't be included.</span>`);
  if (s.encoder === 'nvencc' && S.tools && !S.tools.nvencc.ok) lines.push('<span class="bad">NVEncC was not found — set its path in Settings, or pick the CPU encoder.</span>');
  $('exportSummary').innerHTML = lines.join('<br>');
  $('btnDoExport').disabled = !used.length || kinds.size > 1;
  $('optBitrate').disabled = s.bitrateMode !== 'fixed';
  $('optBlurStrengthV').textContent = s.blurStrength;
  $('optPadV').textContent = `${s.padPct}%`;
}

function openExport() {
  const v = S.settings;
  $('optEncoder').value = v.ENCODER || 'nvencc';
  $('optContainer').value = v.OUTPUT_CONTAINER || 'mp4';
  $('optHeight').value = String(v.OUTPUT_HEIGHT || '0');
  $('optBitrateMode').value = v.BITRATE_MODE || 'source';
  $('optBitrate').value = Math.round(Number(v.BITRATE_KBPS || 40000) / 1000);
  $('optBlurStyle').value = v.BLUR_STYLE || 'blur';
  $('optBlurStrength').value = v.BLUR_STRENGTH || 24;
  $('optPad').value = v.BOX_PADDING || 12;
  $('optSlowAudio').value = v.SLOW_AUDIO || 'stretch';
  $('optFps').value = v.FPS_MODE === 'lowest' ? 'lowest' : 'keep';
  $('exportForm').classList.remove('hidden');
  $('exportRun').classList.add('hidden');
  renderExportSummary();
  $('exportModal').classList.remove('hidden');
}
for (const id of ['optEncoder', 'optContainer', 'optHeight', 'optBitrateMode', 'optBitrate', 'optBlurStyle', 'optBlurStrength', 'optPad', 'optSlowAudio', 'optFps']) {
  $(id).addEventListener('input', () => {
    renderExportSummary();
    const s = exportSettingsFromForm();
    // live preview of blur settings in the editor
    S.settings.BLUR_STRENGTH = String(s.blurStrength); S.settings.BOX_PADDING = String(s.padPct); S.settings.BLUR_STYLE = s.blurStyle;
    requestRender();
  });
}

let exportStart = 0;
let lastOut = null;
async function doExport() {
  const s = exportSettingsFromForm();
  const used = S.clips.filter((c) => ready(c));
  const base = (used[0].name.replace(/\.[^.]+$/, '') + (used.length > 1 ? '_joined' : '') + '_edited');
  const outPath = await api.saveExportDialog(base, s.container);
  if (!outPath) return;
  if (used.some((c) => c.file === outPath)) { alert('Please choose a different file name: that is one of your source clips.'); return; }
  $('exportForm').classList.add('hidden');
  $('exportRun').classList.remove('hidden');
  $('runResult').classList.add('hidden');
  $('btnCancelExport').classList.remove('hidden');
  $('btnShowFile').classList.add('hidden');
  $('btnCloseRun').classList.add('hidden');
  $('runBar').style.width = '0%';
  $('runStage').textContent = 'Starting…';
  exportStart = Date.now();
  lastOut = outPath;
  const project = { clips: used.map((c) => ({ file: c.file, removed: c.removed, tracks: c.tracks, speeds: c.speeds || [], transIn: c.transIn || null, rot: rotOf(c) })) };
  try {
    const res = await api.runExport(project, s, outPath);
    const v = res.verify;
    const lines = [];
    lines.push(`<span class="okc">✓</span> Saved <b>${outPath.split(/[\\/]/).pop()}</b> — ${fmt(res.seconds)}, ${res.frames} frames`);
    lines.push(`<span class="okc">✓</span> Frame count matches the edit (${v.frames.got})`);
    if (v.hdr10plus) lines.push(`<span class="${v.hdr10plus.ok ? 'okc' : 'badc'}">${v.hdr10plus.ok ? '✓' : '✗'}</span> HDR10+ metadata present and in the right place on ${v.hdr10plus.frames} frames`);
    lines.push(res.fps
      ? `<span class="okc">✓</span> ${res.fps} fps throughout${project.clips.some((c) => c.speeds.length) ? ' (slow-motion parts stretched)' : ''}, audio cut to match`
      : `<span class="okc">✓</span> Original phone timing kept${project.clips.some((c) => c.speeds.length) ? ' (slow-motion parts stretched)' : ''}, audio cut to match`);
    lines.push(`<span class="muted small">Took ${fmt((Date.now() - exportStart) / 1000)}</span>`);
    $('runResult').innerHTML = lines.join('<br>');
    $('runStage').textContent = 'Finished';
    $('runBar').style.width = '100%';
    $('btnShowFile').classList.remove('hidden');
    setStatus(`Exported ${outPath}`);
  } catch (e) {
    const m = errMsg(e);
    $('runStage').textContent = /Cancelled/i.test(m) ? 'Export cancelled' : 'Export failed';
    $('runResult').innerHTML = `<span class="badc">✗</span> <span id="errText"></span><br><span class="muted small">Full details are in the log (Log ▴ at the bottom right).</span>`;
    $('errText').textContent = m;
    setStatus('Export failed');
  } finally {
    $('runResult').classList.remove('hidden');
    $('btnCancelExport').classList.add('hidden');
    $('btnCloseRun').classList.remove('hidden');
  }
}
api.onExportProgress((p) => {
  $('runStage').textContent = p.stage;
  $('runBar').style.width = `${(p.overall * 100).toFixed(1)}%`;
  const el = (Date.now() - exportStart) / 1000;
  const eta = p.overall > 0.03 ? el / p.overall - el : null;
  $('runMeta').textContent = `${(p.overall * 100).toFixed(0)}% · ${fmt(el).replace(/\.\d+$/, '')} elapsed${eta !== null ? ` · about ${fmt(eta).replace(/\.\d+$/, '')} left` : ''}`;
});

// ---------------------------------------------------------------- settings
const SETTINGS_FIELDS = [
  ['FFMPEG_PATH', 'ffmpeg', 'file'], ['FFPROBE_PATH', 'ffprobe (empty = next to ffmpeg)', 'file'],
  ['NVENCC_PATH', 'NVEncC64.exe', 'file'], ['HDR10PLUS_TOOL_PATH', 'hdr10plus_tool', 'file'],
  ['MKVMERGE_PATH', 'mkvmerge', 'file'],
  ['HWACCEL', 'GPU decoding', 'select', ['cuda', 'd3d11va', 'auto', 'none']],
  ['NVENCC_PRESET', 'NVENC preset', 'select', ['quality', 'default', 'performance', 'P7', 'P6', 'P5', 'P4']],
  ['AUDIO_BITRATE_KBPS', 'Audio kbps (0 = same as source)', 'number'],
  ['PROXY_WIDTH', 'Preview size (px)', 'number'],
  ['WORK_DIR', 'Temp/preview folder (empty = system temp)', 'folder'],
];
function buildSettingsForm() {
  const f = $('settingsForm');
  f.innerHTML = '';
  for (const [key, label, kind, opts] of SETTINGS_FIELDS) {
    const l = document.createElement('label'); l.textContent = label; f.appendChild(l);
    let input;
    if (kind === 'select') {
      input = document.createElement('select');
      for (const o of opts) { const op = document.createElement('option'); op.value = o; op.textContent = o; input.appendChild(op); }
      f.appendChild(input);
    } else {
      const row = document.createElement('div'); row.className = 'path-row';
      input = document.createElement('input'); input.type = kind === 'number' ? 'number' : 'text';
      row.appendChild(input);
      if (kind === 'file' || kind === 'folder') {
        const b = document.createElement('button'); b.className = 'btn'; b.textContent = 'Browse…';
        b.addEventListener('click', async () => {
          const p = kind === 'file' ? await api.pickFile(label, input.value) : await api.pickFolder(label, input.value);
          if (p) input.value = p;
        });
        row.appendChild(b);
      }
      f.appendChild(row);
    }
    input.id = `set_${key}`;
    input.value = S.settings[key] ?? '';
  }
}
function renderToolStatus(t) {
  if (!t) { $('toolStatus').innerHTML = ''; return; }
  const name = { ffmpeg: 'ffmpeg', ffprobe: 'ffprobe', nvencc: 'NVEncC', hdr10plus: 'hdr10plus_tool', mkvmerge: 'mkvmerge' };
  $('toolStatus').innerHTML = Object.entries(t).map(([k, v]) =>
    `<div><span class="${v.ok ? 'okc' : 'badc'}">${v.ok ? '✓' : '✗'}</span> <b>${name[k]}</b> <span class="muted">${escapeHtml(v.version || '')}${v.gpu ? ' · ' + escapeHtml(v.gpu.slice(0, 120)) : ''}</span></div>`).join('');
}
function escapeHtml(s) { return String(s).replace(/[&<>"]/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[ch])); }
async function checkTools() {
  $('toolStatus').innerHTML = '<span class="muted">Checking…</span>';
  S.tools = await api.checkTools();
  renderToolStatus(S.tools);
  const need = ['ffmpeg', 'ffprobe', 'hdr10plus', 'mkvmerge'];
  if ((S.settings.ENCODER || 'nvencc') === 'nvencc') need.push('nvencc');
  $('toolWarn').classList.toggle('hidden', need.every((k) => S.tools[k].ok));
  if (S.tools.hdr10plus.ok) retryUnreadHdr10Plus();
}
async function openSettings() {
  const r = await api.getSettings();
  S.settings = r.values;
  buildSettingsForm();
  $('envPath').textContent = `Saved in ${r.envPath}`;
  renderToolStatus(S.tools);
  $('settingsModal').classList.remove('hidden');
}
async function saveSettings() {
  const vals = {};
  for (const [key] of SETTINGS_FIELDS) vals[key] = $(`set_${key}`).value.trim();
  const r = await api.saveSettings(vals);
  S.settings = r.values;
  setStatus('Settings saved');
  await checkTools();
}

// ---------------------------------------------------------------- log
const logBody = $('logBody');
api.onLog((l) => {
  const d = document.createElement('div');
  d.className = l.level;
  d.textContent = l.line;
  logBody.appendChild(d);
  while (logBody.childNodes.length > 1500) logBody.removeChild(logBody.firstChild);
  if (!$('logDrawer').classList.contains('hidden')) logBody.scrollTop = logBody.scrollHeight;
});

// ---------------------------------------------------------------- wiring
$('btnAdd').addEventListener('click', async () => addFiles(await api.openClips()));
$('btnUndo').addEventListener('click', undo);
$('btnRedo').addEventListener('click', redo);
$('btnSettings').addEventListener('click', openSettings);
$('toolWarnLink').addEventListener('click', (e) => { e.preventDefault(); openSettings(); });
$('btnSaveSettings').addEventListener('click', saveSettings);
$('btnCheckTools').addEventListener('click', checkTools);
$('btnExport').addEventListener('click', openExport);
$('btnDoExport').addEventListener('click', doExport);
$('btnCancelExport').addEventListener('click', () => { api.cancelExport(); $('runStage').textContent = 'Cancelling…'; });
$('btnShowFile').addEventListener('click', () => lastOut && api.showItem(lastOut));
document.querySelectorAll('[data-close]').forEach((b) => b.addEventListener('click', () => {
  if (!$('exportRun').classList.contains('hidden') && !$('btnCancelExport').classList.contains('hidden')) return; // export running
  b.closest('.modal').classList.add('hidden');
}));
$('btnStart').addEventListener('click', () => seekFrame(0));
$('btnPrev').addEventListener('click', () => seekFrame(S.frame - 1));
$('btnNext').addEventListener('click', () => seekFrame(S.frame + 1));
$('btnPlay').addEventListener('click', togglePlay);
$('btnTurnLeft').addEventListener('click', () => turnClip(-1));
$('btnTurnRight').addEventListener('click', () => turnClip(1));
$('chkBlurPrev').addEventListener('change', (e) => { S.blurPrev = e.target.checked; requestRender(); });
$('btnTrackFwd').addEventListener('click', () => trackSelected(1));
$('btnTrackBack').addEventListener('click', () => trackSelected(-1));
$('btnTrackStop').addEventListener('click', () => api.stopTrack());
$('btnEndHere').addEventListener('click', endHere);
$('btnStartHere').addEventListener('click', startHere);
$('btnDelPlate').addEventListener('click', deletePlate);
$('btnTrimStart').addEventListener('click', trimStart);
$('btnTrimEnd').addEventListener('click', trimEnd);
$('btnMarkA').addEventListener('click', markA);
$('btnMarkB').addEventListener('click', markB);
$('btnCutAB').addEventListener('click', cutAB);
$('btnRestore').addEventListener('click', restorePart);
$('btnFindFlash').addEventListener('click', findLightning);
$('btnSlowAB').addEventListener('click', slowAB);
$('btnSpeedNormal').addEventListener('click', speedNormalHere);
$('selSpeed').addEventListener('change', speedSelected);
$('btnLog').addEventListener('click', () => { $('logDrawer').classList.toggle('hidden'); logBody.scrollTop = logBody.scrollHeight; });
$('btnLogClose').addEventListener('click', () => $('logDrawer').classList.add('hidden'));
$('btnOpenLogs').addEventListener('click', () => api.openLogs());
window.addEventListener('resize', requestRender);

window.addEventListener('keydown', (e) => {
  if (e.target.matches('input, select, textarea')) return;
  if (!$('exportModal').classList.contains('hidden') || !$('settingsModal').classList.contains('hidden')) {
    if (e.key === 'Escape') document.querySelectorAll('.modal:not(.hidden) [data-close]')[0]?.click();
    return;
  }
  const k = e.key;
  if ((e.ctrlKey || e.metaKey) && (k.toLowerCase() === 'y' || (e.shiftKey && k.toLowerCase() === 'z'))) { e.preventDefault(); redo(); return; }
  if ((e.ctrlKey || e.metaKey) && k.toLowerCase() === 'z') { e.preventDefault(); undo(); return; }
  if (e.ctrlKey || e.metaKey || e.altKey) return;
  const step = e.shiftKey ? 10 : 1;
  switch (k) {
    case ' ': e.preventDefault(); togglePlay(); break;
    case 'ArrowLeft': e.preventDefault(); seekFrame(S.frame - step); break;
    case 'ArrowRight': e.preventDefault(); seekFrame(S.frame + step); break;
    case 'Home': seekFrame(0); break;
    case 'End': seekFrame(N() - 1); break;
    case '[': trimStart(); break;
    case ']': trimEnd(); break;
    case 'a': case 'A': markA(); break;
    case 'b': case 'B': markB(); break;
    case 'x': case 'X': cutAB(); break;
    case 'w': case 'W': slowAB(); break;
    case 't': trackSelected(1); break;
    case 'T': trackSelected(-1); break;
    case 'e': case 'E': endHere(); break;
    case 's': case 'S': startHere(); break;
    case 'p': case 'P': $('chkBlurPrev').click(); break;
    case 'r': turnClip(1); break;
    case 'm': case 'M': toggleMute(); break;
    case 'R': turnClip(-1); break;
    case 'Delete': if (S.markA !== null && S.markB !== null) cutAB(); else deletePlate(); break;
    case 'Escape': if (S.tracking) api.stopTrack(); else { S.sel = null; renderPlates(); requestRender(); } break;
    default: return;
  }
});

// drag & drop files
['dragenter', 'dragover'].forEach((ev) => window.addEventListener(ev, (e) => { e.preventDefault(); $('empty').classList.add('drag'); }));
['dragleave', 'drop'].forEach((ev) => window.addEventListener(ev, (e) => { e.preventDefault(); $('empty').classList.remove('drag'); }));
window.addEventListener('drop', (e) => {
  const files = [...(e.dataTransfer.files || [])].map((f) => api.pathForFile(f)).filter(Boolean);
  if (files.length) addFiles(files);
});

// ---------------------------------------------------------------- start
(async () => {
  const r = await api.getSettings();
  S.settings = r.values;
  renderClips(); renderPlates(); requestRender();
  checkTools();
  const sess = await api.loadSession();
  if (sess && sess.clips && sess.clips.length) {
    const restore = Object.fromEntries(sess.clips.map((c) => [c.file, c]));
    await addFiles(sess.clips.map((c) => c.file), restore);
    if (sess.cur >= 0 && sess.cur < S.clips.length) selectClip(sess.cur);
    setStatus('Previous session restored');
  }
  if (sess && sess.sound) { S.sound = { volume: clamp(Number(sess.sound.volume ?? 1), 0, 1), muted: !!sess.sound.muted }; applySound(); }
  if (sess && sess.tlHeight) setTimelineHeight(sess.tlHeight);
})();
