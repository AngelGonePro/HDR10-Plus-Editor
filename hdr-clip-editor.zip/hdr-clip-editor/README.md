# HDR10+ Clip Editor

A small Windows desktop app for phone HDR10+ videos (made for the Galaxy S24 Ultra). It lets you:

- trim the start and end, and cut out parts in the middle
- join several clips into one video, even of different sizes (a 1080p clip between 4K clips is scaled up), with an optional **fade through black** or **crossfade** between them
- turn a clip that was filmed sideways back to landscape (or portrait)
- hear the sound while you play, and see it as a waveform track on the timeline
- undo and redo every edit (**↶ Undo** / **↷ Redo** at the top, or `Ctrl+Z` / `Ctrl+Y`)
- blur or pixelate licence plates. You draw a box once and the app follows the plate.
- slow down parts of a clip, for example lightning, so every real frame stays on screen longer. **⚡ Find lightning** does this automatically.
- export with the NVIDIA GPU (NVEncC / NVENC). The phone's **HDR10+ metadata is kept on every frame**, and the app checks it after every export.

The video is only re-encoded once, on export. Everything outside the plate boxes stays as it was, apart from that single encode.

## What you need (one time)

| Tool | Why | Where |
|---|---|---|
| Node.js 20+ | runs the app | nodejs.org |
| ffmpeg 8 (full build) | decoding, blur, audio | already in `C:\Users\Angel\Documents\ffmpeg-8.0.1-full_build\bin` |
| NVEncC64.exe | GPU HEVC encoder | already in `C:\Users\Angel\Documents\Aviutl_NVEnc_9.29\exe_files\NVEncC\x64` |
| hdr10plus_tool.exe | reads and writes HDR10+ | github.com/quietvoid/hdr10plus_tool → Releases |
| mkvmerge.exe (MKVToolNix) | keeps the phone's exact frame timing | mkvtoolnix.download (default install path is pre-filled) |

## Install and run

```
cd hdr-clip-editor
npm install
npm start
```

On first start, open **⚙ Settings** and press **Check tools**. Every line should show ✓. Use **Browse…** to point at `hdr10plus_tool.exe` (its location is the only path not filled in yet). All paths and options are saved in `.env` next to `package.json` (made from `.env.example` on the first start; updates never overwrite it). You can also edit that file by hand.

## How to use it

1. **Add clips.** Drag the videos into the window or click **＋ Add clips**. The app makes a small preview of each clip (with its sound) and reads its HDR10+ data. Clips opened with an older version get their sound added the first time (a few seconds). A clip with HDR10+ gets a gold **HDR10+** badge. The clip list order is the join order (▲▼ to reorder).
2. **Filmed sideways?** Press **↻** (turn right, `R`) or **↺** (turn left, `Shift+R`) under the video until the picture is the right way up. Press twice for upside down. The preview turns at once, and the export turns the video for real (a 1080×1920 clip becomes 1920×1080). Plate boxes, tracking and cuts are not affected, so you can turn before or after boxing plates. The clip gets a blue **⟳ turned** badge.
3. **Cut.** Move to a frame and press **⇤ Trim start here** / **Trim end here ⇥**. To remove a middle part, hold `Shift` and drag across it on the timeline, then press `Delete`. (Or use **Mark A**, **Mark B**, then **✂ Cut A–B**.) Cut parts show in red on the timeline, and playback skips them. **Restore part** brings back the cut under the playhead, and **↶ Undo** takes back any edit you didn't mean.
4. **Plates.** Pause on a frame where the plate is visible and drag a box around it. Press **Track ▶** (or `T`) and the box follows the plate. If it loses the plate, it stops and tells you where. Move the box back onto the plate on that frame and press Track again. If the plate is gone (behind something, out of the picture), use **End here**. **◀ Track** goes backwards. Orange marks on the timeline are frames the tracker was unsure about. Step through those (`←` `→`) and fix the box if needed. Fixing a box on any frame makes it a fixed point (◆) that later tracking won't overwrite.
5. **Slow motion (optional).**
   - Press **⚡ Find lightning**. The app finds every sudden flash and slows each one down, from a moment before the flash to a moment after. You can change how much before and after in `.env`.
   - To slow down anything else, set **Mark A** and **Mark B**, then press **🐢 Slow down A–B** (`W`).
   - Slow parts show in purple under the timeline. Drag their edges to make them longer or shorter. With the playhead in a purple part, the speed menu (½, ¼, ⅛, 1/16) changes that part. **Normal speed here** removes it.
   - The preview plays these parts at their slowed speed.
   - Nothing is invented: each real frame is just shown longer. At ⅛ speed, a 30 fps clip shows each frame for about a quarter of a second, so you can follow a bolt frame by frame. HDR10+ stays on every frame.
   - Sound in slow parts (Export window): **Slowed down, same pitch**, **Slowed down, deeper** (exact sync, like slowing a tape) or **Silent**.
6. **Trim by dragging.** The start and end of every green part on the timeline have handles. Drag them to trim, or to change the size of a cut. The video shows the frame at the edge while you drag.
7. **Transitions (optional).** Between two clips in the clip list there is a small transition menu. Choose:
   - **Fade through black**: the first clip fades out to black, then the next one fades in. The total length stays the same.
   - **Crossfade**: the end of the first clip dissolves into the start of the next one. The two overlap for the fade time, so the video gets that much shorter, but **no frames are cut from either clip**.
   - Pick the length (0.5–3 s). The preview shows the fade when the playhead is in it, and the timeline shows it as a shaded wedge.
   - HDR10+ metadata for the fading frames is recalculated from both clips, so the TV's tone mapping follows the fade.
8. **Export ▸.** The defaults are GPU encode, MP4, original resolution, and the same bitrate as the phone file. Blur strength and padding update the preview live. At the end you get a checklist:
   - the frame count matches the edit
   - HDR10+ metadata is present and on the right frame, checked frame by frame against the original
   - the original phone timing is kept and the audio is cut to match

Your edits are saved automatically and come back the next time you open the app. Undo/redo covers cuts, trims, plates, slow motion, transitions, turning, and reordering or removing clips (the last 60 steps).

### Sound and the timeline

- **Sound:** the preview plays the clip's sound. 🔊 (or `M`) turns it off and on, and the slider sets the volume. Slow parts play their sound slowed down too. The timeline has an audio track (♪) under the video track: a waveform of the sound, grey where it is cut and purple where it is slowed.
- **Bigger timeline:** drag the bar above the play buttons upwards to make the timeline taller (the video and audio tracks grow with it). Double-click the bar for the normal size. The size is remembered.

### Keyboard

`Space` play · `←` `→` one frame · `Shift`+arrows 10 frames · `T` track · `Shift+T` track back · `E` end plate here · `S` start plate here · `Shift`+drag on timeline marks A–B · `Del` cut A–B (or delete the plate if no A–B is set) · `[` `]` trim · `A` `B` `X` cut · `W` slow down A–B · `P` blur preview on/off · `M` sound on/off · `R` / `Shift+R` turn right / left · `Ctrl+Z` undo · `Ctrl+Y` redo · mouse wheel over the timeline zooms (Shift+wheel scrolls).

## How the export works

For each clip:

1. ffmpeg decodes on the GPU (`-hwaccel cuda`), drops the cut frames and blurs the plate boxes. The blur uses a soft-edged mask, so the edges are clean.
2. The frames go straight from ffmpeg to NVEncC through a pipe. NVEncC encodes HEVC Main10 BT.2020/PQ, using the clip's own mastering-display and MaxCLL values.
3. hdr10plus_tool takes the clip's HDR10+ metadata, removes the entries for the cut frames, and injects the rest into the new video.

Fades are done with ffmpeg's `fade` filter and crossfades with `xfade`. A crossfade is encoded as its own short piece between the two clips, with its plates still blurred.

Slow motion only changes those timestamps (each frame in a slow part is shown longer). The audio of that part is stretched to exactly the same length, using rubberband for "same pitch".

Then the clips are joined. mkvmerge applies the phone's original per-frame timestamps, so Samsung's Auto-FPS (variable frame rate) clips keep their timing. The audio is cut at exactly the same times, encoded once to AAC at the source bitrate, and muxed into MP4 or MKV. Finally the output is read back: frames are counted and HDR10+ is extracted and compared with what was expected.

Every command the app runs is written to the log (**Log ▴** at the bottom right, or the `logs` folder in the temp directory).

## Limits

- **Resolution** in the Export window: *Keep original* uses the biggest clip's size. *2160p (4K)*, *1440p* or *1080p* make the whole video that size, scaling clips up or down as needed (e.g. 1080p clips become 4K). A scaled-up clip gets about twice the bitrate for 1080p → 4K, not four times, because upscaling adds no new detail to store.
- Clips of different sizes can be joined. The biggest clip sets the output size (or pick one under Resolution), and every other clip is scaled to fit it with a single high-quality Lanczos scale. A 1080p clip between 4K clips is scaled up to 4K, and its bitrate is raised (by the square root of the size increase). A clip of a different shape (portrait in a landscape video, 4:3 in 16:9) gets black bars. The Export window lists which clips are scaled or get bars. Upscaling can't add detail that wasn't filmed: a 1080p clip stays as sharp as 1080p, it just fills the 4K frame.
- **Clips with different frame rates** (for example 30 and 60 fps) can be joined. In the Export window, **Frame rate** has two choices:
  - **Keep each clip's own (exact)**, the default. Every part plays at the rate it was filmed (30 fps parts at 30, 60 fps parts at 60), so nothing plays too fast or too slow and the sound stays in sync. This is also how the phone's Auto-FPS clips are kept. The file has a variable frame rate, which phones, TVs, YouTube and normal players handle fine.
  - **Same for the whole video (the lowest)**. The whole video gets one steady rate, the lowest among the clips (e.g. 30 fps). A 60 fps clip then shows every other frame. Slow-motion frames are held for whole steps of 1/30 s. The sound is not changed, and it stays within half a frame of the picture. Use this if some player or editor wants one fixed frame rate. HDR10+ and the plate blur follow every frame. The setting is saved as `FPS_MODE` in `.env`.
- HDR and SDR clips can't be joined in one file. The Export window warns you before you start.
- HDR10+ is carried over from the phone, not recalculated. A blurred plate is a tiny part of the frame, so the phone's brightness data still fits the picture.
- The tracker is a classic (non-AI) template tracker. It handles moving, growing and shrinking plates and camera motion well. Check the orange-marked frames on difficult footage (strong angle changes, heavy motion blur, plate partly covered).
- The preview is a tone-mapped SDR copy at 960 px for smooth scrubbing. The export always uses the original HDR frames.
- Previews are cached in the temp folder (Settings → Temp/preview folder). You can delete that folder at any time. To redo the preview of one clip, press **⟳** on it in the clip list. Your edits stay.
- Some recordings list a few frames that can't be decoded (often the last frames of a recording that was stopped abruptly), or frames that are never shown (after a cut without re-encoding). The app notices this when it makes the preview, finds out exactly which frames decode, and uses only those, with their own timing, sound and HDR10+ entries. The log says how many frames were affected.
- If a clip was added before hdr10plus_tool was set up, it shows **HDR10+ not read ⚠**. Set the tool in Settings and press **Save**, and those clips are read again automatically (or press ⟳ on the clip).
- The lightning finder looks for sudden, short brightness jumps. Objects coming into view, auto-exposure changes and car lights are ignored. If it misses faint distant flashes, lower `FLASH_THRESHOLD` in `.env` (default 15). If it finds too much, raise it.
- With "same pitch" sound, very sharp sounds in a slow part can start up to about a quarter of a slowed frame early. That is how pitch-keeping stretch works. "Deeper" is exactly in sync.
- The crossfade preview is approximate (it mixes the two preview frames). The export is exact.
- A clip without HDR10+ can still take part in a transition. The frames from that clip are then plain HDR10.
- To use the CPU instead (no NVIDIA GPU), pick **CPU — x265** in the Export window. It is much slower.
